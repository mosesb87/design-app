;(function ($, window, document){
  var product = new function(){
     var  prodCore = this
        , prodObj = {}
        , selectedProd = ""
        , selectedColor = ""
        , selectedColorDesc = ""
        , selectedSize = ""
        , selectedSizeDesc = ""
        , selectedSizeGroup = ""
        , selectedItem = ""
        , itemWhse = {}
        , selectedWhse = ""
        , selectedPrice = ""
        , altViewTmpl    
        , opts = {
             'showStock': true
           , 'showOOS': true 
           , 'showAltViews': true 
           , 'useSzGrpImg': false
           , 'allowBo': false
           , 'regPriceLabel' : 'Price:'
           , 'regPriceSaleLabel' : 'Was:'
           , 'orderLimit' : 0
           , 'stylePriceType' : 'lowest'
           , 'hasQuickorder' : false 
          }
        , $prod
        , wishAddedTimer
        , wishAddTmpl
        , wishAddTmplHTML = ''
        , pricingGridTmpl    //ROY010011
        ;
         
     this.init = function(myProdObj,options){
        prodObj = myProdObj.product[0];
        $.extend(true,opts,options);
        $prod = $("#prod" + prodObj.styleCode);
        altViewTmpl = Handlebars.compile( $("#altViewTemplate").html() );
        prodCore.prodObj = prodObj; 
 
        if( typeof opts.selectedColor != 'undefined' && opts.selectedColor != '' ) 
           selectedColor = opts.selectedColor; 
        
        prodCore.prodObj = prodObj; 
        //Attempt to move up the ajax call by calling quickorder init from here right after prodObj is defined. 
        if(opts.hasQuickorder && typeof $.wam.product.quickorder != 'undefined' && typeof qoInitOpts != "undefined" ){ 
           $.wam.product.quickorder.init(qoInitOpts,defWhse,whseObj,prepackObj,selectedColor);
        }else{
          var query = 'action=getProdData&content=json&page=' + $.wam.opts.page + '&product=' + prodObj.styleCode;
          $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,getProductData_callback,'application/json','json',false);       
 
        }
 
        pricingGridTmpl = Handlebars.compile( $("#pricingGridTmpl").html() ); //ROY010011
      
        //(Replace... causes errors now, but proboly can be done) add color/size/item assoc array
        prodObj._item = $.wam.makeAssoc('itemNumber',prodObj.item);
        prodObj._color = $.wam.makeAssoc('colorCode',prodObj.color);
        prodObj._size = $.wam.makeAssoc('sizeCode',prodObj.size);
 
        if( typeof opts.selectedColor != 'undefined' && opts.selectedColor != '' ){
            selectedColor = opts.selectedColor;
            setColor(selectedColor,$prod.find('.colorOuter a[data-colorcode="' + selectedColor + '"]') );
            //Fix model view magiczoom to use primary style imgs
            $prod.find(".modelView a").prop('href',prodObj.imageZm).attr('rev',prodObj.imageLg);
        }
        // Color Click - need to attach directly to anchor, not delegate, due to magicZoom using preventDefault
        $prod.find('.colorOuter a').on('click.product',function(e){ 
           var $this       = $(this),
               colorCode   = String($this.data('colorcode')),
               changeColor = true; 
           e.preventDefault(); //This will prevent following the link to the zoom image if an error occurs
 
           if (typeof $.wam.product.quickorder != 'undefined' && colorCode != "undefined") { 
              changeColor = $.wam.product.quickorder.changeColor(colorCode,$this.data('desc'),true);
 
              // a call to quickorder changecolor may fail if there have been unapplied quantities in the grid
              if (changeColor) setColor(colorCode, $this ); 
           }
           else 
              setColor(colorCode, $this ); 
           
        });
            if(typeof $("#model_desc_label")[0] != 'undefined')							// mmmmmm
              document.getElementById("model_desc").setAttribute('data-desc', $("#model_desc_label")[0].innerText);
 
        // Size Click
        $prod.on('click.product','.sizeOuter a',function(){ 
           var $this = $(this);
           $prod.find('.sizeOuter').removeClass('selected');
           $this.closest('.sizeOuter').addClass('selected');
           setSize( String($this.data('sizecode')) );
        });
        
        //Out of Stock over msg display 
        $prod.on('mouseenter.product','.OOS',hoverOOSIn);
        $prod.on('mouseleave.product','.OOS',hoverOOSOut);      
       
        // Add To Cart Click
        $prod.on('click.product','.addToCartBtn',addToCart);
        $prod.on('click.product','.addToWishlistBtn',addToWishlist);
        
        // Write Review Click
        $prod.on('click.product','.writeReview',function(){ 
           $('#reviewForm').show();
        });
 
        $prod.on('click.product','.altViewVideo',showVideo); /* 011200 */
        
        // enable top tabs
        $('.prodTopTabs a').click(function (e) {
          if( $(this).attr('id') != 'btnSpecTab'){
            e.preventDefault();         
            $(this).tab('show');
          }
        });
        
        //Decorate Click
        $prod.on('click.product','.btn-decorate',function(){
          openDecorator();
        });
        $('body').on('click.product','.btnCloseDecorator',function(){
          $.wam.product.closeDecorator();
        });
       
        //Image Library Click       
        //Relative position of any parent messed up modal dialogs ... move to just before </body>
        var $tmp = $("#imgLibDialog");
        $("#imgLibDialog").remove();
        $('body').append($tmp);
        $tmp = null;
        $("#imgLibDialog").modal({show:false});
        $prod.on('click.product','#imgLibLink',getImgLib);      
        $prod.on('click.product','#imgLibLoginLink',imgLibLoginRedir);
        $prod.on('click.product','#openMillSizes',openMillSizes);
        $prod.on('click.product','.help-dialog-select',function(){ helpDialogSelect(this); }); /* 012100 */
 
        var $reviewtmp = $("#reviewDialog");
        if ($reviewtmp.length) {
            $("#reviewDialog").remove();
            $('body').append($reviewtmp);
            $reviewtmp = null;
           
            
                $("#reviewDialog").modal({
                    show: false
                });
            
            // Bind Events
            $("input[name='rating']").on('click', selectRating);
            $("#submitReview").on('click', submitReview);
            $(".helpfulYes,.helpfulNo").on('click', function () {
                submitHelpful(this);
            });
            $("#btnWriteReviewLogin").on('click', reviewLoginRedir);
        }
       
       if( $("#fdm4Decorator").length ){
         $tmp = $("#fdm4Decorator");
         $("#fdm4Decorator").remove();
         $('body').append($tmp);
         $tmp = null;        
       }
 
       wishAddTmplHTML = $("#wishlist-added-template").html();
       if(typeof wishAddTmplHTML != 'undefined' && wishAddTmplHTML != '')
          wishAddTmpl = Handlebars.compile(wishAddTmplHTML);
       
       updateAltViews();
 
     };
     
     /** Extend method for subTemplates **/
     prodCore.extend = function(name,subTmpl){
        if(typeof prodCore[name] != 'undefined'){
           $.extend(true,prodCore[name],subTmpl);      
        }else{
           prodCore[name] = subTmpl;
        }
     }
     
     //Public Access to prodObj
     prodCore.prodObj = prodObj;
    
     prodCore.getProdElm = function(){
        return $prod;
     };
     prodCore.getProdObj = function(){
       return prodObj;
     };   
    
      function getProductData_callback(data){
 
          if(typeof data == 'undefined' || typeof data.product == 'undefined'){
             $.wam.alert($.wam.getText('noProduct'));
             return;
          }
          
          //Update Product Data
          $.extend(prodObj,data.product[0]);         
 
          prodObj._item = $.wam.makeAssoc('itemNumber',prodObj.item);
 
          if( typeof opts.selectedColor != 'undefined' && opts.selectedColor != '' ){
             selectedColor = opts.selectedColor;
             setColor(selectedColor,$prod.find('.colorOuter a[data-colorcode="' + selectedColor + '"]') );
             //Fix model view magiczoom to use primary style imgs
             $prod.find(".modelView a").prop('href',prodObj.imageZm).attr('rev',prodObj.imageLg);
          }
 
          // update price for retail/co-brand
          updatePrice(); 
          updateSizes(); // needed of select first color is enabled
 
          /*****v ROY010011 v*****/
 
          //Render the pricing grid
          if(typeof data.pricingGrid == 'object')
          {
           // compiled above in the init function
           $("#pricingGridTmpl").html(pricingGridTmpl(data));
           $('#pricingGridStub').html($("#pricingGridTmpl").html()).show();
          }
            
          /*****^ ROY010011 ^*****/
 
      };
    
     //Private Functions
     function setColor(colorCode,$this){ 
      
        var vFound = false;
        if(typeof $this != 'object'){
          //ToDo: set $this to proper color element jQuery object  (add check for dom element and change to jquery)
        }
        
        //Check it is a valid color Code 
        if(typeof colorCode != 'undefined' && colorCode != 'undefined' && typeof prodObj._color[colorCode] != 'object'){
         selectedColor = '';                                                                        
         updateAltViews();                                                                          
           return;
        }
 
        $prod.find('.colorOuter').removeClass('selected');
        $this.closest('.colorOuter').addClass('selected');
 
        //add check for presell here...?
        
        if(typeof colorCode == 'undefined' || colorCode == 'undefined'){
          selectedColor = "";         
          selectedColorDesc = "";
          $prod.find('.selectedSizeDesc').html('');
          selectedSize = "";
          selectedSizeDesc = "";
          $prod.find('.sizeOuter').removeClass('selected');
        }else{
          selectedColor = colorCode;         
          selectedColorDesc = prodObj._color[colorCode].description;
        }
        //Selected class highlight aleeady handled above in onclick - move here + add OOS / Presell checks for classes
        $prod.find('.selectedColorDesc').html(selectedColorDesc);
 
        clearErrors(); // Blank out any add to cart errors
 
        /*
         Previously handled magiczoom image switching manually - now just let the default mz click event handle it 
         No on hover switching - must click to change, so no locked image handleing required        
        */        
 
        //Check that selected size is still valid for this color 
        if (selectedSize != ""){
           $.each(prodObj.item,function(i){
              if(this.colorCode == selectedColor && this.sizeCode == selectedSize){
                 vFound = true;
                 return false;
              }
           });
           if(!vFound){
              selectedSize = "";
              selectedSizeDesc = "";
              $prod.find('.sizeOuter').removeClass('selected');
           }
        }
 
        //Set Selected Item
        if(selectedSize !== "" && selectedColor != ""){
           for(var i=0;i<prodObj.item.length;i++){
              if( prodObj.item[i].colorCode == selectedColor && prodObj.item[i].sizeCode == selectedSize ){
                selectedItem = prodObj.item[i].itemNumber;
                break;
              }
           }
        }else{
          selectedItem = "";
        }
    
        if(typeof colorCode != 'undefined' && colorCode != 'undefined'){
        if ($("#colorPlaceHolder").length) {
          var revertColorGrid = $(".colorGrid .product-item").clone(true);
          var colorGrid = $('div').find('#qoColor_' + selectedColor).clone(true);
          $(".colorGrid .product-description").toggleClass("flex-md-row flex-lg-row");
          $(".colorGrid .product-content").toggleClass("flex-md-nowrap flex-lg-nowrap");
          $("#colorPlaceHolder").replaceWith(revertColorGrid);
          $('div').find('#qoColor_' + selectedColor).replaceWith("<div id='colorPlaceHolder' style='display:none'></div>");
          $(".colorGrid").html(colorGrid);
          $(".colorGrid .product-description").toggleClass("flex-md-row flex-lg-row");
          $(".colorGrid .product-content").toggleClass("flex-md-nowrap flex-lg-nowrap");
 
 
        }else{
          var colorGrid = $('div').find('#qoColor_' + selectedColor).clone(true);
          $('div').find('#qoColor_' + selectedColor).replaceWith("<div id='colorPlaceHolder' style='display:none'></div>");
          $(".colorGrid").html(colorGrid);
          $(".colorGrid .product-description").toggleClass("flex-md-row flex-lg-row");
          $(".colorGrid .product-content").toggleClass("flex-md-nowrap flex-lg-nowrap");
        }
        }
        
      
        updateSizes();
        updatePrice();
        updateAltViews();
     }
     //make setColor public so quickorder can use
     this.setColor = setColor;
     
     /***********************************************************************/
     function setSize(sizeCode){
        var vFound = false;
        
        if(typeof prodObj._size[sizeCode] != 'object'){
          return;
        }
 
        selectedSize = sizeCode;
        selectedSizeDesc = prodObj._size[sizeCode].description;
        if(opts.useSzGrpImg)
          selectedSizeGroup = prodObj._size[sizeCode].sizeGroup;
 
        $prod.find('.selectedSizeDesc').html(selectedSizeDesc);
        
        clearErrors();
 
        if (selectedColor != ""){
           $.each(prodObj.item,function(i){
              if(this.colorCode == selectedColor && this.sizeCode == selectedSize){
                 vFound = true;
                 return false;
              }
           });
           if(!vFound){
              selectedColor = "";
              selectedColorDesc = "";
           }
        }
        
        //Set Selected Item
        if(selectedSize !== "" && selectedColor != ""){
           for(var i=0;i<prodObj.item.length;i++){
              if( prodObj.item[i].colorCode == selectedColor && prodObj.item[i].sizeCode == selectedSize ){
                selectedItem = prodObj.item[i].itemNumber;
                break;
              }
           }
        }else{
          selectedItem = "";
        }
 
        updateColors();
        updatePrice();
     }
     /***********************************************************************/
     function updateColors(){
       var availColors = [];
       $(prodObj.item).each(function(){ 
         if( selectedSize == "" || selectedSize == this.sizeCode){
            if(!availColors[this.colorCode]){
               availColors[this.colorCode] = { item: [] };
            }
            availColors[this.colorCode].item.push(this);
         }
       });
 
       $prod.find('.colorOuter').each(function(){ 
         var $this = $(this),
             colorCode = String($this.find('a').data('colorcode')),
             availQty = 0,
             isPresell = false;
 
         if(availColors[ colorCode ]){
            $this.show();
            $(availColors[ colorCode ].item).each(function(){ 
               availQty += this.availQty
               if(this.preSell) isPresell = true;
            });
            if(isPresell){
               $this.addClass('preSell');
            }else{
               $this.removeClass('preSell');
            }
            if(!isPresell && availQty <= 0){
               if(opts.showStock){
                  $this.addClass('OOS');
               }else{
                  $this.hide();
               }
 
            }else{
               $this.removeClass('OOS');
            }
         }else{
            if(!$this.hasClass('modelView')){
               $this.hide();
            }
         }
 
       });
     }
     /***********************************************************************/
     function updateSizes(){
       var availSizes = [];
       $(prodObj.item).each(function(){ 
         if( selectedColor == "" || selectedColor == this.colorCode){
            if(!availSizes[this.sizeCode]){
               availSizes[this.sizeCode] = { item: [] };
            }
            availSizes[this.sizeCode].item.push(this);
         }
       });
       
       $prod.find('.sizeOuter').each(function(){ 
         var $this = $(this),
             sizeCode = String($this.find('a').data('sizecode'));
             availQty = 0,
             isPresell = false;
 
         //inital before ajax call gets item data - show all sizes
         if(typeof prodObj.item == "undefined"){ 
            $this.show();
            return;
         }
        
         if(availSizes[ sizeCode ]){
            $this.show();
            $(availSizes[ sizeCode ].item).each(function(){ 
               availQty += this.availQty
               if(this.preSell) isPresell = true;
            });
            if(isPresell){
               $this.addClass('preSell');
            }else{
               $this.removeClass('preSell');
            }
            if(!isPresell && availQty <= 0){
               $this.addClass('OOS');
            }else{
               $this.removeClass('OOS');
            }
         }else{
            $this.hide();
         }
 
       });
     }
     /***********************************************************************/
     function updatePrice(){
        var vRegLow = 0,  
            vRegHigh = 0, 
            vRegPrice = 0,
            vSaleLow = 0, 
            vSaleHigh = 0, 
            vSalePrice = 0,
            vSaleLabel,
            vTmpPrice = 0,
            vTmpSalePrice = 0;
        
        //Calculate for both low and high then use option param to deterin if using low/high/range 
        if(selectedItem != ""){
           if(prodObj._item[selectedItem]){
              vRegPrice  = prodObj._item[selectedItem].regPrice;
              vSalePrice = prodObj._item[selectedItem].salePrice;
              vSaleLabel = prodObj._item[selectedItem].saleLabel;
              //vRegLabel = prodObj._item[selectedItem].regPrice;
           }
        }else{
           
           //None Selected
           if(selectedColor == "" && selectedSize == ""){
              vRegPrice  = prodObj.regPrice;
              vSalePrice = prodObj.salePrice;
              vSaleLabel = prodObj.saleLabel;
              if(opts.stylePriceType == 'range'){
                 $(prodObj.item).each(function(){ 
                    if(this.salePrice > 0 && this.salePrice > vSaleHigh )
                        vSaleHigh = this.salePrice;
                    if(this.salePrice > 0 && (this.salePrice < vSaleLow || vSaleLow == 0) )
                        vSaleLow = this.salePrice;
 
                    if(this.regPrice > 0 && this.regPrice > vRegHigh )
                        vRegHigh = this.regPrice;
                    if(this.regPrice > 0 && (this.regPrice < vRegLow || vRegLow == 0) )
                        vRegLow = this.regPrice;
                 });
              }
           }
 
           //Color Only
           if(selectedColor != "" && selectedSize == ""){
              $(prodObj.item).each(function(){ 
                if(this.colorCode == selectedColor){
                  if(this.salePrice > 0 && (this.salePrice < vTmpSalePrice || vTmpSalePrice == 0) ){
                     vTmpSalePrice = this.salePrice;
                     vSaleLabel = this.saleLabel;
                  }
                  if(this.regPrice > 0 && (this.regPrice < vTmpPrice || vTmpPrice == 0) )
                      vTmpPrice = this.regPrice;
                  
                  if(opts.stylePriceType == 'range'){
                     if(this.salePrice > 0 && this.salePrice > vSaleHigh )
                         vSaleHigh = this.salePrice;
                     if(this.salePrice > 0 && (this.salePrice < vSaleLow || vSaleLow == 0) )
                         vSaleLow = this.salePrice;
 
                     if(this.regPrice > 0 && this.regPrice > vRegHigh )
                         vRegHigh = this.regPrice;
                     if(this.regPrice > 0 && (this.regPrice < vRegLow || vRegLow == 0) )
                         vRegLow = this.regPrice;
                  }
                }
              });
              vRegPrice = vTmpPrice;
              vSalePrice = vTmpSalePrice;
              vSaleLabel = vSaleLabel;
           }
           
           //Size Only
           if(selectedColor == "" && selectedSize != ""){
              $(prodObj.item).each(function(){ 
                if(this.sizeCode == selectedSize){
                  if(this.salePrice > 0 && (this.salePrice < vTmpSalePrice || vTmpSalePrice == 0) ){
                     vTmpSalePrice = this.salePrice;
                     vSaleLabel = this.saleLabel;
                  }
                  if(this.regPrice > 0 && (this.regPrice < vTmpPrice || vTmpPrice == 0) )
                      vTmpPrice = this.regPrice;
                }
                if(opts.stylePriceType == 'range'){
                   if(this.salePrice > 0 && this.salePrice > vSaleHigh )
                       vSaleHigh = this.salePrice;
                   if(this.salePrice > 0 && (this.salePrice < vSaleLow || vSaleLow == 0) )
                       vSaleLow = this.salePrice;
 
                   if(this.regPrice > 0 && this.regPrice > vRegHigh )
                       vRegHigh = this.regPrice;
                   if(this.regPrice > 0 && (this.regPrice < vRegLow || vRegLow == 0) )
                       vRegLow = this.regPrice;
                }
              });
              vRegPrice = vTmpPrice;
              vSalePrice = vTmpSalePrice;
              vSaleLabel = vSaleLabel;
           }
 
        }
 
        //Update HTML 
        if(opts.stylePriceType == 'range' && selectedItem == ""){
           if(vRegHigh != vRegLow){
              $prod.find('.regPrice').html( $.wam.format('currency',vRegLow) + ' - ' + $.wam.format('currency',vRegHigh) );
           }else{
              $prod.find('.regPrice').html( $.wam.format('currency',vRegLow) );
           }
           if(vSaleHigh != vSaleLow){
              $prod.find('.salePrice').html( $.wam.format('currency',vSaleLow) + ' - ' + $.wam.format('currency',vSaleHigh) );
           }else{
              $prod.find('.salePrice').html( $.wam.format('currency',vSaleLow) );
           }
           $prod.find('.salePrice').html( $.wam.format('currency',vSalePrice) );
           $prod.find('.salePriceLabel').html( vSaleLabel );
        }else{
           $prod.find('.regPrice').html( $.wam.format('currency',vRegPrice) );
           $prod.find('.salePrice').html( $.wam.format('currency',vSalePrice) );
           $prod.find('.salePriceLabel').html( vSaleLabel );
        }
       
        if(vSalePrice > 0 ){
           $prod.find('.regPrice').addClass('priceStrike');
           $prod.find('.salePrice, .salePriceLabel, .regPriceLabel').show();
        }else{
           $prod.find('.regPrice').removeClass('priceStrike');  
           $prod.find('.salePrice, .salePriceLabel, .regPriceLabel').hide();
        }
 
     }; //updatePrice()
     /*************************************************************/
     function updateAltViews(){
       if(!opts.showAltViews) return;
       var altViewObj = {'altView':[]}, altViewHTML = "";
       $(prodObj.altView).each(function(){
            /* What about size / sizeGroup ... was that ever finished / tested? */ 
            if(this.colorCode == selectedColor) {
               altViewObj.altView.push(this);
            }
       });      
       altViewHTML = altViewTmpl(altViewObj);
       $prod.find('.altViews').html(altViewHTML);
       if( $.trim(altViewHTML) == "" ){
         $prod.find('.altViews').hide();
       }else{ 
         $prod.find('.altViews').show();       
       }
     };
 
     function updateAltViews_old(){
       if(!opts.showAltViews) return;
       
       $prod.find('.altViewInner').each(function(){
         var $this = $(this),
             altID = $this.data('altid'),
             viewFound = false;
 
            $this.hide(); // initially hide the display
 
         $(prodObj.altView).each(function(){
            if(this.altId == altID && this.colorCode == selectedColor && this.sizeGroup == selectedSizeGroup &&
              $this.data("altid") == altID && $this.data("color") == selectedColor && $this.data("size") == selectedSizeGroup) {
              $this.find('a').prop('href',this.imageZm)
                             .prop('rev',this.imageLg)
                   .find('img').prop('src',this.imageSm);
              $this.show();
              viewFound = true;             
            }
         });
            });
 
       if ($(".altViewVideo")[0] != undefined && $($(".altViewVideo")[0]).data("video") != "") {
         $($(".altViewVideo")[0]).show();
               }
 
     };
 
     function openDecorator(colorName){
        if (colorName==''||colorName==null) colorName=selectedColorDesc;
        var laFrameURL;
 
        if(!laUseDecorator) return;
        if(!laHasOrderedProd){
          $.wam.alert( $.wam.getText('dec_no_prod') );
          return; 
        }
        if(!$("#fdm4Decorator").length){
           //This is a basic default if one is not defined in the template
           $('body').append('<div id="fdm4Decorator" class="offScreen"><a href="javascript:void(0);" class="decoratorClose btn-decorate-close">&times;</a><iframe id="fdm4DecoratorIframe" src="about:blank" /><br/><div class="clearfix"><a class="btn-decorate-close btn btn-primary pull-left" href="javascript:void(0);">' + $.wam.getText('close') + '</a></div></div>');
           $('body').on('click','.btn-decorate-close',function(){
              $.product.closeDecorator();
           });
        }
        if($("#fdm4DecoratorIframe").prop('src') == 'about:blank'){
           laFrameURL = laRootPath + 'index.html';
           laColorName = colorName;
           colorName = false;
           if(laDesignID){
             laFrameURL += '?design_id=' + laDesignID;
           }
           $("#fdm4DecoratorIframe").prop('src',laFrameURL);
        }
        if(colorName){
           //ToDo update selected color on current design... (clear first?)
           $("#fdm4DecoratorIframe")[0].contentWindow.LAJS.Model.controlsManager.controlsModel.setProductColorByName(colorName);
           //$("#fdm4DecoratorIframe")[0].contentWindow.LAJS.Util.arrayFind(obj.complexColor.colorizeList, "name", colorName)
        }
        $("#fdm4Decorator").removeClass('offScreen').css('z-index',999999);
        $.wam.block();
        $("a","#fdm4Decorator").prop('disabled',false); //IE fix for disabled close button
        $.wam.scrollTo("#fdm4Decorator",500,-10);
     }; 
     prodCore.closeDecorator = function(){
        if(!laUseDecorator) return;
        $("#fdm4Decorator").addClass('offScreen').css('z-index',1);
        if(!$.wam.keepBlock){
          $.wam.unblock();
        }
     };
     
     /*************************************************************/
     var hoverOOSIn = function(){      
       var $this = $(this),
           sizeDesc = selectedSizeDesc,
           colorDesc = selectedColorDesc;
       
       if( $this.hasClass('sizeOuter') ){
         sizeDesc = $this.find('.sizeInner').html();
       }else{
         colorDesc = $this.find('a:first').data('desc');
       }
       showOOSMsg(colorDesc,sizeDesc);
     };
     var hoverOOSOut = function(){            
       $("#imgMsg").hide();
     };
     var showOOSMsg = function(vColor,vSize){      
       var vPosition = $(".imgUpper").position();      
       
       $("#imgMsgColor").html(vColor);
       $("#imgMsgSize").html(vSize);      
       $("#imgMsg").show();
       var vTopOffset  = ( $(".prodImgInner").outerHeight() - $("#imgMsg").outerHeight() - ( $("#imgMsg").outerHeight()/2) );
       var vLeftOffset = ( $(".imgUpper").outerWidth() - $("#imgMsg").outerWidth() )/2;
 
       $("#imgMsg").css("top",vPosition.top + vTopOffset)
                   .css("left",vPosition.left + vLeftOffset);      
     };
     
     /*************************************************************/
     var imgLibLoginRedir = function(){
         $.wam.confirm( $.wam.getText('img_lib_login') ,function(yes){ 
           if(yes){
              $.wam.golink('/wam_tmpl/login.p','page=' + $.wam.opts.defPages.login + '&loginLocation=' + encodeURIComponent('/wam_tmpl/catalog_product.p?page=' + $.wam.opts.page + '&product=' + prodObj.styleCode) );
           }
         }); 
     };
     var getImgLib = function(){ 
         var libHref = $("#imgLibLink").data('href') + '&color=' + selectedColor;
         $.wam.ajaxPost(libHref,'get',null,getImgLib_callback,'text/html','html',true);
         return false;
     };
     var getImgLib_callback = function(data){ 
       $(".modal-body","#imgLibDialog").html(data);
       $("#imgLibDialog").modal('show');
 
     };
     var openMillSizes = function(){ 
       var imgSrc = $(".millSizesImg","#prodMillSizesTab").prop('src'),
           msgHtml = '<img src="' + imgSrc + '" class="millSizesOpen">';
       $.wam.alert(msgHtml);
       $(".modal-dialog",".bootbox-alert").addClass('modal-lg text-center').find('.bootbox-body').css('overflow','auto');
 
     };   
     /*************************************************************/
     var addToWishlist = function(){ 
        var errMsg = "",
            qty = $prod.find('#qty').val();
        if(!selectedItem && !selectedColor)
           errMsg = $.wam.getText('no_clr');
        else if(!selectedItem && !selectedSize)
           errMsg = $.wam.getText('no_sz');
        else if(!selectedItem)
           errMsg = $.wam.getText('invld_prod');
        else if( isNaN(qty) || qty <= 0)
           errMsg = $.wam.getText('nan_qty');      
        else if( !opts.allowBo ){
          var iAvail = 0;
          try{ iAvail = prodObj._item[selectedItem].availQty; }catch(e){};
          if(iAvail <= 0){
             errMsg = $.wam.getText('itm_oos');         
          }else{
             if(qty > iAvail){
               errMsg = qty + ' ' + $.wam.getText('qty_over_avail') + ' ' + iAvail;
             }
          }
        }
        
        if(errMsg){
           $prod.find('#msgArea').html(errMsg).addClass('alert alert-danger').show();
           $.wam.scrollTo('#msgArea');
           return;
        }
 
        $.wam.hdrCart.add(qty,selectedItem,addToWishlistCallback,'Q');
 
     }; //addToWishlist()
 
     var addToWishlistCallback = function(data){ 
       if(typeof data != 'object') return;
       
       if(typeof data.msg == "object"){
          $prod.find('#msgArea').html( data.msg[0].msg );
           if(!data.msg[0].success){
             $("#msgArea").addClass('alert alert-danger').show();
           }else{
             $("#msgArea").addClass('alert alert-success').show();
           }
           $.wam.scrollTo('#msgArea');
       }else if(typeof data[0] == 'object'){
           $("#msgArea").html(data[0].msg);
           if(!data[0].success){
             $("#msgArea").addClass('alert alert-danger').show();
           }else{
             $("#msgArea").addClass('alert alert-success').show();
           }
           $.wam.scrollTo('#msgArea');
       }
       //Show add to wishlist response
       if(typeof wishAddTmpl == 'function'){
          var addProdObj;
          try{ addProdObj = data.added[0] }catch(e){};
          if(typeof addProdObj != 'undefined'){
             var addHTML = wishAddTmpl( addProdObj );
             $('#wishlistAddStub').html(addHTML).show();
             clearTimeout(wishAddedTimer)
             wishAddedTimer = setTimeout(function() { $('#wishlistAddStub').hide(); }, 4000);
          }
       }
     }; 
     /*************************************************************/
     var getItemOrderLimit = function(vItem){
        var iLimit = 0;
        try{ iLimit = prodObj._item[vItem].orderLimit; }catch(e){};
        if(opts.orderLimit > 0 && iLimit > 0 && opts.orderLimit < iLimit){
          iLimit = opts.orderLimit;
        }
        return iLimit;
     };
     /*************************************************************/
     var addToCart = function(){ 
        var errMsg = "",
            qty = $prod.find('#qty').val();
        $prod.find('#msgArea').html('').removeClass('alert alert-danger').hide();
        if(!selectedItem && !selectedColor)
           errMsg = $.wam.getText('no_clr');
        else if(!selectedItem && !selectedSize)
           errMsg = $.wam.getText('no_sz');
        else if(!selectedItem)
           errMsg = $.wam.getText('invld_prod');
        else if( isNaN(qty) || qty <= 0)
           errMsg = $.wam.getText('nan_qty');     
        else{ 
           var iLimit = getItemOrderLimit(selectedItem);
           if( iLimit > 0 && parseFloat(qty) + $.wam.hdrCart.getItemOrdered(selectedItem) > iLimit )
             errMsg = $.wam.getText('over_limit') + ' ' + iLimit;
        } 
        if( !opts.allowBo && errMsg == ""){
          var iAvail = 0;
          try{ iAvail = prodObj._item[selectedItem].availQty; }catch(e){};
          if(iAvail <= 0){
             errMsg = $.wam.getText('itm_oos');
          }else if(qty > iAvail){
             errMsg = qty + ' ' + $.wam.getText('qty_over_avail') + ' ' + iAvail;
          }
        }
 
        if(errMsg){
           $prod.find('#msgArea').html(errMsg).addClass('alert alert-danger').show();
           $.wam.scrollTo('#msgArea',500,-150);
           return;
        }
       
        //For Retail Add to what is already in the cart
        qty = parseFloat(qty);
        qty += $.wam.hdrCart.getItemOrdered(selectedItem);
       
        $.wam.hdrCart.add(qty,selectedItem,addToCartCallback);
 
     }; //addToCart()
     var addToCartCallback = function(data){ 
       if(typeof data != 'object') return;
 
       /* vv ROY010101 vv */
       //GTM add to cart event
       if ($.wam.opts.enhancedEcomm == true){
           products = [];
           for (var i=0; i<data.order[0].orderLine.length; i++){
               var dataObj = data.order[0].orderLine[i];
               products.push({
                   'name': dataObj.styleDesc.toUpperCase(),
                   'id': dataObj.styleCode.toUpperCase(),
                   'value': dataObj.price, /* EC-564 */
                   'category': dataObj.category,
                   'variant': dataObj.colorDesc + ' ' + dataObj.sizeDesc,
                   'quantity': dataObj.qty
               });
           }
   
           dataLayer.push({
              'event': 'add_to_cart', /* EC-564 */
               'ecommerce': {
                   'currencyCode': opts.currency,
                  'items':  products /* EC-564 */
               }
           });
       }
       /* ^^ ROY010101 ^^ */
       
       if(typeof data.msg == "object"){
          $prod.find('#msgArea').html( data.msg[0].msg );
           if(!data.msg[0].success){
             $("#msgArea").addClass('alert alert-danger').show();
           }else{
             $("#msgArea").addClass('alert alert-success').show();
           }
          $.wam.scrollTo('#msgArea');
       }else if(typeof data[0] == 'object'){
           $("#msgArea").html(data[0].msg);
           if(!data[0].success){
             $("#msgArea").addClass('alert alert-danger').show();
           }else{
             $("#msgArea").addClass('alert alert-success').show();
           }                  
       }
     }; 
     /*v 011200 v*/
     var showVideo = function(){
      var $this = $(this),
          videoSRC = $this.data('video');
      if(typeof videoSRC == "string" && videoSRC != ""){
         var videoHTML = "<video id='prodVideo' controls autoplay src='" + videoSRC + "' width='100%'></video>"; 
        $.wam.alert({ size: "large",
                     message : videoHTML                    
                    });
      }
    };
    /*^ 011200 ^*/
     /*************************************************************/
     function clearErrors(){
       $("#msgArea").html('').prop('class','').hide();
     };   
     /*v 012100 v*/
     function helpDialogSelect(vthis) {
        var $this = $(vthis);
        var returndata = [];
        returndata.push($this.data("productid"));
        if (selectedColor!="") returndata.push(selectedColor);
        parent.helpClick(returndata);
     }; // helpDialogSelect
     /*^ 012100 ^*/
       //Private Functions
     function selectRating(msg){ 
         $("input[name='reviewRating']").val( $("input[name='rating']:checked").val() );
      };
      function reviewLoginRedir(){
        $.wam.confirm( $.wam.getText('review_login'),function(yes){ 
          if(yes){
             $.wam.golink('/wam_tmpl/login.p','page=' + $.wam.opts.defPages.login + '&loginLocation=' + encodeURIComponent('/wam_tmpl/catalog_product.p?page=' + $.wam.opts.page + '&product=' + $.wam.product.prodObj.styleCode) );
          }
        }); 
      };
      function submitReview(){ 
        var query = 'action=submitReview&content=json&product=' + $.wam.product.prodObj.styleCode;
        $('#reviewMsg').html('').removeClass('alert alert-danger alert-success');
        //Validate - check for invalid char / title entered etc. 
        if( document.productReview.reviewTitle.value == '' ){
           $('#reviewMsg').html( $.wam.getText('no_rev_title') ).addClass('alert alert-danger');
           return;
        }
        if( document.productReview.reviewBody.value == '' ){
           $('#reviewMsg').html( $.wam.getText('no_rev_review')  ).addClass('alert alert-danger');
           return;
        }        
        if( $("input[name='rating']:checked",".ratingSelect").length == 0 ){
           $('#reviewMsg').html( $.wam.getText('no_rev_star') ).addClass('alert alert-danger');
           return;
        }        
        query += '&' + $('form[name="productReview"]').serialize();
        $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,submitReview_callback,'application/json','json',true);
      };
      function submitReview_callback(data){
         if(typeof data.msg == "object"){
            $('#reviewMsg').html( data.msg[0].msg );
            if( data.msg[0].success ){
              $('#reviewMsg').addClass('alert alert-success');
              $('form[name="productReview"]').slideUp();
              $("#submitReview").hide();              
            }else{
              $('#reviewMsg').addClass('alert alert-danger');              
            }
         }
      };
 
      function submitHelpful(vThis){ 
        var $this = $(vThis),
            rowID = $this.closest('.reviewDetail').data('rowid'),
            isHelpful = $this.hasClass('helpfulYes'),
            query = 'action=submitHelpful&content=json&reviewRowID=' + rowID + '&isHelpful=' + isHelpful;
 
        $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,function(data){ submitHelpful_callback(data, $this); },'application/json','json',true);
      };
      function submitHelpful_callback(data,$this){
         if(typeof data.msg == "object"){
            //Could set localstorage value of rowid to prevent submitting multiple times... then check and hide yes / no in docReady... 
            $this.closest('.helpfulOuter').html( data.msg[0].msg );
         }
      };
 
      function goReviewMsg(msg){
          var $revMsg = $('#reviewMsg');
          $revMsg.html(msg);
          //Scroll to the top of the browse products
          $("html,body").animate({scrollTop: $revMsg.offset().top },250);
      };
  }; //END product
  
  //Extend $.wam with product
  $.extend(true,$.wam,{
    'product': product
  });
    
 })( jQuery, window, document );
 
 /*!Magic Zoom v4.5.28 
    Copyright 2014 Magic Toolbox
    License agreement: http://www.magictoolbox.com/license/
 */
 /* ... need v5+ for these ... 
 var mzOptions = { autostart: false, autoStart: false };
 var mzMobileOptions  = { autostart: false, autoStart: false };
 */
 
 eval(function(m,a,g,i,c,k){c=function(e){return(e<a?'':c(parseInt(e/a)))+((e=e%a)>35?String.fromCharCode(e+29):e.toString(36))};if(!''.replace(/^/,String)){while(g--){k[c(g)]=i[g]||c(g)}i=[function(e){return k[e]}];c=function(){return'\\w+'};g=1};while(g--){if(i[g]){m=m.replace(new RegExp('\\b'+c(g)+'\\b','g'),i[g])}}return m}('(R(){N(13.4L){Q}U b={3A:"b3.7.4",8z:0,52:{},$73:R(d){Q(d.$3t||(d.$3t=++a.8z))},5k:R(d){Q(a.52[d]||(a.52[d]={}))},$F:R(){},$X:R(){Q X},1O:R(d){Q(1m!=d)},b4:R(d){Q!!(d)},27:R(d){N(!a.1O(d)){Q X}N(d.$2I){Q d.$2I}N(!!d.3m){N(1==d.3m){Q"69"}N(3==d.3m){Q"8K"}}N(d.1w&&d.6p){Q"b5"}N(d.1w&&d.5u){Q"1D"}N((d 2Q 13.b6||d 2Q 13.72)&&d.2W===a.3W){Q"43"}N(d 2Q 13.3u){Q"49"}N(d 2Q 13.72){Q"R"}N(d 2Q 13.6T){Q"3Z"}N(a.V.2L){N(a.1O(d.8h)){Q"3e"}}1e{N(d===13.3e||d.2W==13.7j||d.2W==13.b2||d.2W==13.b1||d.2W==13.aX||d.2W==13.aW){Q"3e"}}N(d 2Q 13.9i){Q"8Y"}N(d 2Q 13.7n){Q"aY"}N(d===13){Q"13"}N(d===1d){Q"1d"}Q 39(d)},1G:R(j,h){N(!(j 2Q 13.3u)){j=[j]}1q(U g=0,e=j.1w;g<e;g++){N(!a.1O(j)){4V}1q(U f 1I(h||{})){2z{j[g][f]=h[f]}30(d){}}}Q j[0]},63:R(h,g){N(!(h 2Q 13.3u)){h=[h]}1q(U f=0,d=h.1w;f<d;f++){N(!a.1O(h[f])){4V}N(!h[f].1N){4V}1q(U e 1I(g||{})){N(!h[f].1N[e]){h[f].1N[e]=g[e]}}}Q h[0]},9h:R(f,e){N(!a.1O(f)){Q f}1q(U d 1I(e||{})){N(!f[d]){f[d]=e[d]}}Q f},$2z:R(){1q(U f=0,d=1D.1w;f<d;f++){2z{Q 1D[f]()}30(g){}}Q 1c},$A:R(f){N(!a.1O(f)){Q $12([])}N(f.9W){Q $12(f.9W())}N(f.6p){U e=f.1w||0,d=1A 3u(e);3b(e--){d[e]=f[e]}Q $12(d)}Q $12(3u.1N.aZ.1L(f))},2N:R(){Q 1A 9i().b0()},3U:R(h){U f;31(a.27(h)){1p"6v":f={};1q(U g 1I h){f[g]=a.3U(h[g])}1n;1p"49":f=[];1q(U e=0,d=h.1w;e<d;e++){f[e]=a.3U(h[e])}1n;3h:Q h}Q a.$(f)},$:R(e){N(!a.1O(e)){Q 1c}N(e.$7h){Q e}31(a.27(e)){1p"49":e=a.9h(e,a.1G(a.3u,{$7h:a.$F}));e.2A=e.8m;e.3n=a.3u.3n;Q e;1n;1p"3Z":U d=1d.9C(e);N(a.1O(d)){Q a.$(d)}Q 1c;1n;1p"13":1p"1d":a.$73(e);e=a.1G(e,a.42);1n;1p"69":a.$73(e);e=a.1G(e,a.2a);1n;1p"3e":e=a.1G(e,a.7j);1n;1p"8K":Q e;1n;1p"R":1p"49":1p"8Y":3h:1n}Q a.1G(e,{$7h:a.$F})},$1A:R(d,f,e){Q $12(a.9s.2Z(d)).9U(f||{}).1f(e||{})},b7:R(e){N(1d.7c&&1d.7c.1w){1d.7c[0].6u(e,0)}1e{U d=$12(1d.2Z("1l"));d.2K(e);1d.56("5G")[0].1M(d)}}};U a=b;13.4L=b;13.$12=b.$;a.3u={$2I:"49",79:R(g,h){U d=M.1w;1q(U e=M.1w,f=(h<0)?1o.3c(0,e+h):h||0;f<e;f++){N(M[f]===g){Q f}}Q-1},3n:R(d,e){Q M.79(d,e)!=-1},8m:R(d,g){1q(U f=0,e=M.1w;f<e;f++){N(f 1I M){d.1L(g,M[f],f,M)}}},44:R(d,j){U h=[];1q(U g=0,e=M.1w;g<e;g++){N(g 1I M){U f=M[g];N(d.1L(j,M[g],g,M)){h.4y(f)}}}Q h},b8:R(d,h){U g=[];1q(U f=0,e=M.1w;f<e;f++){N(f 1I M){g[f]=d.1L(h,M[f],f,M)}}Q g}};a.63(6T,{$2I:"3Z",5P:R(){Q M.3P(/^\\s+|\\s+$/g,"")},bh:R(d,e){Q(e||X)?(M.48()===d.48()):(M.2H().48()===d.2H().48())},2g:R(){Q M.3P(/-\\D/g,R(d){Q d.93(1).bi()})},9n:R(){Q M.3P(/[A-Z]/g,R(d){Q("-"+d.93(0).2H())})},4r:R(d){Q 2i(M,d||10)},bj:R(){Q 2T(M)},7C:R(){Q!M.3P(/19/i,"").5P()},2r:R(e,d){d=d||"";Q(d+M+d).79(d+e+d)>-1}});b.63(72,{$2I:"R",1S:R(){U e=a.$A(1D),d=M,f=e.4G();Q R(){Q d.35(f||1c,e.8i(a.$A(1D)))}},3d:R(){U e=a.$A(1D),d=M,f=e.4G();Q R(g){Q d.35(f||1c,$12([g||13.3e]).8i(e))}},2n:R(){U e=a.$A(1D),d=M,f=e.4G();Q 13.4s(R(){Q d.35(d,e)},f||0)},bk:R(){U e=a.$A(1D),d=M;Q R(){Q d.2n.35(d,e)}},9F:R(){U e=a.$A(1D),d=M,f=e.4G();Q 13.bg(R(){Q d.35(d,e)},f||0)}});U c=6M.bf.2H();a.V={6b:{8x:!!(1d.ba),b9:!!(13.bb),6q:!!(1d.bd)},4u:R(){Q"be"1I 13||(13.7X&&1d 2Q 7X)}(),aV:c.4b(/a0|aU|aD|aC\\/|aE|aF|aG|aB|aA|aw|av|a5(a4|a7|ad)|ax|ay|az |aH|aI|aQ|aR|9T m(aS|1I)i|aT( aP)?|9r|p(aO|au)\\/|aK|aJ|aL|aM|aN|bm\\.(V|bn)|bW|bX|bY (ce|9r)|bZ|bV/)?19:X,34:(13.9T)?"6O":!!(13.bU)?"2L":(1m!=1d.bQ||1c!=13.bP)?"8l":(1c!=13.bR||!6M.bS)?"2y":"bT",3A:"",2u:0,6d:c.4b(/a5(?:ad|a7|a4)/)?"95":(c.4b(/(?:c0|a0)/)||6M.6d.4b(/c1|6G|c9/i)||["ca"])[0].2H(),3V:1d.5p&&"9y"==1d.5p.2H(),2E:R(){Q(1d.5p&&"9y"==1d.5p.2H())?1d.23:1d.5D},3C:13.3C||13.cc||13.cd||13.c8||13.c7||1m,66:13.66||13.9L||13.9L||13.c3||13.c2||13.c4||1m,1T:X,2t:R(){N(a.V.1T){Q}a.V.1T=19;a.23=$12(1d.23);a.6G=$12(13);(R(){a.V.4a={2F:X,1V:""};N(39 1d.23.1l.8j!=="1m"){a.V.4a.2F=19}1e{U f="7U 7Q O 6m 7R".5T(" ");1q(U e=0,d=f.1w;e<d;e++){a.V.4a.1V=f[e];N(39 1d.23.1l[a.V.4a.1V+"c5"]!=="1m"){a.V.4a.2F=19;1n}}}})();(R(){a.V.4A={2F:X,1V:""};N(39 1d.23.1l.c6!=="1m"){a.V.4A.2F=19}1e{U f="7U 7Q O 6m 7R".5T(" ");1q(U e=0,d=f.1w;e<d;e++){a.V.4A.1V=f[e];N(39 1d.23.1l[a.V.4A.1V+"bO"]!=="1m"){a.V.4A.2F=19;1n}}}})();$12(1d).9S("3Q")}};(R(){R d(){Q!!(1D.5u.6J)}a.V.3A=("6O"==a.V.34)?!!(1d.5G)?bN:!!(13.bw)?bx:!!(13.87)?by:(a.V.6b.6q)?bz:((d())?bv:((1d.4Z)?bu:6a)):("2L"==a.V.34)?!!(13.bp||13.bo)?84:!!(13.8o&&13.bq)?6:((13.8o)?5:4):("2y"==a.V.34)?((a.V.6b.8x)?((a.V.6b.6q)?bs:9q):bt):("8l"==a.V.34)?!!(1d.5G)?6a:!!1d.5J?bA:!!(13.87)?bB:((1d.4Z)?bJ:bK):"";a.V[a.V.34]=a.V[a.V.34+a.V.3A]=19;N(13.89){a.V.89=19}a.V.2u=(!a.V.2L)?0:(1d.85)?1d.85:R(){U e=0;N(a.V.3V){Q 5}31(a.V.3A){1p 4:e=6;1n;1p 5:e=7;1n;1p 6:e=8;1n;1p 84:e=9;1n}Q e}()})();(R(){a.V.21={2F:X,5y:R(){Q X},7r:R(){},8g:R(){},83:"",8b:"",1V:""};N(39 1d.8d!="1m"){a.V.21.2F=19}1e{U f="2y bL o 6m bM".5T(" ");1q(U e=0,d=f.1w;e<d;e++){a.V.21.1V=f[e];N(39 1d[a.V.21.1V+"8f"]!="1m"){a.V.21.2F=19;1n}}}N(a.V.21.2F){a.V.21.83=a.V.21.1V+"bI";a.V.21.8b=a.V.21.1V+"bH";a.V.21.5y=R(){31(M.1V){1p"":Q 1d.21;1p"2y":Q 1d.bD;3h:Q 1d[M.1V+"bC"]}};a.V.21.7r=R(g){Q(M.1V==="")?g.8e():g[M.1V+"bE"]()};a.V.21.8g=R(g){Q(M.1V==="")?1d.8d():1d[M.1V+"8f"]()}}})();a.2a={6C:R(d){Q M.2X.2r(d," ")},2d:R(d){N(d&&!M.6C(d)){M.2X+=(M.2X?" ":"")+d}Q M},4C:R(d){d=d||".*";M.2X=M.2X.3P(1A 7n("(^|\\\\s)"+d+"(?:\\\\s|$)"),"$1").5P();Q M},bF:R(d){Q M.6C(d)?M.4C(d):M.2d(d)},2v:R(f){f=(f=="6o"&&M.4X)?"7l":f.2g();U d=1c,e=1c;N(M.4X){d=M.4X[f]}1e{N(1d.6D&&1d.6D.7I){e=1d.6D.7I(M,1c);d=e?e.bG([f.9n()]):1c}}N(!d){d=M.1l[f]}N("1C"==f){Q a.1O(d)?2T(d):1}N(/^(24(6V|6k|6X|6W)7K)|((1P|3z)(6V|6k|6X|6W))$/.1z(f)){d=2i(d)?d:"1B"}Q("22"==d?1c:d)},2J:R(f,d){2z{N("1C"==f){M.1Y(d);Q M}1e{N("6o"==f){M.1l[("1m"===39(M.1l.7l))?"cf":"7l"]=d;Q M}1e{N(a.V.4a&&/8j/.1z(f)){}}}M.1l[f.2g()]=d+(("7q"==a.27(d)&&!$12(["54","1k"]).3n(f.2g()))?"1i":"")}30(g){}Q M},1f:R(e){1q(U d 1I e){M.2J(d,e[d])}Q M},at:R(){U d={};a.$A(1D).2A(R(e){d[e]=M.2v(e)},M);Q d},1Y:R(h,e){e=e||X;h=2T(h);N(e){N(h==0){N("2h"!=M.1l.2w){M.1l.2w="2h"}}1e{N("46"!=M.1l.2w){M.1l.2w="46"}}}N(a.V.2L){N(!M.4X||!M.4X.an){M.1l.1k=1}2z{U g=M.am.6p("7V.9t.9Q");g.5y=(1!=h);g.1C=h*1H}30(d){M.1l.44+=(1==h)?"":"al:7V.9t.9Q(5y=19,1C="+h*1H+")"}}M.1l.1C=h;Q M},9U:R(d){1q(U e 1I d){M.af(e,""+d[e])}Q M},26:R(){Q M.1f({3I:"3T",2w:"2h"})},1X:R(){Q M.1f({3I:"3H",2w:"46"})},1E:R(){Q{S:M.ai,W:M.ah}},5g:R(){Q{17:M.5K,18:M.5N}},ag:R(){U d=M,e={17:0,18:0};do{e.18+=d.5N||0;e.17+=d.5K||0;d=d.1x}3b(d);Q e},4c:R(){N(a.1O(1d.5D.9z)){U d=M.9z(),f=$12(1d).5g(),h=a.V.2E();Q{17:d.17+f.y-h.aa,18:d.18+f.x-h.ab}}U g=M,e=t=0;do{e+=g.a9||0;t+=g.ak||0;g=g.aq}3b(g&&!(/^(?:23|ar)$/i).1z(g.3s));Q{17:t,18:e}},67:R(){U e=M.4c();U d=M.1E();Q{17:e.17,1g:e.17+d.W,18:e.18,1j:e.18+d.S}},6j:R(f){2z{M.91=f}30(d){M.as=f}Q M},3w:R(){Q(M.1x)?M.1x.2R(M):M},5j:R(){a.$A(M.ao).2A(R(d){N(3==d.3m||8==d.3m){Q}$12(d).5j()});M.3w();M.8V();N(M.$3t){a.52[M.$3t]=1c;5E a.52[M.$3t]}Q 1c},5C:R(g,e){e=e||"1g";U d=M.1W;("17"==e&&d)?M.5B(g,d):M.1M(g);Q M},2D:R(f,e){U d=$12(f).5C(M,e);Q M},ae:R(d){M.5C(d.1x.99(M,d));Q M},7o:R(d){N("69"!==a.27("3Z"==a.27(d)?d=1d.9C(d):d)){Q X}Q(M==d)?X:(M.3n&&!(a.V.9o))?(M.3n(d)):(M.9I)?!!(M.9I(d)&16):a.$A(M.4U(d.3s)).3n(d)}};a.2a.4i=a.2a.2v;a.2a.ac=a.2a.1f;N(!13.2a){13.2a=a.$F;N(a.V.34.2y){13.1d.2Z("aj")}13.2a.1N=(a.V.34.2y)?13["[[ap.1N]]"]:{}}a.63(13.2a,{$2I:"69"});a.42={1E:R(){N(a.V.ch||a.V.9o){Q{S:13.8G,W:13.8F}}Q{S:a.V.2E().dP,W:a.V.2E().dQ}},5g:R(){Q{x:13.dO||a.V.2E().5N,y:13.dN||a.V.2E().5K}},dK:R(){U d=M.1E();Q{S:1o.3c(a.V.2E().dL,d.S),W:1o.3c(a.V.2E().dM,d.W)}}};a.1G(1d,{$2I:"1d"});a.1G(13,{$2I:"13"});a.1G([a.2a,a.42],{2S:R(g,e){U d=a.5k(M.$3t),f=d[g];N(1m!=e&&1m==f){f=d[g]=e}Q(a.1O(f)?f:1c)},76:R(f,e){U d=a.5k(M.$3t);d[f]=e;Q M},8W:R(e){U d=a.5k(M.$3t);5E d[e];Q M}});N(!(13.7s&&13.7s.1N&&13.7s.1N.4Z)){a.1G([a.2a,a.42],{4Z:R(d){Q a.$A(M.56("*")).44(R(g){2z{Q(1==g.3m&&g.2X.2r(d," "))}30(f){}})}})}a.1G([a.2a,a.42],{dR:R(){Q M.4Z(1D[0])},4U:R(){Q M.56(1D[0])}});N(a.V.21.2F){a.2a.8e=R(){a.V.21.7r(M)}}a.7j={$2I:"3e",1K:R(){N(M.8c){M.8c()}1e{M.8h=19}N(M.6N){M.6N()}1e{M.dS=X}Q M},4v:R(){U e,d;e=((/4M/i).1z(M.29))?M.5V[0]:M;Q(!a.1O(e))?{x:0,y:0}:{x:e.dY||e.7g+a.V.2E().5N,y:e.dZ||e.71+a.V.2E().5K}},98:R(){U d=M.dX||M.dW;3b(d&&3==d.3m){d=d.1x}Q d},5r:R(){U e=1c;31(M.29){1p"2c":e=M.7N||M.dT;1n;1p"3a":e=M.7N||M.e1;1n;3h:Q e}2z{3b(e&&3==e.3m){e=e.1x}}30(d){e=1c}Q e},5f:R(){N(!M.9K&&M.5H!==1m){Q(M.5H&1?1:(M.5H&2?3:(M.5H&4?2:0)))}Q M.9K}};a.77="9v";a.7k="dV";a.5t="";N(!1d.9v){a.77="dJ";a.7k="dI";a.5t="3Y"}a.1G([a.2a,a.42],{1v:R(g,f){U i=("3Q"==g)?X:19,e=M.2S("4I",{});e[g]=e[g]||{};N(e[g].5l(f.$4F)){Q M}N(!f.$4F){f.$4F=1o.6e(1o.6f()*a.2N())}U d=M,h=R(j){Q f.1L(d)};N("3Q"==g){N(a.V.1T){f.1L(M);Q M}}N(i){h=R(j){j=a.1G(j||13.e,{$2I:"3e"});Q f.1L(d,$12(j))};M[a.77](a.5t+g,h,X)}e[g][f.$4F]=h;Q M},1Z:R(g){U i=("3Q"==g)?X:19,e=M.2S("4I");N(!e||!e[g]){Q M}U h=e[g],f=1D[1]||1c;N(g&&!f){1q(U d 1I h){N(!h.5l(d)){4V}M.1Z(g,d)}Q M}f=("R"==a.27(f))?f.$4F:f;N(!h.5l(f)){Q M}N("3Q"==g){i=X}N(i){M[a.7k](a.5t+g,h[f],X)}5E h[f];Q M},9S:R(h,f){U m=("3Q"==h)?X:19,l=M,j;N(!m){U g=M.2S("4I");N(!g||!g[h]){Q M}U i=g[h];1q(U d 1I i){N(!i.5l(d)){4V}i[d].1L(M)}Q M}N(l===1d&&1d.5o&&!l.8L){l=1d.5D}N(1d.5o){j=1d.5o(h);j.dx(f,19,19)}1e{j=1d.dy();j.dw=h}N(1d.5o){l.8L(j)}1e{l.dv("3Y"+f,j)}Q j},8V:R(){U d=M.2S("4I");N(!d){Q M}1q(U e 1I d){M.1Z(e)}M.8W("4I");Q M}});(R(){N("5Z"===1d.5J){Q a.V.2t.2n(1)}N(a.V.2y&&a.V.3A<9q){(R(){($12(["ds","5Z"]).3n(1d.5J))?a.V.2t():1D.5u.2n(50)})()}1e{N(a.V.2L&&a.V.2u<9&&13==17){(R(){(a.$2z(R(){a.V.2E().dt("18");Q 19}))?a.V.2t():1D.5u.2n(50)})()}1e{$12(1d).1v("du",a.V.2t);$12(13).1v("2k",a.V.2t)}}})();a.3W=R(){U h=1c,e=a.$A(1D);N("43"==a.27(e[0])){h=e.4G()}U d=R(){1q(U l 1I M){M[l]=a.3U(M[l])}N(M.2W.$2M){M.$2M={};U o=M.2W.$2M;1q(U n 1I o){U j=o[n];31(a.27(j)){1p"R":M.$2M[n]=a.3W.9M(M,j);1n;1p"6v":M.$2M[n]=a.3U(j);1n;1p"49":M.$2M[n]=a.3U(j);1n}}}U i=(M.3r)?M.3r.35(M,1D):M;5E M.6J;Q i};N(!d.1N.3r){d.1N.3r=a.$F}N(h){U g=R(){};g.1N=h.1N;d.1N=1A g;d.$2M={};1q(U f 1I h.1N){d.$2M[f]=h.1N[f]}}1e{d.$2M=1c}d.2W=a.3W;d.1N.2W=d;a.1G(d.1N,e[0]);a.1G(d,{$2I:"43"});Q d};b.3W.9M=R(d,e){Q R(){U g=M.6J;U f=e.35(d,1D);Q f}};a.6G=$12(13);a.9s=$12(1d)})();(R(b){N(!b){6F"9x 9J 9H";Q}N(b.2C){Q}U a=b.$;b.2C=1A b.3W({P:{58:60,4f:8J,7w:R(c){Q-(1o.6n(1o.6B*c)-1)/2},9E:b.$F,4n:b.$F,8u:b.$F,8v:b.$F,5a:X,8t:19},3x:1c,3r:R(d,c){M.el=a(d);M.P=b.1G(M.P,c);M.36=X},2b:R(c){M.3x=c;M.9N=0;M.dz=0;M.6S=b.2N();M.7S=M.6S+M.P.4f;M.6r=M.6U.1S(M);M.P.9E.1L();N(!M.P.5a&&b.V.3C){M.36=b.V.3C.1L(13,M.6r)}1e{M.36=M.6U.1S(M).9F(1o.33(7x/M.P.58))}Q M},6Q:R(){N(M.36){N(!M.P.5a&&b.V.3C&&b.V.66){b.V.66.1L(13,M.36)}1e{dA(M.36)}M.36=X}},1K:R(c){c=b.1O(c)?c:X;M.6Q();N(c){M.3X(1);M.P.4n.2n(10)}Q M},6s:R(e,d,c){Q(d-e)*c+e},6U:R(){U d=b.2N();N(d>=M.7S){M.6Q();M.3X(1);M.P.4n.2n(10);Q M}U c=M.P.7w((d-M.6S)/M.P.4f);N(!M.P.5a&&b.V.3C){M.36=b.V.3C.1L(13,M.6r)}M.3X(c)},3X:R(c){U d={};1q(U e 1I M.3x){N("1C"===e){d[e]=1o.33(M.6s(M.3x[e][0],M.3x[e][1],c)*1H)/1H}1e{d[e]=M.6s(M.3x[e][0],M.3x[e][1],c);N(M.P.8t){d[e]=1o.33(d[e])}}}M.P.8u(d);M.7Z(d);M.P.8v(d)},7Z:R(c){Q M.el.1f(c)}});b.2C.3q={dG:R(c){Q c},86:R(c){Q-(1o.6n(1o.6B*c)-1)/2},dH:R(c){Q 1-b.2C.3q.86(1-c)},88:R(c){Q 1o.3o(2,8*(c-1))},dF:R(c){Q 1-b.2C.3q.88(1-c)},80:R(c){Q 1o.3o(c,2)},dE:R(c){Q 1-b.2C.3q.80(1-c)},8a:R(c){Q 1o.3o(c,3)},dB:R(c){Q 1-b.2C.3q.8a(1-c)},8k:R(d,c){c=c||1.dC;Q 1o.3o(d,2)*((c+1)*d-c)},dD:R(d,c){Q 1-b.2C.3q.8k(1-d)},96:R(d,c){c=c||[];Q 1o.3o(2,10*--d)*1o.6n(20*d*1o.6B*(c[0]||1)/3)},e0:R(d,c){Q 1-b.2C.3q.96(1-d,c)},9Z:R(e){1q(U d=0,c=1;1;d+=c,c/=2){N(e>=(7-4*d)/11){Q c*c-1o.3o((11-6*d-11*e)/4,2)}}},eh:R(c){Q 1-b.2C.3q.9Z(1-c)},3T:R(c){Q 0}}})(4L);(R(b){N(!b){6F"9x 9J 9H";Q}N(b.7t){Q}U a=b.$;b.7t=1A b.3W(b.2C,{3r:R(c,d){M.6w=c;M.P=b.1G(M.P,d);M.36=X},2b:R(c){M.$2M.2b([]);M.8H=c;Q M},3X:R(c){1q(U d=0;d<M.6w.1w;d++){M.el=a(M.6w[d]);M.3x=M.8H[d];M.$2M.3X(c)}}})})(4L);U 6R=(R(c){U d=c.$;c.$62=R(f){$12(f).1K();Q X};c.9G=R(f,h,l){U i,g,j,k=[],e=-1;l||(l=c.ei);i=c.$(l)||(1d.5G||1d.23).1M(c.$1A("1l",{1U:l,29:"8y/6z"}));g=i.ej||i.en;N("6v"==c.27(h)){1q(j 1I h){k.4y(j+":"+h[j])}h=k.em(";")}N(g.6u){e=g.6u(f+" {"+h+"}",g.ek.1w)}1e{e=g.ec(f,h)}Q e};U a={3A:"ed.5.28",P:{},5I:{1C:50,3g:X,7f:40,58:25,1r:4K,1u:4K,4j:15,1F:"1j",4B:"17",9Y:"6L",3y:X,5i:19,3F:X,4o:X,x:-1,y:-1,4k:X,9A:X,2p:"2k",5A:19,3i:"17",5h:"2l",8Q:19,7H:6i,7Y:6a,2O:"",1t:19,55:"7B",5z:"8C",97:75,9f:"e7",5W:19,9c:"eb 1k...",9b:"e8",9e:75,6c:-1,6P:-1,3J:"1J",9p:60,3B:"8w",7G:6i,94:19,8P:X,4W:"",8O:19,51:X,5b:X,3N:X,a6:"",2t:c.$F},7z:$12([/^(1C)(\\s+)?:(\\s+)?(\\d+)$/i,/^(1C-e6)(\\s+)?:(\\s+)?(19|X)$/i,/^(5A\\-5F)(\\s+)?:(\\s+)?(\\d+)$/i,/^(58)(\\s+)?:(\\s+)?(\\d+)$/i,/^(1k\\-S)(\\s+)?:(\\s+)?(\\d+\\%?)(1i)?/i,/^(1k\\-W)(\\s+)?:(\\s+)?(\\d+\\%?)(1i)?/i,/^(1k\\-eg)(\\s+)?:(\\s+)?(\\d+)(1i)?/i,/^(1k\\-1y)(\\s+)?:(\\s+)?(1j|18|17|1g|3j|2j|#([a-5x-65\\-:\\.]+))$/i,/^(1k\\-eo)(\\s+)?:(\\s+)?(1j|18|17|1g|5X)$/i,/^(1k\\-8n\\-e4)(\\s+)?:(\\s+)?(19|X)$/i,/^(1k\\-13\\-6t)(\\s+)?:(\\s+)?(6L|9R|X)$/i,/^(ee\\-ef)(\\s+)?:(\\s+)?(19|X)$/i,/^(e5\\-3Y\\-1J)(\\s+)?:(\\s+)?(19|X)$/i,/^(ea\\-1X\\-1k)(\\s+)?:(\\s+)?(19|X)$/i,/^(e9\\-1y)(\\s+)?:(\\s+)?(19|X)$/i,/^(x)(\\s+)?:(\\s+)?([\\d.]+)(1i)?/i,/^(y)(\\s+)?:(\\s+)?([\\d.]+)(1i)?/i,/^(1J\\-6l\\-4e)(\\s+)?:(\\s+)?(19|X)$/i,/^(1J\\-6l\\-e2)(\\s+)?:(\\s+)?(19|X)$/i,/^(8B\\-3Y)(\\s+)?:(\\s+)?(2k|1J|2c)$/i,/^(1J\\-6l\\-8B)(\\s+)?:(\\s+)?(19|X)$/i,/^(5A)(\\s+)?:(\\s+)?(19|X)$/i,/^(1X\\-2l)(\\s+)?:(\\s+)?(19|X|17|1g)$/i,/^(2l\\-e3)(\\s+)?:(\\s+)?(2l|#([a-5x-65\\-:\\.]+))$/i,/^(1k\\-4O)(\\s+)?:(\\s+)?(19|X)$/i,/^(1k\\-4O\\-1I\\-5F)(\\s+)?:(\\s+)?(\\d+)$/i,/^(1k\\-4O\\-dU\\-5F)(\\s+)?:(\\s+)?(\\d+)$/i,/^(2O)(\\s+)?:(\\s+)?([a-5x-65\\-:\\.]+)$/i,/^(1t)(\\s+)?:(\\s+)?(19|X)/i,/^(1t\\-8y)(\\s+)?:(\\s+)?([^;]*)$/i,/^(1t\\-1C)(\\s+)?:(\\s+)?(\\d+)$/i,/^(1t\\-1y)(\\s+)?:(\\s+)?(8C|9m|9g|bl|br|bc)/i,/^(1X\\-5c)(\\s+)?:(\\s+)?(19|X)$/i,/^(5c\\-dq)(\\s+)?:(\\s+)?([^;]*)$/i,/^(5c\\-1C)(\\s+)?:(\\s+)?(\\d+)$/i,/^(5c\\-1y\\-x)(\\s+)?:(\\s+)?(\\d+)(1i)?/i,/^(5c\\-1y\\-y)(\\s+)?:(\\s+)?(\\d+)(1i)?/i,/^(cE\\-8E)(\\s+)?:(\\s+)?(1J|2c)$/i,/^(2m\\-8E)(\\s+)?:(\\s+)?(1J|2c)$/i,/^(2m\\-2c\\-cF)(\\s+)?:(\\s+)?(\\d+)$/i,/^(2m\\-6t)(\\s+)?:(\\s+)?(8w|4O|78|X)$/i,/^(2m\\-6t\\-5F)(\\s+)?:(\\s+)?(\\d+)$/i,/^(2m\\-43)(\\s+)?:(\\s+)?([a-5x-65\\-:\\.]+)$/i,/^(8n\\-1k\\-13)(\\s+)?:(\\s+)?(19|X)$/i,/^(8s\\-2m\\-cD)(\\s+)?:(\\s+)?(19|X)$/i,/^(8s\\-2m\\-8N)(\\s+)?:(\\s+)?(19|X)$/i,/^(cC\\-cz)(\\s+)?:(\\s+)?(19|X)$/i,/^(1j\\-1J)(\\s+)?:(\\s+)?(19|X)$/i,/^(cA\\-1k)(\\s+)?:(\\s+)?(19|X)$/i,/^(6z\\-43)(\\s+)?:(\\s+)?([^;]*)$/i,]),37:$12([]),9D:R(h){U g=/(1J|2c)/i;1q(U f=0;f<a.37.1w;f++){N(a.37[f].2e&&!a.37[f].4z){a.37[f].4d()}1e{N(g.1z(a.37[f].P.2p)&&a.37[f].4l){a.37[f].4l=h}}}},1K:R(f){U e=$12([]);N(f){N((f=$12(f))&&f.1k){e.4y(f)}1e{Q X}}1e{e=$12(c.$A(c.23.4U("A")).44(R(g){Q((" "+g.2X+" ").4b(/\\cB\\s/)&&g.1k)}))}e.2A(R(g){g.1k&&g.1k.1K()},M)},2b:R(e){N(0==1D.1w){a.6y();Q 19}e=$12(e);N(!e||!(" "+e.2X+" ").4b(/\\s(6R|cG)\\s/)){Q X}N(!e.1k){U f=1c;3b(f=e.1W){N(f.3s=="6E"){1n}e.2R(f)}3b(f=e.cH){N(f.3s=="6E"){1n}e.2R(f)}N(!e.1W||e.1W.3s!="6E"){6F"cN cO 7B"}a.37.4y(1A a.1k(e,(1D.1w>1)?1D[1]:1m))}1e{e.1k.2b()}},2K:R(h,e,g,f){N((h=$12(h))&&h.1k){(1c===e||""===e)&&(e=1m);(1c===g||""===g)&&(g=1m);h.1k.2K(e,g,f);Q 19}Q X},6y:R(){c.$A(13.1d.56("A")).2A(R(e){N(e.2X.2r("6R"," ")){N(a.1K(e)){a.2b.2n(1H,e)}1e{a.2b(e)}}},M)},1X:R(e){Q a.7E(e)},7E:R(e){N((e=$12(e))&&e.1k){Q e.1k.4e()}Q X},cM:R(e){N((e=$12(e))&&e.1k){Q e.1k.4d()}Q X},cL:R(e){N((e=$12(e))&&e.1k){Q{x:e.1k.P.x,y:e.1k.P.y}}},8Z:R(g){U f,e;f="";1q(e=0;e<g.1w;e++){f+=6T.cI(14^g.cJ(e))}Q f}};a.45=R(){M.3r.35(M,1D)};a.45.1N={3r:R(e){M.cb=1c;M.3l=1c;M.6I=M.7O.3d(M);M.64=1c;M.S=0;M.W=0;M.61=0;M.68=0;M.24={18:0,1j:0,17:0,1g:0};M.1P={18:0,1j:0,17:0,1g:0};M.1T=X;M.3R=1c;N("3Z"==c.27(e)){M.3R=c.$1A("4D").2d("a3-cK-5e").1f({1y:"2o",17:"-cy",S:"7F",W:"7F",3v:"2h"}).2D(c.23);M.T=c.$1A("5e").2D(M.3R);M.5Y();M.T.1R=e}1e{M.T=$12(e);M.5Y();M.T.1R=e.1R}},4N:R(){N(M.3R){N(M.T.1x==M.3R){M.T.3w().1f({1y:"cx",17:"22"})}M.3R.5j();M.3R=1c}},7O:R(f){N(f){$12(f).1K()}N(M.cb){M.4N();M.cb.1L(M,X)}M.3G()},5Y:R(e){M.3l=1c;N(e==19||!(M.T.1R&&(M.T.5Z||M.T.5J=="5Z"))){M.3l=R(f){N(f){$12(f).1K()}N(M.1T){Q}M.1T=19;M.3k();N(M.cb){M.4N();M.cb.1L()}}.3d(M);M.T.1v("2k",M.3l);$12(["8r","a8"]).2A(R(f){M.T.1v(f,M.6I)},M)}1e{M.1T=19}},2K:R(f,h){U g=M.1T;M.3G();U e=c.$1A("a",{1Q:f});N(19!==h&&M.T.1R.2r(e.1Q)&&0!==M.T.S){M.1T=g}1e{M.5Y(19);M.T.1R=f}e=1c},3k:R(){M.61=M.T.61||M.T.S;M.68=M.T.68||M.T.W;M.S=M.T.S;M.W=M.T.W;N(M.S==0&&M.W==0&&c.V.2y){M.S=M.T.61;M.W=M.T.68}$12(["6X","6W","6V","6k"]).2A(R(f){M.1P[f.2H()]=M.T.4i("1P"+f).4r();M.24[f.2H()]=M.T.4i("24"+f+"7K").4r()},M);N(c.V.6O||(c.V.2L&&!c.V.3V)){M.S-=M.1P.18+M.1P.1j;M.W-=M.1P.17+M.1P.1g}},5s:R(){U e=1c;e=M.T.67();Q{17:e.17+M.24.17,1g:e.1g-M.24.1g,18:e.18+M.24.18,1j:e.1j-M.24.1j}},cm:R(){N(M.64){M.64.1R=M.T.1R;M.T=1c;M.T=M.64}},2k:R(e){N(M.1T){N(!M.S){(R(){M.3k();M.4N();e.1L()}).1S(M).2n(1)}1e{M.4N();e.1L()}}1e{N(!M.3l){e.1L(M,X);Q}M.cb=e}},3G:R(){N(M.3l){M.T.1Z("2k",M.3l)}$12(["8r","a8"]).2A(R(e){M.T.1Z(e,M.6I)},M);M.3l=1c;M.cb=1c;M.S=1c;M.1T=X;M.cn=X}};a.1k=R(){M.7v.35(M,1D)};a.1k.1N={7v:R(h,f,g){U e={};M.3f=-1;M.2e=X;M.4J=0;M.4E=0;M.5O=!(M.Y);M.5m=M.5O?{}:M.5m||{};M.4z=X;M.2G=1c;M.6Y=$12(13).2S("3L:8I")||$12(13).2S("3L:8I",c.$1A("4D").1f({1y:"2o",17:-cl,S:10,W:10,3v:"2h"}).2D(c.23));M.P=c.3U(a.5I);N(h){M.c=$12(h)}M.3p=("4D"==M.c.3s.2H());e=c.1G(e,M.5U());e=c.1G(e,M.5U(M.c.59));e=c.1G(e,M.5m);N(f){e=c.1G(e,c.1G(19===g?M.5m:{},M.5U(f)))}N(e.3y&&!e.4k&&1m===e.3F){e.3F=19}c.1G(M.P,e);M.P.2O+="";N("2k"==M.P.2p&&c.1O(M.P.9B)&&"19"==M.P.9B.48()){M.P.2p="1J"}N(c.1O(M.P.6H)&&M.P.6H!=M.P.3J){M.P.3J=M.P.6H}N(c.V.4u){N(13.9u&&13.9u("(3c-S: ck)").dr){M.P.1F="2j";M.P.4k=19}}N(M.5O&&!M.3p){M.1U=M.5q=M.c.1U||"";N(!M.c.1U){M.c.1U=M.1U="1k-"+1o.6e(1o.6f()*c.2N())}}N("2j"==M.P.1F&&M.P.3y){M.P.5i=19}N(M.P.3N){M.2e=X;M.P.4k=19;M.P.1t=X}("3Z"===c.27(M.P.2t))&&("R"===c.27(13[M.P.2t]))&&(M.P.2t=13[M.P.2t]);N(h){M.41=1c;M.4R=M.7i.3d(M);M.6K=M.7a.3d(M);M.74=M.1X.1S(M,19);M.8T=M.9a.1S(M);M.2Y=M.4T.3d(M);M.7d=R(k){U j=$12(M.c).2S("3L:13:6Z"),i=$12(13).1E();N(j.S!==i.S||j.W!==i.W){4p(M.9w);M.9w=M.8p.1S(M).2n(10);$12(M.c).76("3L:13:6Z",i)}}.3d(M);N(!M.3p){M.c.1v("1J",R(j){U i=j.5f();N(3==i){Q 19}$12(j).1K();N(!c.V.2L){M.9d()}Q X})}M.c.1v("7i",M.4R);M.c.1v("7a",M.6K);N("2c"==M.P.2p){M.c.1v("2c",M.4R)}N(c.V.4u){M.c.1f({"-2y-ci-cj":"3T","-2y-4M-co":"3T","-2y-cp-cv-4w":"cw"});N(!M.P.3N){M.c.1v("7p",M.4R);M.c.1v("57",M.6K)}1e{M.c.1v("1J",R(i){i.6N()})}}M.c.82="3Y";M.c.1l.cu="3T";M.c.1v("ct",c.$62);N(!M.3p){M.c.1f({1y:"4t",3I:(c.V.cq)?"3H":"9k-3H",cg:"3T",9j:"0",81:"cr",3v:"2h"});N(c.V.2u){M.c.2d("a3-1q-cs"+c.V.2u)}N(M.c.2v("8X")=="5X"){M.c.1f({3z:"22 22"})}}M.c.1k=M}1e{M.P.2p="2k"}N(!M.P.5b){M.c.1v("8M",c.$62)}N("2k"==M.P.2p){M.4Q()}1e{N(""!==M.5q){M.7m(19)}}},4Q:R(){U j,m,l,k,h;N(!M.1b){M.1b=1A a.45(M.c.1W);M.1h=1A a.45(M.c.1Q)}1e{M.1h.2K(M.c.1Q)}N(!M.Y){M.Y={T:$12(1d.2Z("47")).2d("cP").2d(M.P.a6).1f({3v:"2h",54:M.P.1F=="2j"?1H:cQ,17:"-5S",1y:"2o",S:M.P.1r+"1i",W:M.P.1u+"1i"}),1k:M,2B:"1B",5R:"1B",4Y:0,53:0,3E:{2x:"18",4m:1},3D:{2x:"17",4m:1},3j:X,3O:M.P.1r,3S:M.P.1u};N("2j"==M.P.1F){M.Y.T.2d("2j-1k")}N(!(c.V.de&&c.V.2u<9)&&"2j"!=M.P.1F){31(M.P.9Y){1p"6L":M.Y.T.2d("df");1n;1p"9R":M.Y.T.2d("dd");1n;3h:1n}}M.Y.26=R(){N(!M.T){Q}N(M.T.1l.17!="-5S"&&M.1k.1a&&!M.1k.1a.32){M.T.1l.17="-5S"}N(M.T.1x===c.23){M.T.2D(M.1k.6Y)}};M.Y.7D=M.Y.26.1S(M.Y);N(c.V.70){j=$12(1d.2Z("dc"));j.1R="d9:\'\'";j.1f({18:"1B",17:"1B",1y:"2o","z-2V":-1}).da=0;M.Y.4P=M.Y.T.1M(j)}M.Y.2P=$12(1d.2Z("47")).2d("db").1f({1y:"4t",54:10,18:"1B",17:"1B",1P:"dg"}).26();m=c.$1A("47",{},{3v:"2h"});m.1M(M.1h.T);M.1h.T.1f({1P:"1B",3z:"1B",24:"1B",S:"22",W:"22"});N(M.P.3i=="1g"){M.Y.T.1M(m);M.Y.T.1M(M.Y.2P)}1e{M.Y.T.1M(M.Y.2P);M.Y.T.1M(m)}M.Y.T.2D(M.6Y);N("1m"!==39(h)){M.Y.g=$12(1d.2Z("4D")).1f({4w:h[1],dh:h[2]+"1i",dn:h[3],dp:"dm",1y:"2o","z-2V":10+(""+(M.1h.T.2v("z-2V")||0)).4r(),S:h[5],8X:h[4],"dl-W":"di",18:"1B"}).6j(a.8Z(h[0])).2D(M.Y.T,((1o.6e(1o.6f()*dj)+1)%2)?"17":"1g")}}M.Y.3O=M.P.1r;M.Y.3S=M.P.1u;M.Y.3j=X;N(M.P.3i!="X"&&M.P.3i!=X){U i=M.Y.2P;i.26();3b(l=i.1W){i.2R(l)}N(M.P.5h=="2l"&&""!=M.c.2l){i.1M(1d.5w(M.c.2l));i.1X()}1e{N(M.P.5h.2r("#")){U n=M.P.5h.3P(/^#/,"");N($12(n)){i.6j($12(n).91);i.1X()}}}}1e{M.Y.2P.26()}M.c.9V=M.c.2l;M.c.2l="";M.1b.2k(M.8U.1S(M))},8U:R(e){N(!e&&e!==1m){Q}N(!M.1b){Q}N(!M.P.3g){M.1b.T.1Y(1)}N(!M.3p){M.c.1f({S:"22",W:"22"})}N(M.P.5W&&!M.P.3N){M.4S=4s(M.8T,6i)}N(M.P.2O!=""&&$12(M.P.2O)){M.dk()}N(M.c.1U!=""){M.7m()}M.1h.2k(M.6h.1S(M))},6h:R(h){U g,f,i,e;N(!h&&h!==1m){4p(M.4S);N(M.P.5W&&M.2s){M.2s.26()}M.3f=c.2N();Q}N(!M.1b||!M.1h){Q}f=M.1b.T.67();M.5Q=f;N(f.1g==f.17){M.6h.1S(M).2n(8J);Q}i=("3j"==M.P.1F)?M.c.1U+"-8N":M.P.1F.2r("#")?M.P.1F.3P(/^#/,""):1c;N(i&&$12(i)){M.Y.3j=19;$12(i).1M(M.Y.T)}1e{N("2j"==M.P.1F){M.c.1M(M.Y.T)}}M.1b.3k();M.1h.3k();N(M.1b.S==0&&c.V.2L){!M.3p&&M.c.1f({S:M.1b.S+"1i"})}g=M.Y.2P.1E();N(/%$/i.1z(M.P.1r)){M.P.1r=(2i(M.P.1r)/1H)*M.1b.S}N(/%$/i.1z(M.P.1u)){M.P.1u=(2i(M.P.1u)/1H)*M.1b.W}M.Y.T.1f({S:M.P.1r});g=M.Y.2P.1E();N(M.P.8O||M.P.51){N((M.1h.S<M.P.1r)||M.P.51){M.P.1r=M.1h.S;M.Y.T.1f({S:M.P.1r});g=M.Y.2P.1E()}N((M.1h.W<M.P.1u)||M.P.51){M.P.1u=M.1h.W+g.W}}31(M.P.1F){1p"1j":M.Y.T.1l.18=f.1j+M.P.4j+"1i";M.Y.3E.2x="1j";1n;1p"18":M.Y.T.1l.18=f.18-M.P.4j-M.P.1r+"1i";1n;1p"17":M.Y.2B=f.17-(M.P.4j+M.P.1u)+"1i";1n;1p"1g":M.Y.2B=f.1g+M.P.4j+"1i";M.Y.3D.2x="1g";1n;1p"2j":M.Y.T.1f({18:"1B",W:"1H%",S:"1H%"});M.P.1r=M.1b.S;M.P.1u=M.1b.W;M.Y.2B="1B";g=M.Y.2P.1E();1n;3h:N(M.Y.3j){e=$12(M.Y.T.1x).1E();N(/%$/i.1z(M.Y.3O)){M.P.1r=(2i(M.Y.3O)/1H)*e.S}N(/%$/i.1z(M.Y.3S)){M.P.1u=(2i(M.Y.3S)/1H)*e.W}M.Y.T.1f({18:"1B",S:M.P.1r});M.Y.2B="1B";g=M.Y.2P.1E()}1n}N(M.P.3i=="1g"){$12(M.1h.T.1x).2J("W",M.P.1u-g.W)}M.Y.T.1f("2j"==M.P.1F?{}:{W:M.P.1u+"1i",S:M.P.1r+"1i"}).1Y(1);N(c.V.70&&M.Y.4P){M.Y.4P.1f({S:M.P.1r+"1i",W:M.P.1u+"1i"})}N(M.P.1F=="1j"||M.P.1F=="18"){N(M.P.4B=="5X"){M.Y.2B=(f.1g-(f.1g-f.17)/2-M.P.1u/2)+"1i";M.Y.3D={2x:"1g",4m:2}}1e{N(M.P.4B=="1g"){M.Y.2B=(f.1g-M.P.1u)+"1i";M.Y.3D.2x="1g"}1e{M.Y.2B=f.17+"1i"}}}1e{N(M.P.1F=="17"||M.P.1F=="1g"){N(M.P.4B=="5X"){M.Y.T.1l.18=(f.1j-(f.1j-f.18)/2-M.P.1r/2)+"1i";M.Y.3E={2x:"1j",4m:2}}1e{N(M.P.4B=="1j"){M.Y.T.1l.18=(f.1j-M.P.1r)+"1i";M.Y.3E.2x="1j"}1e{M.Y.T.1l.18=f.18+"1i"}}}}M.Y.4Y=2i(M.Y.2B,10);M.Y.53=2i(M.Y.T.1l.18,10);M.Y.5R=M.Y.53;M.Y.2B=M.Y.4Y;M.4q=M.P.1u-g.W;N(M.Y.g){M.Y.g.1f({17:M.P.3i=="1g"?0:"22",1g:M.P.3i=="1g"?"22":0})}M.1h.T.1f({1y:"4t",38:"1B",1P:"1B",18:"1B",17:"1B"});M.8q();N(M.P.3F){N(M.P.x==-1){M.P.x=M.1b.S/2}N(M.P.y==-1){M.P.y=M.1b.W/2}M.1X()}1e{N(M.P.8Q){M.2f=1A c.2C(M.Y.T,{5a:"95"===c.V.6d})}M.Y.T.1f({17:"-5S"})}N(M.P.5W&&M.2s){M.2s.26()}M.c.1v("6x",M.2Y);M.c.1v("3a",M.2Y);N(c.V.4u){M.c.1v("7p",M.2Y);M.c.1v("8S",M.2Y);M.c.1v("57",M.2Y)}M.9l();$12(M.c).2S("3L:13:6Z",$12(13).1E());$12(13).1v("92",M.7d);N(!M.P.3N&&(!M.P.4k||"1J"==M.P.2p)){M.2e=19}N("1J"==M.P.2p&&M.4l){M.4T(M.4l)}N(M.4z){M.4e()}M.3f=c.2N();!M.3p&&("R"==c.27(M.P.2t))&&M.P.2t.1L(1c,M.1U,!M.5O)},9l:R(){U i=/9m|br/i,e=/bl|br|bc/i,f=/bc|9g/i,h=1c;M.4g=1m;N(!M.P.1t){N(M.1t){M.1t.5j();M.1t=1m}Q}N(!M.1t){M.1t=$12(1d.2Z("47")).2d(M.P.9f).1f({3I:"3H",3v:"2h",1y:"2o",2w:"2h","z-2V":1});N(M.P.55!=""){M.1t.1M(1d.5w(M.P.55))}M.c.1M(M.1t)}1e{N(M.P.55!=""){h=M.1t[(M.1t.1W)?"99":"1M"](1d.5w(M.P.55),M.1t.1W);h=1c}}M.1t.1f({18:"22",1j:"22",17:"22",1g:"22",3I:"3H",1C:(M.P.97/1H),"3c-S":(M.1b.S-4)});U g=M.1t.1E();M.1t.2J((i.1z(M.P.5z)?"1j":"18"),(f.1z(M.P.5z)?(M.1b.S-g.S)/2:2)).2J((e.1z(M.P.5z)?"1g":"17"),2);M.4g=19;M.1t.1X()},9a:R(){N(M.1h.1T){Q}M.2s=$12(1d.2Z("47")).2d(M.P.9b).1Y(M.P.9e/1H).1f({3I:"3H",3v:"2h",1y:"2o",2w:"2h","z-2V":20,"3c-S":(M.1b.S-4)});M.2s.1M(1d.5w(M.P.9c));M.c.1M(M.2s);U e=M.2s.1E();M.2s.1f({18:(M.P.6c==-1?((M.1b.S-e.S)/2):(M.P.6c))+"1i",17:(M.P.6P==-1?((M.1b.W-e.W)/2):(M.P.6P))+"1i"});M.2s.1X()},7m:R(g){U e,h,f=1A 7n("1k\\\\-1U(\\\\s+)?:(\\\\s+)?"+M.c.1U+"($|;)");M.2m=$12([]);c.$A(1d.56("A")).2A(R(j){N(f.1z(j.59)){N(!$12(j).4x){j.4x=R(k){N(!c.V.2L){M.9d()}$12(k).1K();Q X};j.1v("1J",j.4x)}N(g){N(("2c"==M.P.2p||"1J"==M.P.2p)&&!$12(j).5v){j.5v=R(l,k){k.1Z("1J",k.5v);N(!!M.1b){Q}$12(l).1K();M.c.1Q=k.1Q;M.c.1W.1R=k.5d;M.2b(k.59)}.3d(M,j);j.1v("1J",j.5v)}Q}U i=c.$1A("a",{1Q:j.5d});(M.P.4W!="")&&$12(j)[M.1h.T.1R.2r(j.1Q)&&M.1b.T.1R.2r(i.1Q)?"2d":"4C"](M.P.4W);N(M.1h.T.1R.2r(j.1Q)&&M.1b.T.1R.2r(i.1Q)){M.41=j}i=1c;N(!j.3K){j.3K=R(m,l){l=m.d8||m.98();2z{3b("a"!=l.3s.2H()){l=l.1x}}30(k){Q}N(l.7o(m.5r())){Q}N(m.29=="3a"){N(M.3M){4p(M.3M)}M.3M=X;Q}N(l.2l!=""){M.c.2l=l.2l}N(m.29=="2c"){M.3M=4s(M.2K.1S(M,l.1Q,l.5d,l.59,l),M.P.9p)}1e{M.2K(l.1Q,l.5d,l.59,l)}}.3d(M);j.1v(M.P.3J,j.3K);N(M.P.3J=="2c"){j.1v("3a",j.3K)}}j.1f({9j:"0",3I:"9k-3H"});N(M.P.94){h=1A 8R();h.1R=j.5d}N(M.P.8P){e=1A 8R();e.1R=j.1Q}M.2m.4y(j)}},M)},1K:R(f){2z{N(M.Y){M.Y.26()}M.4d();M.c.1Z("6x",M.2Y);M.c.1Z("3a",M.2Y);N(c.V.4u){M.c.1Z("8S",M.2Y);M.c.1Z("57",M.2Y)}N(1m===f&&M.1a){M.1a.T.26()}N(M.2f){M.2f.1K()}M.1s=1c;M.2e=X;N(M.2m!==1m){M.2m.2A(R(e){N(M.P.4W!=""){e.4C(M.P.4W)}N(1m===f){e.1Z(M.P.3J,e.3K);N(M.P.3J=="2c"){e.1Z("3a",e.3K)}e.3K=1c;e.1Z("1J",e.4x);e.4x=1c}},M)}N(M.P.2O!=""&&$12(M.P.2O)){$12(M.P.2O).26();$12(M.P.2O).d7.5B($12(M.P.2O),$12(M.P.2O).cW);N(M.c.7e){M.c.2R(M.c.7e)}}N(M.P.3g){M.c.4C("8D");M.1b.T.1Y(1)}M.2f=1c;N(M.2s){M.c.2R(M.2s)}N(M.1t){M.1t.26()}N(1m===f){N(M.1t){M.c.2R(M.1t)}M.1t=1c;M.1h.3G();M.1b.3G();(M.1a&&M.1a.T)&&M.c.2R(M.1a.T);(M.Y&&M.Y.T)&&M.Y.T.1x.2R(M.Y.T);M.1a=1c;M.Y=1c;M.1h=1c;M.1b=1c;N(!M.P.5b){M.c.1Z("8M",c.$62)}N(""===M.5q){M.c.cX("1U")}1e{M.c.1U=M.5q}$12(13).1Z("92",M.7d)}N(M.4S){4p(M.4S);M.4S=1c}M.2G=1c;M.c.7e=1c;M.2s=1c;N(M.c.2l==""){M.c.2l=M.c.9V}M.3f=-1}30(g){}},2b:R(f,e){N(M.3f!=-1){Q}M.7v(X,f,(1c===e||1m===e))},2K:R(z,m,f,y){U g,C,e,j,v,h,E=1c,w=1c,k=M.41,n,l,o,B,u,q,s,F,D,p;y=y||1c;N(c.2N()-M.3f<4K||M.3f==-1||M.5M){M.3M&&4p(M.3M);g=4K-c.2N()+M.3f;N(M.3f==-1){g=4K}M.3M=4s(M.2K.1S(M,z,m,f,y),g);Q}N(y&&M.41==y){Q}1e{M.41=y}C=R(G){N(1m!=z){M.c.1Q=z}N(1m===f){f=""}N(M.P.4o){f="x: "+M.P.x+"; y: "+M.P.y+"; "+f}N(1m!=m){M.1b.2K(m)}N(G!==1m){M.1b.2k(G)}};M.1b.3k();j=M.1b.S;v=M.1b.W;M.1K(19);N(M.P.3B!="X"&&1m!==m){M.5M=19;U A=$12(M.c.5L(19)).1f({1y:"4t",17:0,18:0,S:""});U r=$12(M.c.1x).2v("S");U i=0;N("cV-9P"==$12(M.c.1x).2v("9P-cU")){i=(2i($12(M.c.1x).2v("1P-18"))||0)}U x=c.$1A("4D",{1U:M.c.1x.1U,"43":M.c.1x.2X}).2d("6A-7P-7T").1f({1P:$12(M.c.1x).2v("1P"),S:r,"3z-18":"-"+r,"3c-S":$12(M.c.1x).2v("3c-S")});N("cR"===M.c.1x.3s.cS()){x.1f({1P:0});M.c.1x.5B(x,M.c)}1e{M.c.1x.1x.5B(x,M.c.1x)}x.5C(A);c.V.2y&&x.1E();N(c.V.2u&&c.V.2u<8){$12(A.1W).1Y(1)}h=1A a.45(A.1W);h.2K(m);N("78"==M.P.3B){p=M.c.1Q;l=M.2m.44(R(G){Q G.1Q.2r(p)});l=(l[0])?$12(l[0].4U("5e")[0]||l[0]):M.1b.T;o=M.2m.44(R(G){Q G.1Q.2r(z)});o=(o[0])?$12(o[0].4U("5e")[0]||o[0]):1c;N(1c==o){o=M.1b.T;l=M.1b.T}u=M.1b.T.4c(),q=l.4c(),s=o.4c(),D=l.1E(),F=o.1E()}e=R(I){U G={},K={},J={},L=1c,H=1c;N(X===I){h.3G();$12(h.T).3w();h=1c;x.3w();M.5M=X;N(w){w.9N="cT"}M.41=k;M.2b(1c,k);Q}N(c.V.2u&&c.V.2u<8&&(j===h.S||0===h.S)){h.T.2J("1k",1);x.1E();h.3k()}N("78"==M.P.3B){G.S=[j,D.S];G.W=[v,D.W];G.17=[u.17,q.17];G.18=[u.18,q.18];K.S=[F.S,h.S];K.W=[F.W,h.W];K.17=[s.17,u.17];x.1f({1P:""});A.1Y(0).1f({W:0,S:h.S,1y:"4t",});K.18=[s.18,A.4c().18+2i(r)-i];J.S=[j,h.S];h.T.2D(c.23).1f({1y:"2o","z-2V":7L,18:K.18[0],17:K.17[0],S:K.S[0],W:K.W[0]});L=$12(M.c.1W.5L(X)).2D(c.23).1f({1y:"2o","z-2V":7M,18:G.18[0],17:G.17[0],2w:"46"});H=M.c.2v("24-S")}1e{h.T.2D(M.c).1f({1y:"2o","z-2V":7L,1C:0,18:"1B",17:"1B",W:"22"});L=$12(M.c.1W.5L(X)).2D(M.c).1f({1y:"2o","z-2V":7M,18:"1B",17:"1B",2w:"46",W:"22"});K={1C:[0,1]};N(j!=h.S||v!=h.W){J.S=K.S=G.S=[j,h.S];J.W=K.W=G.W=[v,h.W]}N(M.P.3B=="4O"){G.1C=[1,0]}}n=1A a.45(L);n.2k($12(R(){$12(M.c.1W).1f({2w:"2h"});x.3w();N(1c!==H){M.c.2J("24-S",0)}1A c.7t([M.c,h.T,(L||M.c.1W)],{4f:M.P.7G,4n:R(){N(L){L.3w();L=1c}N(1c!==H){M.c.2J("24-S",H)}C.1L(M,R(){h.3G();$12(M.c.1W).1f({2w:"46"});$12(h.T).3w();h=1c;N(G.1C){$12(M.c.1W).1f({1C:1})}M.5M=X;M.2b(f,y);N(E){E.2n(10)}}.1S(M))}.1S(M)}).2b([J,K,G])}).1S(M))};h.2k(e.1S(M))}1e{C.1L(M,R(){M.c.1f({S:M.1b.S+"1i",W:M.1b.W+"1i"});M.2b(f,y);N(E){E.2n(10)}}.1S(M))}},5U:R(f){U e,j,h,g;e=1c;j=[];f=f||"";N(""==f){1q(g 1I a.P){e=a.P[g];31(c.27(a.5I[g.2g()])){1p"7W":e=e.48().7C();1n;1p"7q":N(!("1r"===g.2g()||"1u"===g.2g())||!/\\%$/i.1z(e)){e=2T(e)}1n;3h:1n}j[g.2g()]=e}}1e{h=$12(f.5T(";"));h.2A(R(i){a.7z.2A(R(k){e=k.cY(i.5P());N(e){31(c.27(a.5I[e[1].2g()])){1p"7W":j[e[1].2g()]=e[4]==="19";1n;1p"7q":j[e[1].2g()]=(("1r"===e[1].2g()||"1u"===e[1].2g())&&/\\%$/.1z(e[4]))?e[4]:2T(e[4]);1n;3h:j[e[1].2g()]=e[4]}}},M)},M)}N(X===j.3B){j.3B="X"}Q j},8q:R(){U f,e;N(!M.1a){M.1a={T:$12(1d.2Z("47")).2d("8D").1f({54:10,1y:"2o",3v:"2h"}).26(),S:20,W:20,6g:""};M.c.1M(M.1a.T);M.1a.6g=M.1a.T.2v("7b-4w")}N(M.P.51){M.1a.T.1f({"24-S":"1B",81:"3h"})}M.1a.32=X;M.1a.W=M.4q/(M.1h.W/M.1b.W);M.1a.S=M.P.1r/(M.1h.S/M.1b.S);N(M.1a.S>M.1b.S){M.1a.S=M.1b.S}N(M.1a.W>M.1b.W){M.1a.W=M.1b.W}M.1a.S=1o.33(M.1a.S);M.1a.W=1o.33(M.1a.W);M.1a.38=M.1a.T.4i("7A").4r();M.1a.T.1f({S:(M.1a.S-2*(c.V.3V?0:M.1a.38))+"1i",W:(M.1a.W-2*(c.V.3V?0:M.1a.38))+"1i"});N(!M.P.3g&&!M.P.5b){M.1a.T.1Y(2T(M.P.1C/1H));N(M.1a.2q){M.1a.T.2R(M.1a.2q);M.1a.2q=1c}}1e{N(M.1a.2q){M.1a.2q.1R=M.1b.T.1R}1e{f=M.1b.T.5L(X);f.82="3Y";M.1a.2q=$12(M.1a.T.1M(f)).1f({1y:"2o",54:5})}N(M.P.3g){M.1a.2q.1f(M.1b.T.1E());M.1a.T.1Y(1);N(c.V.2u&&c.V.2u<9){M.1a.2q.1Y(1)}}1e{N(M.P.5b){M.1a.2q.1Y(0.cZ)}M.1a.T.1Y(2T(M.P.1C/1H))}}},4T:R(h,f){N(!M.2e||h===1m||h.d5){Q X}N(!M.1a){Q X}U i=(/4M/i).1z(h.29)&&h.7J.1w>1;U g=("57"==h.29&&!h.a1);N((!M.3p||h.29!="3a")&&!i){$12(h).1K()}N(f===1m){f=$12(h).4v()}N(M.1s===1c||M.1s===1m){M.1s=M.1b.5s()}N(g||("3a"==h.29&&M.c!==h.5r()&&!M.c.7o(h.5r()))||i||f.x>M.1s.1j||f.x<M.1s.18||f.y>M.1s.1g||f.y<M.1s.17){M.4d();Q X}M.4z=X;N(h.29=="3a"||h.29=="57"){Q X}N(M.P.3y&&!M.4h){Q X}N(!M.P.5i){f.x-=M.4J;f.y-=M.4E}N((f.x+M.1a.S/2)>=M.1s.1j){f.x=M.1s.1j-M.1a.S/2}N((f.x-M.1a.S/2)<=M.1s.18){f.x=M.1s.18+M.1a.S/2}N((f.y+M.1a.W/2)>=M.1s.1g){f.y=M.1s.1g-M.1a.W/2}N((f.y-M.1a.W/2)<=M.1s.17){f.y=M.1s.17+M.1a.W/2}M.P.x=f.x-M.1s.18;M.P.y=f.y-M.1s.17;N(M.2G===1c){M.2G=4s(M.74,10)}N(c.1O(M.4g)&&M.4g){M.4g=X;M.1t.26()}Q 19},1X:R(i){N(i&&!M.2G){Q}U o,l,h,g,n,m,k,j,f,e=M.P,p=M.1a;o=p.S/2;l=p.W/2;p.T.1l.18=e.x-o+M.1b.24.18+"1i";p.T.1l.17=e.y-l+M.1b.24.17+"1i";N(M.P.3g){p.2q.1l.18="-"+(2T(p.T.1l.18)+p.38)+"1i";p.2q.1l.17="-"+(2T(p.T.1l.17)+p.38)+"1i"}h=(M.P.x-o)*(M.1h.S/M.1b.S);g=(M.P.y-l)*(M.1h.W/M.1b.W);N(M.1h.S-h<e.1r){h=M.1h.S-e.1r;N(h<0){h=0}}N(M.1h.W-g<M.4q){g=M.1h.W-M.4q;N(g<0){g=0}}N(1d.5D.d6=="d4"){h=(e.x+p.S/2-M.1b.S)*(M.1h.S/M.1b.S)}h=1o.33(h);g=1o.33(g);N(e.5A===X||(!p.32)){M.1h.T.1l.18=(-h)+"1i";M.1h.T.1l.17=(-g)+"1i"}1e{n=2i(M.1h.T.1l.18);m=2i(M.1h.T.1l.17);k=(-h-n);j=(-g-m);N(!k&&!j){M.2G=1c;Q}k*=e.7f/1H;N(k<1&&k>0){k=1}1e{N(k>-1&&k<0){k=-1}}n+=k;j*=e.7f/1H;N(j<1&&j>0){j=1}1e{N(j>-1&&j<0){j=-1}}m+=j;M.1h.T.1l.18=n+"1i";M.1h.T.1l.17=m+"1i"}N(!p.32){N(M.2f){M.2f.1K();M.2f.P.4n=c.$F;M.2f.P.4f=e.7H;M.Y.T.1Y(0);M.2f.2b({1C:[0,1]})}N(/^(18|1j|17|1g)$/i.1z(e.1F)){M.Y.T.2D(c.23)}N(e.1F!="2j"){p.T.1X()}M.Y.T.1f(M.7u(/^(18|1j|17|1g)$/i.1z(e.1F)&&!M.P.3F));N(e.3g){M.c.2J("7b-4w",M.1a.6g);M.1b.T.1Y(2T((1H-e.1C)/1H))}p.32=19}N(M.2G){M.2G=4s(M.74,7x/e.58)}},7u:R(m){U f=M.8A(5),e=M.1b.T.67(),j=M.P.1F,i=M.Y,g=M.P.4j,n=i.T.1E(),l=i.4Y,h=i.53,k={18:i.53,17:i.4Y};N("2j"===j||M.Y.3j){Q k}m||(m=X);i.5R+=(e[i.3E.2x]-M.5Q[i.3E.2x])/i.3E.4m;i.2B+=(e[i.3D.2x]-M.5Q[i.3D.2x])/i.3D.4m;M.5Q=e;k.18=h=i.5R;k.17=l=i.2B;N(m){N("18"==j||"1j"==j){N("18"==j&&f.18>h){k.18=(e.18-f.18>=n.S)?(e.18-n.S-2):(f.1j-e.1j-2>e.18-f.18-2)?(e.1j+2):(e.18-n.S-2)}1e{N("1j"==j&&f.1j<h+n.S){k.18=(f.1j-e.1j>=n.S)?(e.1j+2):(e.18-f.18-2>f.1j-e.1j-2)?(e.18-n.S-2):(e.1j+2)}}}1e{N("17"==j||"1g"==j){k.18=1o.3c(f.18+2,1o.7y(f.1j,h+n.S)-n.S);N("17"==j&&f.17>l){k.17=(e.17-f.17>=n.W)?(e.17-n.W-2):(f.1g-e.1g-2>e.17-f.17-2)?(e.1g+2):(e.17-n.W-2)}1e{N("1g"==j&&f.1g<l+n.W){k.17=(f.1g-e.1g>=n.W)?(e.1g+2):(e.17-f.17-2>f.1g-e.1g-2)?(e.17-n.W-2):(e.1g+2)}}}}}Q k},8A:R(g){g=g||0;U f=(c.V.4u)?{S:13.8G,W:13.8F}:$12(13).1E(),e=$12(13).5g();Q{18:e.x+g,1j:e.x+f.S-g,17:e.y+g,1g:e.y+f.W-g}},8p:R(i){N(!M.1b||!M.1b.1T){Q}U g,f,h={S:M.1b.S,W:M.1b.W};M.1b.3k();N(M.Y.3j){f=$12(M.Y.T.1x).1E();N(/%$/i.1z(M.Y.3O)){M.P.1r=(2i(M.Y.3O)/1H)*f.S}N(/%$/i.1z(M.Y.3S)){M.P.1u=(2i(M.Y.3S)/1H)*f.W}}1e{N("2j"===M.P.1F){M.P.1r=M.1b.S;M.P.1u=M.1b.W}1e{N(/%$/i.1z(M.Y.3O)){M.P.1r*=M.1b.S/h.S}N(/%$/i.1z(M.Y.3S)){M.P.1u*=M.1b.W/h.W}}}g=M.Y.2P.1E();M.4q=M.P.1u-g.W;N(M.P.3i=="1g"){$12(M.1h.T.1x).2J("W",M.P.1u-g.W)}M.Y.T.1f("2j"==M.P.1F?{}:{W:M.P.1u+"1i",S:M.P.1r+"1i"});N(c.V.70&&M.Y.4P){M.Y.4P.1f({S:M.P.1r,W:M.P.1u})}N(M.P.3g&&M.1a.2q){M.1a.2q.1f(M.1b.T.1E())}M.1a.W=M.4q/(M.1h.W/M.1b.W);M.1a.S=M.P.1r/(M.1h.S/M.1b.S);N(M.1a.S>M.1b.S){M.1a.S=M.1b.S}N(M.1a.W>M.1b.W){M.1a.W=M.1b.W}M.1a.S=1o.33(M.1a.S);M.1a.W=1o.33(M.1a.W);M.1a.38=M.1a.T.4i("7A").4r();M.1a.T.1f({S:(M.1a.S-2*(c.V.3V?0:M.1a.38))+"1i",W:(M.1a.W-2*(c.V.3V?0:M.1a.38))+"1i"});N(M.1a.32){M.Y.T.1f(M.7u(/^(18|1j|17|1g)$/i.1z(M.P.1F)&&!M.P.3F));M.P.x*=M.1b.S/h.S;M.P.y*=M.1b.W/h.W;M.1X()}},4e:R(f,g){f=(c.1O(f))?f:19;M.4z=19;N(!M.1h){M.4Q();Q}N(M.P.3N){Q}M.2e=19;N(f){N(c.1O(g)){M.4T(g);Q}N(!M.P.4o){M.P.x=M.1b.S/2;M.P.y=M.1b.W/2}M.1X()}},4d:R(){U e=M.1a&&M.1a.32;N(M.2G){4p(M.2G);M.2G=1c}N(!M.P.3F&&M.1a&&M.1a.32){M.1a.32=X;M.1a.T.26();N(M.2f){M.2f.1K();M.2f.P.4n=M.Y.7D;M.2f.P.4f=M.P.7Y;U f=M.Y.T.4i("1C");M.2f.2b({1C:[f,0]})}1e{M.Y.26()}N(M.P.3g){M.c.2J("7b-4w","");M.1b.T.1Y(1)}}M.1s=1c;N(M.P.4k){M.2e=X}N(M.P.3y){M.4h=X}N(M.1t){M.4g=19;M.1t.1X()}},7i:R(i){U f=i.5f(),h=(/4M/i).1z(i.29),j=c.2N();N(3==f){Q 19}N(h){N(i.4H.1w>1){Q}M.c.76("3L:3e:9X",{1U:i.4H[0].9O,x:i.4H[0].7g,y:i.4H[0].71,90:j});N(M.1h&&M.1h.1T&&!M.2e){Q}}N(!(h&&i.7J.1w>1)){$12(i).1K()}N("1J"==M.P.2p&&!M.1b){M.4l=i;M.4Q();Q}N("2c"==M.P.2p&&!M.1b&&(i.29=="2c"||i.29=="7p")){M.4l=i;M.4Q();M.c.1Z("2c",M.4R);Q}N(M.P.3N){Q}N(M.1b&&!M.1h.1T){Q}N(M.1h&&M.P.9A&&M.2e&&!h){M.2e=X;M.4d();Q}N(M.1h&&!M.2e){M.4e(19,i);i.5n&&i.5n()}N(M.2e&&M.P.3y){M.4h=19;N(!M.P.5i){N(M.1s===1c||M.1s===1m){M.1s=M.1b.5s()}U g=i.4v();M.4J=g.x-M.P.x-M.1s.18;M.4E=g.y-M.P.y-M.1s.17;N(1o.a2(M.4J)>M.1a.S/2||1o.a2(M.4E)>M.1a.W/2){M.4h=X;Q}}1e{M.4T(i)}}},7a:R(i){U f=i.5f(),h=(/4M/i).1z(i.29),k=c.2N(),j=1c,g=M.P.4o;N(3==f){Q 19}N(h){j=M.c.2S("3L:3e:9X");N(!j||i.4H.1w>1){Q}N(j.1U==i.5V[0].9O&&k-j.90<=6a&&1o.d3(1o.3o(i.5V[0].7g-j.x,2)+1o.3o(i.5V[0].71-j.y,2))<=15){N(M.1h&&M.1h.1T&&!M.2e){N(M.1s===1c||M.1s===1m){M.1s=M.1b.5s()}M.P.4o=19;M.P.x=i.4v().x-M.1s.18;M.P.y=i.4v().y-M.1s.17;M.4e(19);M.P.4o=g;M.P.3y&&(M.4h=19);M.4J=0;M.4E=0;i.a1=19;i.d0=19;i.5n&&i.5n()}$12(i).1K();Q}}1e{$12(i).1K();N(M.P.3y){M.4h=X}}}};N(c.V.2L){2z{1d.d1("d2",X,19)}30(b){}}$12(1d).1v("3Q",R(){c.9G(".6A-7P-7T","3z-1j: 0 !2U;3z-17: 0 !2U;3z-1g: 0 !2U;1P-17: 0 !2U;1P-1g: 0 !2U;24: 0 !2U;1y: 4t  !2U;W: 0 !2U;7y-W: 0 !2U;z-2V: -1;6o: 3T !2U;1C: 0;","6A-6z");$12(1d).1v("6x",a.9D);a.6y()});Q a})(4L);',62,893,'||||||||||||||||||||||||||||||||||||||||||||||||this|if||options|return|function|width|self|var|j21|height|false|z46||||mjs|window||||top|left|true|z4|z7|null|document|else|j6|bottom|z1|px|right|zoom|style|undefined|break|Math|case|for|zoomWidth|z6|hint|zoomHeight|je1|length|parentNode|position|test|new|0px|opacity|arguments|j7|zoomPosition|extend|100|in|click|stop|call|appendChild|prototype|defined|padding|href|src|j24|ready|id|prefix|firstChild|show|j23|je2||fullScreen|auto|body|border||hide|j1||type|Element|start|mouseover|j2|z30|z2|j22|hidden|parseInt|inner|load|title|selectors|j27|absolute|initializeOn|z42|has|z3|onready|ieMode|j5|visibility|edge|webkit|try|j14|z21|FX|j32|getDoc|capable|z44|toLowerCase|J_TYPE|j6Prop|update|trident|parent|now|hotspots|z41|instanceof|removeChild|j29|parseFloat|important|index|constructor|className|z43Bind|createElement|catch|switch|z38|round|engine|apply|timer|zooms|borderWidth|typeof|mouseout|while|max|j16|event|z28|opacityReverse|default|showTitle|custom|z13|z9|nodeType|contains|pow|divTag|Transition|init|tagName|J_UUID|Array|overflow|j33|styles|dragMode|margin|version|selectorsEffect|requestAnimationFrame|adjustY|adjustX|alwaysShowZoom|unload|block|display|selectorsChange|z34|magiczoom|z35|disableZoom|initWidth|replace|domready|_tmpp|initHeight|none|detach|backCompat|Class|render|on|string||lastSelector|Doc|class|filter|z47|visible|DIV|toString|array|css3Transformations|match|j8|pause|activate|duration|hintVisible|z45|j19|zoomDistance|clickToActivate|initMouseEvent|ratio|onComplete|preservePosition|clearTimeout|zoomViewHeight|j17|setTimeout|relative|touchScreen|j15|color|z36|push|activatedEx|css3Animation|zoomAlign|j3|div|ddy|J_EUID|shift|targetTouches|events|ddx|300|magicJS|touch|_cleanup|fade|z23|z18|z14|z24|z43|byTag|continue|selectorsClass|currentStyle|initTopPos|getElementsByClassName||entireImage|storage|initLeftPos|zIndex|hintText|getElementsByTagName|touchend|fps|rel|forceAnimation|rightClick|loading|rev|img|getButton|j10|titleSource|moveOnClick|kill|getStorage|hasOwnProperty|exOptions|stopImmediatePropagation|createEvent|compatMode|originId|getRelated|getBox|_event_prefix_|callee|clickInitZoom|createTextNode|z0|enabled|hintPosition|smoothing|insertBefore|append|documentElement|delete|speed|head|button|defaults|readyState|scrollTop|cloneNode|ufx|scrollLeft|firstRun|j26|z7Rect|lastLeftPos|100000px|split|z37|changedTouches|showLoading|center|z11|complete||naturalWidth|Ff|implement|z10|9_|cancelAnimationFrame|j9|naturalHeight|element|200|features|loadingPositionX|platform|floor|random|bgColor|z20|400|changeContent|Bottom|to|ms|cos|float|item|query|loopBind|calc|effect|insertRule|object|el_arr|mousemove|refresh|css|mz|PI|j13|defaultView|IMG|throw|win|thumbChange|onErrorHandler|caller|z15|shadow|navigator|preventDefault|presto|loadingPositionY|stopAnimation|MagicZoom|startTime|String|loop|Top|Right|Left|z1Holder|size|trident4|clientY|Function|uuid|z16||j30|_event_add_|pounce|indexOf|mouseup|background|styleSheets|resizeBind|z33|smoothingSpeed|clientX|J_EXTENDED|mousedown|Event|_event_del_|styleFloat|z26|RegExp|hasChild|touchstart|number|request|HTMLElement|PFX|adjustPosition|construct|transition|1000|min|z39|borderLeftWidth|Zoom|j18|z22|zoomIn|1px|selectorsEffectSpeed|zoomFadeInSpeed|getComputedStyle|touches|Width|5001|5000|relatedTarget|onError|tmp|Moz|Khtml|finishTime|clone|Webkit|DXImageTransform|boolean|DocumentTouch|zoomFadeOutSpeed|set|quadIn|cursor|unselectable|changeEventName|900|documentMode|sineIn|localStorage|expoIn|chrome|cubicIn|errorEventName|stopPropagation|cancelFullScreen|requestFullScreen|CancelFullScreen|cancel|cancelBubble|concat|transform|backIn|gecko|forEach|fit|XMLHttpRequest|onresize|z27|abort|preload|roundCss|onBeforeRender|onAfterRender|dissolve|xpath|text|UUID|getViewPort|initialize|tl|MagicZoomPup|change|innerHeight|innerWidth|styles_arr|holder|500|textnode|dispatchEvent|contextmenu|big|fitZoomWindow|preloadSelectorsBig|zoomFade|Image|touchmove|z17|z19|je3|j31|textAlign|date|x7|ts|innerHTML|resize|charAt|preloadSelectorsSmall|ios|elasticIn|hintOpacity|getTarget|replaceChild|z29|loadingClass|loadingMsg|blur|loadingOpacity|hintClass|tc|nativize|Date|outline|inline|setupHint|tr|dashize|webkit419|selectorsMouseoverDelay|420|phone|doc|Microsoft|matchMedia|addEventListener|resizeTimer|MagicJS|backcompat|getBoundingClientRect|clickToDeactivate|clickToInitialize|getElementById|z8|onStart|interval|insertCSS|found|compareDocumentPosition|not|which|mozCancelAnimationFrame|wrap|state|identifier|box|Alpha|glow|raiseEvent|opera|setProps|z5|toArray|lastTap|zoomWindowEffect|bounceIn|android|continueAnimation|abs|magic|hone|ip|cssClass|od|error|offsetLeft|clientTop|clientLeft|j20||enclose|setAttribute|j11|offsetHeight|offsetWidth|iframe|offsetTop|progid|filters|hasLayout|childNodes|DOMElement|offsetParent|html|innerText|j19s|re|iemobile|hiptop|iris|kindle|lge|fennec|elaine|bada|avantgo|blackberry|blazer|compal|maemo|midp|pocket|plucker|psp|symbian|treo|ixi|os|mmp|netfront|ob|palm|tablet|mobile|KeyEvent|KeyboardEvent|regexp|slice|getTime|UIEvent|MouseEvent|v2|exists|collection|Object|addCSS|map|air|evaluate|runtime||querySelector|ontouchstart|userAgent|setInterval|eq|toUpperCase|toFloat|j28||up|link|performance|msPerformance|postMessage||525|419|210|211|applicationCache|260|250|220|192|191|FullScreen|webkitIsFullScreen|RequestFullScreen|j4|getPropertyValue|fullscreenerror|fullscreenchange|190|181|moz|khtml|270|AnimationName|mozInnerScreenY|getBoxObjectFor|WebKitPoint|taintEnabled|unknown|ActiveXObject|xiino|vodafone|wap|windows|xda|webos|mac|msCancelAnimationFrame|oCancelAnimationFrame|webkitCancelRequestAnimationFrame|Transform|animationName|msRequestAnimationFrame|oRequestAnimationFrame|linux|other||mozRequestAnimationFrame|webkitRequestAnimationFrame||cssFloat|textDecoration|presto925|user|select|767px|10000|z12|_new|callout|tap|gecko181|hand|ie|selectstart|MozUserSelect|highlight|transparent|static|10000px|image|disable|sMagicZoom|entire|small|thumb|delay|MagicZoomPlus|lastChild|fromCharCode|charCodeAt|temporary|getXY|zoomOut|Invalid|Magic|MagicZoomBigImageCont|10002|td|toLocaleLowerCase|inz30|sizing|content|z32|removeAttribute|exec|009|zoomActivation|execCommand|BackgroundImageCache|sqrt|rtl|skipAnimation|dir|z31|currentTarget|javascript|frameBorder|MagicZoomHeader|IFRAME|MagicBoxGlow|trident900|MagicBoxShadow|3px|fontSize|2em|101|z25|line|Tahoma|fontWeight||fontFamily|msg|matches|loaded|doScroll|DOMContentLoaded|fireEvent|eventType|initEvent|createEventObject|curFrame|clearInterval|cubicOut|618|backOut|quadOut|expoOut|linear|sineOut|detachEvent|attachEvent|j12|scrollWidth|scrollHeight|pageYOffset|pageXOffset|clientWidth|clientHeight|byClass|returnValue|fromElement|out|removeEventListener|srcElement|target|pageX|pageY|elasticOut|toElement|deactivate|source|screen|move|reverse|MagicZoomHint|MagicZoomLoading|preserve|always|Loading|addRule|v4|drag|mode|distance|bounceOut|stylesId|sheet|cssRules||join|styleSheet|align'.split('|'),0,{}))

$(document).ready(function() {
  var importIds = ['B1001','B1015','B2001','B3001','B3002','B3015','B3200','B8150','B9025C'];

  var pid = $('.prodImg[data-productid]').data('productid');
  if (importIds.indexOf(String(pid).toUpperCase()) !== -1) {
    $('.prodImgInner').addClass('isImportProduct');
  }
});
;(function ($, window, document){
   
   var quickorder = new function(){
      
      var  opts = { 'checkStock': true
                   ,'fullCaseOnly': false
                   ,'fullCaseQty': 1
                   ,'getOnOrder': true
                   ,'invListingPg': 'inventory_listing'         
                   ,'showBISNotify': false        
                   ,'showPrepack': false    
                   ,'poDays': 0
                   ,'autoBO': true
                  }
         , base = this
         , whseList = []
         , _whseList
         , itemWhse = {}
         , $grid
         , selectedWhse = ""
         , selectedColor = ""
         , whseGridLoaded = false
         , prepackObj = []
         , boAsnObj = {}
         , deisgnGridRefresh = false
         , styleInputHTML
         ;

      var $prod, prodObj; 
      var skipSelectDesign = false;
      var gridTmpl,
          gridWhseTmpl,
          storedWhse = "",      
          storedGridMode = "",  
          storedColor = "",    
          gridColorTmpl,
         pricingGridTmpl;  //ROY010003
      
     var qtyBackgroundColor = ""; //ROY010003
      this.init = function(options,defWhse,ttWhseList,vPrepackObj){
         $.extend(true,opts,options);
                  
         $prod = $.wam.product.getProdElm();
         prodObj = $.wam.product.getProdObj();
         
         storedWhse     = $.wam.store('selectedWarehouse');
         storedGridMode = $.wam.store('gridMode');     
         storedColor    = $.wam.store('selectedColor'); 

         if( typeof opts.autoBO == 'undefined' || opts.autoBO == '' )
          opts.autoBO = false;

         if(typeof storedGridMode != 'undefined' && storedGridMode != '' && storedGridMode != null ) {
           opts.gridMode = storedGridMode;
         }
       
         styleInputHTML = $("#qoSearchInputOuter").html();
        
         if(typeof defWhse != 'undefined' && defWhse != '')
             selectedWhse = defWhse.toLowerCase();
         // WAS: selectedWhse = $prod.find('select[name="whseSelect"]').val();
         
         $.wam.store('completeOnly',null); // Clear BO completeOnly flag incase set but lines never added

         if(typeof vPrepackObj == 'object'){
           prepackObj = vPrepackObj;           
         }
                 
         blockGrid();

         var query = 'action=getProdData&content=json&page=' + $.wam.opts.page + '&product=' + prodObj.styleCode + '&warehouse=' + selectedWhse;
         $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,getProdData_callback,'application/json','json',false);       
         //Compile the Handlebars Template 
         gridTmpl        = Handlebars.compile( $("#qoGridColorTmpl").html() );
         gridTmpl2       = Handlebars.compile( $("#qoGridWhseTmpl").html()  );
         gridWhseTmpl    = Handlebars.compile( $("#whseSelectTmpl").html()  ); 
         gridColorTmpl   = Handlebars.compile( $("#colorSelectTmpl").html() );                                                 
        pricingGridTmpl = Handlebars.compile( $("#pricingGridTmpl").html() );  //ROY010003                                                 
         $("#gridMode").val(opts.gridMode).on('change',function(){ changeGridMode($(this).val(),true); });
         
         // type = number input causes the value to change on mouse scroll - prevent it
         $('.quickorderGrid').on('focus','input.qoInput', function (e) {
          $(this).on('mousewheel.disableScroll', function (e) {
            e.preventDefault()
           })
         });
         $('.quickorderGrid').on('blur','input.qoInput', function (e) {
           $(this).off('mousewheel.disableScroll')
         });         
     };
     
     //TEMP - move to layout.js 
     $.wam.makeAssoc = function(vKey,vArr,vLink){
        if(typeof vArr == "undefined") return;
        var newKey,
            newArr = {};
        for(var i=0; i<vArr.length; i++) {
          newKey = vArr[i][vKey];
          if(vLink){
            newArr[ newKey ] = vArr[i];
          }else{
            newArr[ newKey ] = $.extend(true,{},vArr[i]);
          }
        }
        return newArr;     
     };

     function getProdData_callback(data){

         if(typeof data == 'undefined' || typeof data.product == 'undefined'){
            $.wam.alert($.wam.getText('noProduct'));
            return;
         }
         
         //Update Product Data
         $.extend(prodObj,data.product[0]);         
         
         //make itemWhse an assocArray
         $(prodObj.item).each(function(idx){
           var thisItem = this; 
           if(typeof thisItem.itemWhse == 'object' && thisItem.itemWhse.length){
              thisItem._itemWhse = $.wam.makeAssoc('warehouse',thisItem.itemWhse,true);
           }                     
         });
         prodObj._itemLink = $.wam.makeAssoc('itemNumber',prodObj.item,true);
         prodObj._item = $.wam.makeAssoc('itemNumber',prodObj.item);
         $grid = $prod.find('.quickorderGrid');           

         if(typeof data.warehouseList != 'undefined'){
           whseList  = data.warehouseList;
           _whseList = $.wam.makeAssoc('whse',whseList);
         }       

         //make itemWhse an assocArray
         for(key in prodObj._item){
           if(prodObj._item[key].itemWhse && prodObj._item[key].itemWhse.length){
              prodObj._item[key]._itemWhse = $.wam.makeAssoc('warehouse',prodObj._item[key].itemWhse);
              delete prodObj._item[key].itemWhse;
           }
         }

         
         if(typeof storedGridMode != 'undefined' && storedGridMode != '' && storedGridMode != null ) {
             opts.gridMode = storedGridMode;
         }

         //Set stored values if they are valid for this product 
         if(typeof defWhse != 'undefined' && defWhse != '' && defWhse != null)
            storedWshe = defWhse.toLowerCase();

         if(typeof storedWshe != 'undefined' && storedWhse != '' && storedWhse != null && typeof _whseList != 'undefined' && typeof _whseList[storedWshe] != "undefined")          
            selectedWhse = storedWhse.toLowerCase();

         if(typeof storedColor != 'undefined' && storedColor != '' && storedColor != null && typeof prodObj._color[storedColor] != 'undefined')
            opts.selectedColor = storedColor;

         if( typeof opts.selectedColor != 'undefined' && opts.selectedColor != '' ){
             selectedColor = opts.selectedColor;
             $.wam.product.setColor(selectedColor,$prod.find('.colorOuter a[data-colorcode="' + selectedColor + '"]') );
             //Fix model view magiczoom to use primary style imgs
             $prod.find(".modelView a").prop('href',prodObj.imageZm).attr('rev',prodObj.imageLg);
         }

         //Render Warehouse List / Cutoff status 
         if(typeof data.warehouseList == 'object'){
           whseList = data.warehouseList;
           _whseList = $.wam.makeAssoc('whse',whseList);
           //Check if selected warehouse is in returned list 
           if(typeof _whseList[selectedWhse] == 'undefined'){
             selectedWhse = data.warehouseList[0].whse;
           }
           changeGridMode(opts.gridMode,true,true);           
         }

        /*** v ROY010003 v ***/
         //Render the pricing grid
         if(typeof data.pricingGrid == 'object')
         {
          // compiled above in the init function
          $("#pricingGridTmpl").html(pricingGridTmpl(data));
          $('#pricingGridStub').html($("#pricingGridTmpl").html()).show();
         }
        /*** ^ ROY010003 ^ ***/
         unblockGrid();

         $grid = $prod.find('.quickorderGrid');
         
         var $tmp = $(".backorderDialog");
         $(".backorderDialog").remove();
         $('body').append($tmp);
         $tmp = null;
         
         var $tmp = $("#prepackDialog");
         $("#prepackDialog").remove();
         $('body').append($tmp);
         $tmp = null;

         // Bind Events       
         $prod.on('change','select[name="whseSelect"]',function(){ changeWarehouse(this); });
         $("#colorSelectOuter").on('change','#colorSelect',renderGrid);
         $prod.on('click','.qoAddBtn',quickorderAdd);
         $prod.on('click','.qoViewCartBtn',goCart);
         $prod.on('click','.qoNotifyBtn',function(){ quickorderNotify(this) }); 
         $prod.on('click','.qoAddPrepackBtn',function(){ openPrepack(this) }); 
         $("#prepackSelect").on('change',changePrepack);
         $(".ppApplyBtn").on('click',applyPrepack);
         $grid.on('change','.qoInput',function(){ changeQty(this); });
         $grid.on('click','.qoAddLineBtn',function(){ quickorderAddLine(this); });
         $('.qoSearchGoBtn').on('click',quickorderSearch);
         $('.showStockGo').on('click',showExpectedStock);
         $('.qoMillGoBtn').on('click',selectMill);
         $('.backorderDialog').on('click','.boSelectBtn',selectBoOpt);
         $('.backorderDialog').on('click','.boConfirmBtn',confirmBOStock);  //ROY010003
         $('.backorderDialog').on('click','.boCancelBtn',cancelBOStock);    //ROY010003
         $('#qoPromo').on('submit',applyPromo);
         //Expected Stock Click
         $(".stockLabel").on("click",function(){viewStock(this);}); 
         $(".expStockLabel").on("click",function(){viewStock(this);}); 
         $("form[name='quickorderForm']").on('submit',quickorderAdd);
        /*** v ROY010003 v ***/
         $(".product-elem").on("click",function(){viewOnOrder($(this));});
        $('.qoInput',".product-content").on("focus",function() { $(this).css("background-color",qtyBackgroundColor); }); 
        $('.qoInput',".product-content").on("blur",function() { var val = $(this).val(); if (val == "" || val == "0") $(this).css("background-color",""); }); 
        $prod.on('click','.comingSummary',function() { comingToggle($(this)); });
        /*** ^ ROY010003 ^ ***/
         //Ensure cutoff msg is set for when default whse is not avail for current product        
         if( $(".cutoffMsg").html() == '' ){
           $(".cutoffMsg").html( $("option[selected]","#whseSelect").data('cutoff') );
         }
        
         //FDM4 Decorator
         if(laUseDecorator){
         
          $tmp = $("#applyDesignDialog");
          $("#applyDesignDialog").remove();
          $('body').append($tmp);
          $tmp = null;
           
          $(".btn-decorate").show();
          $("#decorateLegend").show();
           
          $.each(prodObj.item,function(){ 
           if(this.orderQty > 0){
            laHasOrderedProd=true; 
            return false; 
           }
          });
          
          if(laHasOrderedProd && laHasDesign){
            $(".qoApplyDesignBtn").show();
          }
           
          //Button Events 
          $("#applyDesignDialog").on('click','.designPreview',selectDesign);
          //ApplyDesign Dialog events
          $("#applyDesignDialog").on('click',".laGridCancel",closeApplySavedDesign);
          $("#applyDesignDialog").on('click',".laGridDelete",deleteDesign);
          $("#applyDesignDialog").on('click',".laGridSave",designGridSave);
          
          $("#applyDesignDialog").on('click',"#selDesignLeft",function(){ scrollDesigns('left'); });
          $("#applyDesignDialog").on('click',"#selDesignRight",function(){ scrollDesigns('right'); });
          $("#applyDesignDialog").on('click',".decoratorClose",closeApplySavedDesign);
          
          $("#applyDesignDialog").on('mouseover','.designLocPreview',function(){ 
            var $this = $(this);
            if($this.hasClass('selected')){ return; }
            $this.parent().find('.selected').removeClass('selected');
            $this.addClass('selected').closest('.designPreview').find('.designImg').prop('src',$this.find('img').prop('src'));
          });
          $("#applyDesignDialog").on('mouseenter','.designArrow',function(){ $(this).addClass('arrowOn'); });
          $("#applyDesignDialog").on('mouseleave','.designArrow',function(){ $(this).removeClass('arrowOn'); });
          $("#applyDesignDialog").on('change',".la_design_input",decLineChange);
          if(laHasDesign){
             $(".btnQoDesignGrid").show();        
          }
          $(".quickorderGrid").on('click','.qoDecImage',openApplyDesign);
          $(".qoApplyDesignBtn").on('click',openApplyDesign);
        }
        if ((typeof window.CSS != 'undefined') && window.CSS.supports("-webkit-background-clip","text") && window.CSS.supports("-webkit-text-fill-color","transparent")) { /* CIT010000 */
           setMultiHexGrid();} /* CIT010000 */        
     };

     function renderGrid(){
        if(opts.gridMode == 'whse'){
          renderGridWhse();
        }else{
          renderGridColor();
        }  
        
        // highlight ordered qtys
       $("input[data-ordered!='0']",".product-content").css("background-color",qtyBackgroundColor);    //ROY010003
     };   

     //One Color, All Warhouses
     function renderGridColor(){     
        var prodTmp = {};
        prodTmp.showPrepack = opts.showPrepack;
        prodTmp.showNotify  = opts.showBISNotify;   
        prodTmp.color = [];      
        prodTmp.size  = $.extend([],prodObj.size);
        prodTmp.warehouse = $.extend([],whseList);;              
        var showNotifyColumn = false;
        
        $.wam.store('selectedColor', $("#colorSelect").val());
        $.each(prodObj.color,function(idx){
           if(this.colorCode == $("#colorSelect").val() ){
              prodTmp.color = $.extend({},this);
              return false;
           }
        });
        /* possible issue with inital color mode display? .... */
        prodTmp.color.hasSale = false;
        var colorItems = $.grep(prodObj.item,function(myItem){ 
                           return (myItem.colorCode == prodTmp.color.colorCode); 
                         });
        prodTmp.color.size = [];

        prodTmp.color.colorShowPrepack = prodTmp.showPrepack;
        
        var colorPrepack = false;
        for(var i=0;i<prepackObj.length;i++){
           if(prepackObj[i].colorCode == prodTmp.color.colorCode){
              colorPrepack = true;
              break;  
           }
        }    
        $.each(prodTmp.warehouse,function(idx2){
           this.showPrepack = colorPrepack;
           this.hasPrepack = colorPrepack;
        });
        $.each(prodTmp.size,function(idx2){
          //thisColor.size.push({ sizeCode: this.sizeCode, description:this.description });
          var thisSize = this;           
          var colorSizeObj = { sizeCode: thisSize.sizeCode, description:thisSize.description };
          $.each(colorItems,function(idx3){
            var thisItem = this;
            if(thisItem.sizeCode == thisSize.sizeCode && typeof thisItem.itemWhse != "undefined"){                
              
              if( thisItem.onSale ){
                prodTmp.color.hasSale = true;
                if (thisItem.saleType=="C")  
                   thisItem.saleIcon = $('#closeoutIcon').html(); 
                else if (thisItem.saleType=="S")  
                   thisItem.saleIcon = $('#saleIcon').html(); 
              }
              colorSizeObj.item = $.extend({},thisItem);
            }               
          });     
          
          // if there's at least one row out of stock, show the notify column
          if (prodTmp.color.show && prodTmp.color.hasOOS) showNotifyColumn = true;

          prodTmp.color.size.push( colorSizeObj);

        });             

        $.each(prodTmp.warehouse,function(idx){
           var thisWhse  = this;
           var itemFound = false; 
           thisWhse.size = $.extend(true,[],prodTmp.color.size);
           thisWhse.show = false;
           thisWhse.notifyClass = '';   
           thisWhse.poDays = opts.poDays;  
           thisWhse.hasOOS = false;
          thisWhse.onOrder = [];
          thisWhse.onOrderSummary = [];

           $.each(thisWhse.size,function(idx2){
             
             var thisSize = this;                      
             var thisItem = thisSize.item;
             var itemWhseFound = false;
             if(typeof thisItem == 'object' && typeof thisItem.itemWhse != "undefined"){                
               $.each(thisItem.itemWhse,function(idx4){
                 if(this.warehouse == thisWhse.whse){                     
                   itemWhseFound = true;
                   thisItem.availQty         = this.availQty;
                   thisItem.availQtyHtml     = this.availQtyHtml;
                   thisItem.orderQty         = this.orderQty;
                   thisItem.saleIcon         = ''; 
                   thisItem.totalOrdered     = this.orderQty + this.boQty; 
                   thisItem.hasDecoration 	 = this.hasDecoration; 
                   //thisSize.item         = $.extend({},thisItem);        
                  thisItem.onOrder          = $.extend([],this.onOrder);           //ROY010003
                  thisItem.onOrderSummary   = $.extend([],this.onOrderSummary);    //ROY010003
                   thisItem.prodQty          = this.prodQty;                        //ROY010003
                   thisItem.realAvailQty     = this.realAvailQty;                   //ROY010003
                   thisItem.realAvailQtyHtml = this.realAvailQtyHtml;               //ROY010003

                   var tmpItemWhse; 
                   try{ 
                      tmpItemWhse = prodObj._item[thisItem.itemNumber]._itemWhse[this.warehouse];
                   }catch(e){ }
                   if( typeof tmpItemWhse == 'object' ){
                      thisItem.availQty     = tmpItemWhse.availQty;
                      thisItem.availQtyHtml = tmpItemWhse.availQtyHtml;
                      thisItem.orderQty     = tmpItemWhse.orderQty;
                      thisItem.totalOrdered = tmpItemWhse.orderQty + tmpItemWhse.boQty;                     
                      thisItem.hasDecoration = tmpItemWhse.hasDecoration; 
                   }
                   //whseSizeObj.item = $.extend({},thisItem);
                   /*** v ROY010003 v ***/
                   // only need to do this once for the first size since every size has the same data set for po/asn regardless of qty
                  if (thisWhse.onOrder.length === 0)
                   {
                    thisWhse.onOrder        = $.extend([],this.onOrder);
                    thisWhse.onOrderSummary = $.extend([],this.onOrderSummary);
                    
                    // reformat dates to mm/dd/yyyy
                    for (var i=0; i<thisWhse.onOrder.length; i++)
                    thisWhse.onOrder[i].formattedDate = formatDate(thisWhse.onOrder[i].estDate);
                    for (var i=0; i<thisWhse.onOrderSummary.length; i++)                     
                    {
                     thisWhse.onOrderSummary[i].begDate = formatDate(thisWhse.onOrderSummary[i].begDate);
                     thisWhse.onOrderSummary[i].endDate = formatDate(thisWhse.onOrderSummary[i].endDate);
                    }
                   }
                  /*** ^ ROY010003 ^ ***/

                   thisWhse.show = true;

                   if (thisItem.availQty>0) 
                      thisWhse.rowOOS=false;
                   
                   if (this.notify) thisWhse.notifyClass = 'selected';
                   if (thisItem.availQty<1) thisWhse.hasOOS = true; 

                   return false;
                 }
               });

             }               
             if(!itemWhseFound){
                delete thisSize.item;
             }
             
             /* if there's at least one row out of stock, show the notify column */
             if (thisWhse.show && thisWhse.hasOOS) showNotifyColumn = true;


           });           
        });

        /* only show the notify column if there's a color row OOS */
        if (prodTmp.showNotify) {
           
           if (!showNotifyColumn) prodTmp.showNotify = false;

           /* with handlebars, we need a separate var at the color level for the if statement to work */
           $.each(prodTmp.warehouse,function(){
              this.showNotify = prodTmp.showNotify;    
           });

        }
        
        $(".quickorderGrid").html( gridTmpl2(prodTmp) ); 

        /* now that we have an order grid displayed, let's show the grid buttons, legend, and promo code input */
        $prod.find('.qoButtonRow').show();
        $prod.find('#qoPromo').show(); 

     };


     this.changeColor = function(colorCode,colorDesc,selectDropDown) { 
        
        if (opts.gridMode != 'color' || typeof prodObj._color[colorCode] == 'undefined') return true; 
        
        // possible a user has selected a color before the AJAX to load all inventory and pricing is finished
        if (!whseGridLoaded) {
          blockGrid();
          selectedColor = colorCode;
          return true;
        }
         
        if( checkUnapplied() ){
           if(confirm( $.wam.getText('unapplied') )){
              $prod.find('#whseSelect').val(selectedWhse); 
              quickorderAdd();
              return false;
           }
        }

        selectedColor = colorCode;

        if (selectDropDown) {
            $("#colorSelect").val(selectedColor);   
            $("#colorSelect").trigger("change");    
        }   
        renderGridColor();
        
        return true;
     }

     //One Warehouse, All Colors 
     function renderGridWhse(){     
        var prodTmp = {};
        prodTmp.showPrepack = opts.showPrepack;
        prodTmp.showNotify  = opts.showBISNotify; 
        prodTmp.color = $.extend([],prodObj.color);
        prodTmp.size  = $.extend([],prodObj.size);
        var showNotifyColumn = false;
        
        prodTmp.whseDesc   = _whseList[selectedWhse].whseDesc;
        prodTmp.whseCutoff = _whseList[selectedWhse].cutoffMsg;

        $.each(prodTmp.color,function(idx){
         
           var thisColor = this;
           var itemFound = false; 

           //Ugg not ideal to have to do this here ... may be easier to reWork the JSON from the server to better match this senario ... 
           thisColor.hasSale = false;
           thisColor.show = false;

           var colorItems = $.grep(prodObj.item,function(myItem){ 
                              return (myItem.colorCode == thisColor.colorCode); 
                            });
           thisColor.size = [];

           thisColor.colorRowOOS = true;
           thisColor.notifyClass = '';
           thisColor.colorShowPrepack = prodTmp.showPrepack;
           thisColor.colorHasPrepack = false;
           // poDays. If needed outside the color level, then we'll need 2 separate variable names for handlebars to work
           thisColor.poDays = opts.poDays;  
           thisColor.hasOOS = false;
          thisColor.onOrder = [];
          thisColor.onOrderSummary = [];

           for(var i=0;i<prepackObj.length;i++){
              if(prepackObj[i].colorCode == thisColor.colorCode){
                 thisColor.colorHasPrepack = true;
                 break;  
              }
           }

           $.each(prodTmp.size,function(idx2){
             //thisColor.size.push({ sizeCode: this.sizeCode, description:this.description });
             var thisSize = this;           
             var colorSizeObj = { sizeCode: thisSize.sizeCode, description:thisSize.description };
             $.each(colorItems,function(idx3){
               var thisItem = this;
               if(thisItem.sizeCode == thisSize.sizeCode && typeof thisItem.itemWhse != "undefined"){                
                 
                 $.each(thisItem.itemWhse,function(idx4){
                   if(this.warehouse == selectedWhse){                     
                     thisItem.availQty         = this.availQty;
                     thisItem.availQtyHtml     = this.availQtyHtml;
                     thisItem.orderQty         = this.orderQty;
                     thisItem.saleIcon         = ''; 
                     thisItem.totalOrdered     = this.orderQty + this.boQty; 
                     thisItem.hasDecoration = this.hasDecoration; 
                     var tmpItemWhse; 
 					 try{ 
                     	tmpItemWhse = prodObj._item[thisItem.itemNumber]._itemWhse[this.warehouse];
                     }catch(e){ }
                     if( typeof tmpItemWhse == 'object' ){
                        thisItem.availQty     = tmpItemWhse.availQty;
                        thisItem.availQtyHtml = tmpItemWhse.availQtyHtml;
                        thisItem.orderQty     = tmpItemWhse.orderQty;
                        thisItem.totalOrdered = tmpItemWhse.orderQty + tmpItemWhse.boQty;    
                        thisItem.hasDecoration = tmpItemWhse.hasDecoration; 
                     } 
                     thisItem.onOrder          = $.extend([],this.onOrder);         //ROY010003
                     thisItem.onOrderSummary   = $.extend([],this.onOrderSummary);  //ROY010003
                     thisItem.prodQty          = this.prodQty;                      //ROY010003
                     thisItem.realAvailQty     = this.realAvailQty;                 //ROY010003
                     thisItem.realAvailQtyHtml = this.realAvailQtyHtml;             //ROY010003
                     
                    /*** v ROY010003 v ***/
                     // only need to do this once for the first size since every size has the same data set for po/asn regardless of qty
                    if (thisColor.onOrder.length === 0)
                     {
                      thisColor.onOrder        = $.extend([],this.onOrder);
                      thisColor.onOrderSummary = $.extend([],this.onOrderSummary);
                     
                      // reformat dates to mm/dd/yyyy
                      for (var i=0; i<thisColor.onOrder.length; i++)
                      thisColor.onOrder[i].formattedDate = formatDate(thisColor.onOrder[i].estDate);
                      for (var i=0; i<thisColor.onOrderSummary.length; i++)
                      {
                       thisColor.onOrderSummary[i].begDate = formatDate(thisColor.onOrderSummary[i].begDate);
                       thisColor.onOrderSummary[i].endDate = formatDate(thisColor.onOrderSummary[i].endDate);
                      }
                     }
                    /*** ^ ROY010003 ^ ***/
                     if( thisItem.onSale ){
                       thisColor.hasSale = true;
                       if (thisItem.saleType=="C")  
                          thisItem.saleIcon = $('#closeoutIcon').html(); 
                       else if (thisItem.saleType=="S")  
                          thisItem.saleIcon = $('#saleIcon').html(); 
                     }
                    
                     colorSizeObj.item = $.extend({},thisItem);
                     
                     thisColor.whse = selectedWhse; 
                     thisColor.show = true;

                     if (thisItem.availQty>0) 
                        thisColor.colorRowOOS=false;
                     
                     if (this.notify) thisColor.notifyClass = 'selected';
                     if (thisItem.availQty<1) thisColor.hasOOS = true; 

                     return false;
                   }
                 });

               }               
             });     
             
             /* if there's at least one row out of stock, show the notify column */
             if (thisColor.show && thisColor.hasOOS) showNotifyColumn = true;

             thisColor.size.push( colorSizeObj);

           });           

        });

        /* only show the notify column if there's a color row OOS */
        if (prodTmp.showNotify) {
           
           if (!showNotifyColumn) prodTmp.showNotify = false;

           /* with handlebars, we need a separate var at the color level for the if statement to work */
           $.each(prodTmp.color,function(){
              var thisColor = this;
              thisColor.colorShowNotify = prodTmp.showNotify;    
           });

        }

        $(".quickorderGrid").html( gridTmpl(prodTmp) ); 

        /* now that we have an order grid displayed, let's show the grid buttons, legend, and promo code input */
        $prod.find('.qoButtonRow').show();
        $prod.find('#qoPromo').show(); 
        
        // if the color has a sale then need to add space above the on order summary display
        $(".product-item").each(function()
        {
         var row = $(this);
         
         $(".qoSalePrice").each(function()
                                {
          row.find(".comingSummary").addClass("comingSummarySpacer");
          
          // quit after finding the first on sale item, only need to add this class once for the row
          return false;
         });
         
        });
     };
     function blockGrid() {
        $prod.find("#orderGridLoading").show();  
     };

     function unblockGrid() {
        $prod.find("#orderGridLoading").hide();  
     };

     function viewStock(clickElement){
        var styleCode = $.wam.product.getProdObj().styleCode; 
        var colorCode = $(clickElement).closest(".product-item").data("color");
        var whseCode = $("#whseSelect :selected").val();
        var millCode = $("#millSelect :selected").val();
        var showExpectedStock = $("#showPO").prop("checked");
        var expectedStockDays = $("#poDays").val();
        
        //Blank mill code on the QO grid means all mills
        if (millCode === "")
            millCode = "*";
        
        var invListingURL = $.wam.getlink("/wam_tmpl/inventory_listing.p","page=" + opts.invListingPg + "&action=process&warehouse=" + whseCode + "&mill=" + millCode + "&style=" + styleCode + "&color=" + colorCode);
        if (showExpectedStock)
            invListingURL += "&showExpected=true&expectedDays=" + expectedStockDays;

        if( checkUnapplied() ){
          if(confirm( $.wam.getText('unapplied') )){  
             quickorderAdd();
             return;
          }else{
            document.location.href=invListingURL; 
          }
        }else{
          document.location.href=invListingURL; 
        }        
       
        
     };
     
     function quickorderSearch(){
       var styleCode = $('#qoSearchInput').val();
       $("#gridMsg").html('').prop('class','');
       if($.trim(styleCode) == ''){
          $('#gridMsg').addClass('alert alert-danger').html( $.wam.getText('enter_style') );
          scrollToMsg();
          return;
       }
       if( checkUnapplied() ){
          if(confirm( $.wam.getText('unapplied') )){  
             quickorderAdd();
             return;
          }else{
            $.wam.golink('/wam_tmpl/catalog_product.p?page=' + $.wam.opts.page,'product=' + styleCode + '&warehouse=' + selectedWhse);
          }
       }else{
          $.wam.golink('/wam_tmpl/catalog_product.p?page=' + $.wam.opts.page,'product=' + styleCode + '&warehouse=' + selectedWhse);
       }       
       
     };

     function scrollToMsg(){
       $.wam.scrollTo('#gridMsg'); 
       //$('html, body').animate({scrollTop: $('#gridMsg').offset().top - 60 }, 400);
     };

     function applyPromo(){
        var query = 'action=applyPromo&content=json&promoCode=' + encodeURIComponent($("input[name='qoPromoInput']",this).val());
        $("#gridMsg").html('').prop('class','');
        $.wam.ajaxPost('/wam_tmpl/cart.p?' + query,'POST',null,applyPromo_callback,'application/json','json',true);
     };
     function applyPromo_callback(data){   
        var sMsg;
        var sClass; 
        if(typeof data.msg == 'object' && data.msg.length){
          sMsg = data.msg[0].msg;
          if($.trim(sMsg) == "") return;
          if(data.msg[0].success){
              sClass = 'alert-modal-success';       
          }else{ 
             sClass = 'alert alert-modal-danger';   
          }
          $.wam.alert({
              message: sMsg,
              callback: function(){ location.reload(true); },
              className: sClass,
              backdrop: true,
              size: 'small'
          });

        }else{
          //Unknown Error...
        }
     };

     function selectMill(){
        var selMill = $("#millSelect").val();
        var query = 'action=getMillStyles&content=json&millCode=' + selMill + '&page=' + $.wam.opts.page;
        $("#gridMsg").html('').prop('class',''); 
        if(selMill == ''){
           $("#qoSearchInputOuter").html(styleInputHTML);  
        }else{
          $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,selectMill_callback,'application/json','json',true);       
        }
     };
     function selectMill_callback(data){
       var styleSelect = "<select name='qoSearchInput' id='qoSearchInput' class='form-control'>"
                       + "<option value=''>" + $.wam.getText('sel_style') + "</option>"
       if( data.millStyle && data.millStyle.length ){
          for(var i=0;i<data.millStyle.length;i++){
             styleSelect += "<option value='" + data.millStyle[i].styleCode + "'>[" + data.millStyle[i].styleCode + "] " + data.millStyle[i].description + "</option>";
          }
          styleSelect += "</select>";
          $("#qoSearchInputOuter").html(styleSelect);         
       }else{
         $("#gridMsg").html( $.wam.getText('no_mill_style') ).prop('class','alert alert-danger');
         $("#qoSearchInputOuter").html(styleInputHTML);  
         $.wam.scrollTo('#gridMsg');
       }
       
     };

     //Private Functions
     function goCart(){
        if( checkUnapplied() ){
           if(confirm( $.wam.getText('unapplied') )){
              $prod.find('select[name="whseSelect"]').val(selectedWhse);    
              quickorderAdd(true);
              return false;
           }else{
             return true;
           }
        }else{
           return true;
        }
     };

     function checkUnapplied(){ 
        var origQty, 
            qty,
            hasUnapplied = false;

        $grid.find('.qoInput').each(function(){
          var $this = $(this);
          origQty = $this.data('ordered');
          qty = this.value;
          if( qty == '' && origQty === 0) qty = 0; //Allow placeholder
          if(origQty != qty){
             hasUnapplied = true;
             if(qty == '' && !isNaN(origQty) && origQty > 0)
               this.value = 0;
          }
        });
        
        return hasUnapplied;

     };

     function changeWarehouse(vThis){
        var newWhse = $(vThis).val(),
            found,
            itemNum,
            $cell;

        if( checkUnapplied() ){
           if(confirm( $.wam.getText('unapplied') )){
              $prod.find('select[name="whseSelect"]').val(selectedWhse);    
              quickorderAdd();
              return false;
           }
        }

        selectedWhse = newWhse;
        $.wam.store('selectedWarehouse', selectedWhse); 

        renderGrid();

       /*** v ROY010003 v ***/
        // set the running total of order qty for this row, send in the current row
        if (opts.gridMode == 'whse')
         setOrderQtyTotal($(".qoGridColor").find(".product-description")); 
        else
         setOrderQtyTotal($(".qoGridWhse").find(".product-description")); 
       /*** ^ ROY010003 ^ ***/
       $(".cutoffMsg").html( $("option:selected","#whseSelect").data('cutoff') ); //From Demo
     };

     function updateInputData(orderObj){
       var hasWhseSelect = $prod.find("select[name='whseSelect']").length,
           lineWhse,
           whse,
           $input,
           totalOrdered;
       
       //gridMode overrides whseSelect  
       if(opts.gridMode == "color"){
          hasWhseSelect = false;
       }

       if(hasWhseSelect){
          whse = $prod.find("select[name='whseSelect']").val().toLowerCase();
       }else{
          whse = _whseList[selectedWhse].whse;
       }

       $grid.find("input[value='0']").data('ordered',0);
       if(orderObj && orderObj.orderLine && orderObj.orderLine.length){
       for(var i=0;i<orderObj.orderLine.length;i++){
          itemNum = String(orderObj.orderLine[i].itemNumber).toLowerCase(); //need String in case itemNum is numeric only
          lineWhse = orderObj.orderLine[i].warehouse.toLowerCase();
          if(hasWhseSelect){
            if(whse == lineWhse){
              $input = $grid.find("input[name='" + itemNum + "']");
            }else{
              $input = {length:0};
            }
          }else{
              $input = $grid.find(".product-item[data-warehouse='" + lineWhse + "']").find("input[name='" + itemNum + "']");
          }
          if($input.length && 
             typeof prodObj._item[itemNum] == 'object' && 
             typeof prodObj._item[itemNum]._itemWhse == 'object' && 
             prodObj._item[itemNum]._itemWhse[lineWhse] )
          {
             $input.data('ordered',prodObj._item[itemNum]._itemWhse[lineWhse].orderQty);
	     /* vvvv 022000 vvvv */
             if (prodObj._item[itemNum]._itemWhse[lineWhse].orderQty > 0) {            
                 $input.removeClass('qtyOrdered');
                 $input.addClass('qtyOrdered');
             }
	     /* ^^^^ 022000 ^^^^ */
          }
       }
       }
     };

     function changeQty(vThis){
       var  $this = $(vThis)
          , itemNum = $this.closest('.qoCell').data('item')
          , oldQty = $this.data('ordered')
          , availQty = 0
          , nextPOQty = 0           //ROY010003
          , itemPhaseObs = false    //ROY010003
          , prodQty = 0;            //ROY010003
      
       if( $("input[name='boOpt']:checked").length == 0){
          $("input[name='boOpt'][value='2']").prop('checked',true);
       }

       //Prevent nonNumeric or negative values
       if(isNaN(vThis.value) || vThis.value < 0){
          vThis.value = oldQty;
       }
       
       //Full Case check
       if(opts.fullCaseOnly){
          var caseQty = prodObj._item[itemNum].caseQty, 
              numCases,    
              newQty;
          if(!caseQty)caseQty=1;
          if(vThis.value % caseQty != 0){
            $.wam.alert( $.wam.getText('full_case') );
            numCases =  Math.round(vThis.value/caseQty);
            if( numCases < (vThis.value/caseQty) ) numCases++;
            vThis.value = numCases * caseQty;
          }
       }

      /***** v ROY010003 v *****/
      // set the running total of order qty for this row, send in the current row
       setOrderQtyTotal($this.closest(".product-description"));
       try { itemPhaseObs = (prodObj._item[itemNum].isPhaseOut || prodObj._item[itemNum].isObsolete); }catch(e){};

       //Check for backorder and prompt
       if(opts.gridMode == 'color'){
          var rowWhse = $this.closest('.product-item').data('warehouse');
          try{ 
              realAvailQty = prodObj._item[itemNum]._itemWhse[rowWhse].realAvailQty;
           availQty     = prodObj._item[itemNum]._itemWhse[rowWhse].availQty;
              prodQty      = prodObj._item[itemNum]._itemWhse[rowWhse].prodQty;                
              nextPOQty    = prodObj._item[itemNum]._itemWhse[rowWhse].onOrder[0].poQty;       
          } catch (e){} 
       }else{
          try{ 
              realAvailQty = prodObj._item[itemNum]._itemWhse[selectedWhse].realAvailQty;
         availQty     = prodObj._item[itemNum]._itemWhse[selectedWhse].availQty;
              prodQty      = prodObj._item[itemNum]._itemWhse[selectedWhse].prodQty;                
              nextPOQty    = prodObj._item[itemNum]._itemWhse[selectedWhse].onOrder[0].poQty;   
        } catch (e){} 
       }
      
       // are we out of production qty as well as avail qty?
       if((vThis.value.toFloat(0) > (availQty + prodQty)) && !itemPhaseObs) {
           if(opts.getOnOrder){
               var query = 'action=getItemOnOrder&item=' + itemNum + '&page=' + $.wam.opts.page;
               $.wam.block();
               $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,function(data){ getOnOrderAlert_callback(data,itemNum,vThis,0); },'application/json','json',false);
           }else{
              openAvailableAlert(itemNum,"",0);
           }
       }
       // is the qty between on-hand and avail?
       else if((vThis.value.toFloat(0) > realAvailQty) && (vThis.value.toFloat(0) <= availQty) && !itemPhaseObs){  
           if(opts.getOnOrder){
               var query = 'action=getItemOnOrder&item=' + itemNum + '&page=' + $.wam.opts.page;
               $.wam.block();
               $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,function(data){ getOnOrderAlert_callback(data,itemNum,vThis,1); },'application/json','json',false);
           }else{
              openAvailableAlert(itemNum,"",1);
           }
       }
       else if((vThis.value.toFloat(0) > availQty) && !itemPhaseObs){
         if(opts.getOnOrder){
            var query = 'action=getItemOnOrder&item=' + itemNum
                      + '&page=' + $.wam.opts.page;
            $.wam.block();
            $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,function(data){ getOnOrder_callback(data,itemNum,vThis); },'application/json','json',false);
         }else{
           openBackorderDialog(itemNum,vThis);
         }
       }
       // is the qty > avail and item is obsolete
       else if((vThis.value.toFloat(0) > realAvailQty) && itemPhaseObs){
           openObsoleteAlert(itemNum,$(vThis));
       }
      /***** ^ ROY010003 ^ *****/

     };
     
     /***** v ROY010003 v *****/
     function openObsoleteAlert(itemNum,vThis){
         var smsg = $.wam.getText('bo_obs_item'),
             availQty = 0;
	
         $.wam.confirm({size: "medium",
                        title: "Production Warning",
                        message: smsg,
                        buttons: {
                            cancel: {
                                label: '<i class="fa fa-times"></i> Cancel'
                            },
                            confirm: {
                                label: '<i class="fa fa-check"></i> Confirm'
                            }
                        },
                        callback: function(ans){
                             if(ans){   // accept avail qtys
                                 try{ availQty = prodObj._item[itemNum]._itemWhse[selectedWhse].realAvailQty }catch(e){}
                                 vThis.val( availQty ).focus();
                                 setOrderQtyTotal(vThis.closest(".product-description"));
                             }
                             else{  // cancel qtys
                                 vThis.val( 0 ).focus();
                                 setOrderQtyTotal(vThis.closest(".product-description"));
                             }
                            }
         });
     } // openObsoleteAlert()

     function setOrderQtyTotal(rowObjs){
          rowObjs.each(function(i){
       //var qtyObjs = $(this).find(".qoInput");
       var orderQty = 0;
           
            $(this).find(".qoInput").each(function(j){
        var qty = parseInt($(this).val());
        
        if (isNaN(qty))
         qty = 0;
        
        orderQty += qty;  
       });
      
       $(this).find(".productCount").val(orderQty);
      });
      
     } // setOrderQtyTotal()

     /****************************************************/
          /*********************************************************/
    
     function getOnOrderAlert_callback(data,itemNum,vThis,imode)
     {  
      var itemWhseArr = [],
          nextAvailDate;
      
      try{ itemWhseArr = data.ProDataSet.itemWhse; } catch(e){}; 
            
      if(typeof itemWhseArr == 'object' && itemWhseArr.length)
      {
       for(var i=0;i<itemWhseArr.length;i++)
       {
        try { nextAvailDate = itemWhseArr[i].nextEstArrival; } catch(e){};
       }
      }
      
      openAvailableAlert(itemNum,nextAvailDate,imode,$(vThis));
     };
    
     /********************************/

     function openAvailableAlert(itemNum, nextAvailDate, imode,vThis)
     { 
      var msg   = "",
          d     = "",
          size  = "";
      
      d = formatDate(nextAvailDate);
      
      if (imode == 0) {
          msg = $.wam.getText('bo_not_avail');
          size = "medium";
      }
      else{
          msg = $.wam.getText('prod_qty_warn')
          size = "small";
      }
      
      $.wam.unblock();
      
      $.wam.alert
      ({
       size: size,
       title: "Production Warning",
       message: msg,
      callback: function() {}
      });

     }; //openAvailableAlert()
    
     /**************************************************/
     /***** ^ ROY010003 ^ *****/
    
     function getOnOrder_callback(data,itemNum,vThis){ 
        var itemWhseObj = {},
            itemWhseArr = [];
        try{ itemWhseArr = data.ProDataSet.itemWhse; }catch(e){}; 
        try{ boAsnObj = data.ProDataSet.asnInfo; }catch(e){}; 
        if(typeof itemWhseArr == 'object' && itemWhseArr.length){
           for(var i=0;i<itemWhseArr.length;i++){
             try{ 
               prodObj._item[itemNum]._itemWhse[itemWhseArr[i].warehouse.toLowerCase()].onOrderQty = itemWhseArr[i].onOrderQty;
               prodObj._item[itemNum]._itemWhse[itemWhseArr[i].warehouse.toLowerCase()].onOrderQtyHtml = itemWhseArr[i].onOrderQtyHtml;               
             }catch(e){};
           }
        }

        openBackorderDialog(itemNum,vThis);
     };

     function openBackorderDialog(itemNum,vThis,vWhse){ 
         //Update Qty display in backorder overlay
         var stockHTML = "",
             stockMsg = "",
             whseName = "",
             availQty = 0,
             hasOnOrder = false,
             otherWhseStock = false;         
         if(typeof vWhse == 'undefined'){ vWhse = selectedWhse; } 
         try{ availQty = prodObj._item[itemNum]._itemWhse[vWhse].availQty; } catch (e){}
       
         if (availQty <= 0 ){
            stockMsg = $.wam.getText('bo_oos');
         }else{
            stockMsg = $.wam.getText('bo_too_low');
         }
         for(whse in prodObj._item[itemNum]._itemWhse){
            whseName = whse;
            try{ whseName = _whseList[whse].whseDesc; }catch(e){}

            stockHTML += "<tr><td>" + whseName + "</td>" 
                      +  "<td>" + prodObj._item[itemNum]._itemWhse[whse].availQtyHtml + "</td>"
                      +  "<td class='qoBoOnOrder'>" + prodObj._item[itemNum]._itemWhse[whse].onOrderQtyHtml + "</td></tr>";
            if(prodObj._item[itemNum]._itemWhse[whse].onOrderQty > 0){ hasOnOrder = true; }
          if(whse != vWhse && prodObj._item[itemNum]._itemWhse[whse].availQty > 0 ){
              otherWhseStock = true;
            }

         }
         $(".boChoiceTableInner",".backorderDialog").html(stockHTML);
         if(hasOnOrder){
           $(".qoBoOnOrder",".backorderDialog").show();
         }else{
           $(".qoBoOnOrder",".backorderDialog").hide();
         }
         $(".boMessage",".backorderDialog").html(stockMsg);
         
         //Update valid backorder options
         var whseAllowBo = false;
         try{ whseAllowBo = _whseList[vWhse].allowBackorder;  }catch(e){};
         if (whseAllowBo) {
             whseAllowBo = !(prodObj._item[itemNum].isPhaseOut || prodObj._item[itemNum].isObsolete);
         }
         if(whseAllowBo){
            $(".boOpt2,.boOpt3",".backorderDialog").show();
         }else{
            $(".boOpt2,.boOpt3",".backorderDialog").hide();
         }
         if(otherWhseStock){
            $(".boOpt1",".backorderDialog").show();
         }else{
            $(".boOpt1",".backorderDialog").hide();
         }
         if(availQty <= 0){
            $(".boOpt4",".backorderDialog").hide();
         }else{
            $(".boOpt4",".backorderDialog").show();
         }
         //Show backorder dialog
         $.wam.block();
          $.wam.moveOverlay(".backorderDialog");
          $(".backorderDialog").data('fromInput',vThis).show();
         
          if( !$("input[name='boOpt']:checked",".backorderDialog").is(':visible') ){
           $("input[name='boOpt']:visible:first",".backorderDialog").trigger('click');
          }
     };

     function showExpectedStock(){
        var showExpected = $("#showPO").is(':checked'),
            cookieVal = $("#poDays").val();
        
        if(showExpected){
           if( isNaN(cookieVal) || cookieVal <= 0 ){
              $.wam.alert( $.wam.getText('nan_stock_days') ); 
              return; 
           }
           $.wam.setCookie($.wam.opts.cookieBase + 'showPoDays', cookieVal, null,'/', $.wam.opts.cookieDomain );
        }else{
           $.wam.setCookie($.wam.opts.cookieBase + 'showPoDays', 0, null,'/', $.wam.opts.cookieDomain );
           $.wam.deleteCookie($.wam.opts.cookieBase + 'showPoDays','/', $.wam.opts.cookieDomain );           
        }
       
        var reloadHref = document.location.href;
        if(reloadHref.indexOf('warehouse=') == -1){                      
           reloadHref += (reloadHref.indexOf('?') == -1)?'?':'&';  
           reloadHref += 'warehouse=' + selectedWhse;
        }else{
          var queryWhse = $.wam.getParam('warehouse')
          reloadHref = reloadHref.replace('warehouse=' + queryWhse,'warehouse=' + selectedWhse);
        }
        document.location.href = reloadHref;
            
     };

     function selectBoOpt(){
       var $input   = $( $(".backorderDialog").data('fromInput') ),
           optNum   = $("input[name='boOpt']:checked").val(),
           availQty = 0,
           keepOpen = false,
           itemNum  = $input.closest('.qoCell').data('item'),
           runQOA   = false;
       
       switch(optNum){
          case "1": //Select another warehouse
                $input.val( $input.data('ordered') );
                $('select[name="whseSelect"]').focus();
          break;
          case "2": //Ship avail and backorder balance
             runQOA = true;
          break;
          case "3": //Ship Complete when avail
            if( boAsnObj && boAsnObj.length ){
               var origZ = $(".backorderDialog").css('z-index');
               keepOpen = true; 
               var asnHTML = "<table class='table table-striped'>" +
                             "<thead><tr><th>" + $.wam.getText('on_ord') + "</th><th>" + $.wam.getText('est_date') + "</th></tr></thead>" +
                             "<tbody>";
               $(boAsnObj).each(function(){ 
                  if(this.warehouse && this.warehouse.toLowerCase() == selectedWhse)
                    asnHTML += '<tr><td>' + String(this.qty) + '</td><td>' + this.estDate + '</td></tr>';
               });
               asnHTML += '</tbody></table>';
               $("#pageOverlay").hide();
               $(".backorderDialog").css('z-index',99);
               $.wam.confirm({
                 title: $.wam.getText('next_avail_dates'),
                 message: asnHTML,
                 buttons: {
                    'cancel': { label: $.wam.getText('cancel'),
                                className: 'btn-default pull-left'
                              },
                    'confirm': { label: $.wam.getText('accept'),
                                 className: 'btn-primary pull-right'
                               }
                 },
                 callback: function(ans){
                   if(ans){
                      //shipComplete set on order in addToCartQuickorder... 
                      $.wam.store('completeOnly',true);
                      $.wam.moveOverlay(".backorderDialog",true); // Stop scroll trigger                         
                      $(".backorderDialog").stop().fadeOut(100);  
                      keepOpen = false;
                      $('.modal-dialog','.bootbox').removeClass('modal-sm');
                      $(".backorderDialog").css('z-index',origZ);
                      $.wam.unblock();  
                   }else{
                     $(".backorderDialog").css('z-index',origZ);
                     $("#pageOverlay").show();
                   }
                 }
               });
               $('.modal-dialog','.bootbox').addClass('modal-sm');
            }
            runQOA = true; //021002
          break;
          case "4": //Take only avail stock
             try{ availQty = prodObj._item[itemNum]._itemWhse[selectedWhse].realAvailQty }catch(e){}
             $input.val( availQty ).focus();
             runQOA = true; //021002
          break;
          case "5": //select another product
                $input.val( $input.data('ordered') );
                $("#qoSearchInput").focus();
                $.wam.scrollTo("#qoSearchInput");
          break;
          case "6": //Cancel BO qty
                $input.val( $input.data('ordered') ).focus();
          break;
       }
       
       // set the running total of order qty for this row, send in the current row
       setOrderQtyTotal($input.closest(".product-description"));
       
      if(!keepOpen){
         $.wam.moveOverlay(".backorderDialog",true); // Stop scroll trigger
         $.wam.unblock();         
         $(".backorderDialog").stop().fadeOut(100);
       }

       if(runQOA){
       quickorderAdd();
       }
     }
     /***** v ROY010003 v *****/
     function confirmBOStock(){
        var $input   = $( $(".backorderDialog").data('fromInput') ),
            availQty = 0,
            keepOpen = false,
            itemNum  = $input.closest('.qoCell').data('item'),
            runQOA   = false;
      
        try{ availQty = prodObj._item[itemNum]._itemWhse[selectedWhse].realAvailQty }catch(e){}
        $input.val( availQty ).focus();

        $.wam.moveOverlay(".backorderDialog",true); // Stop scroll trigger
        $.wam.unblock();         
        $(".backorderDialog").stop().fadeOut(100);
     }
     function cancelBOStock(){
        var $input   = $( $(".backorderDialog").data('fromInput') ),
            availQty = 0,
            keepOpen = false,
            itemNum  = $input.closest('.qoCell').data('item'),
            runQOA   = false;

        $.wam.moveOverlay(".backorderDialog",true); // Stop scroll trigger
        $.wam.unblock();         
        $(".backorderDialog").stop().fadeOut(100);
     }
     /***** ^ ROY010003 ^ *****/

     function quickorderAdd(goToCart){
       var hasWhseSelect = $prod.find("select[name='whseSelect']").length,
           whse,    
           postJSON = {'qoItem':[]};
       
       if( typeof goToCart != "boolean" ) goToCart = false;
       
       if(hasWhseSelect){
          whse = $prod.find("select[name='whseSelect']").val()
       }else{
          whse = _whseList[selectedWhse].whse;
       }

       $prod.find('input.qoInput').each(function(){ 
          if(!isNaN(this.value) && this.value != ""){
             if(!hasWhseSelect){
                whse = $(this).closest('.product-item').data('warehouse');
             } 
            /* Removed condition on has warehouse selected ROY010001*/
             postJSON.qoItem.push({'itemNumber':this.name, 'qty': this.value, 'warehouse':whse });
          }
       });
       quickorderAddAjax(postJSON,goToCart);
     };
     
     function quickorderAddLine(vThis){
       var $row = $(vThis).closest('.product-item'),
           whse = $(vThis).data('warehouse'),
           postJSON = {'qoItem':[]};

 /*ROY010001*/
       if( typeof whse == 'undefined'){  //If not colorWhse mode get from dropdown
         whse = $prod.find("select[name='whseSelect']").val()
       }
      
      if (typeof whse == 'undefined' || ""){
        whse = _whseList[selectedWhse].whse;
       }      
 /*ROY010001*/
       $row.find('input.qoInput').each(function(){ 
          if(!isNaN(this.value) && this.value != ""){
             postJSON.qoItem.push({'itemNumber':this.name, 'qty': this.value, 'warehouse':whse });
          }
       });

       quickorderAddAjax(postJSON);
     };

     function quickorderAddAjax(postJSON,goToCart){     
        var query = 'action=qoAddToCart&content=json';
        if( $.wam.store('completeOnly') ){
           query+='&completeOnly=true';
           $.wam.store('completeOnly',null);
        }
        $("#gridMsg").html('').prop('class','');
       if(typeof postJSON == 'object' && postJSON.qoItem && postJSON.qoItem.length){
         $.wam.ajaxPost('/wam_tmpl/cart.p?' + query,'POST',JSON.stringify(postJSON),function(data){quickorderAddAjaxCallback(data,goToCart);},'application/json','json',true);
       }else{
         $('#gridMsg').html( $.wam.getText('qo_no_qty') ).addClass('alert alert-danger');
         $.wam.scrollTo('#gridMsg');
       }
     };
     function quickorderAddAjaxCallback(data,goToCart){
        var sMsg, orderObj;
       
        if (goToCart) {
          $.wam.golink('/wam_tmpl/cart.p','page=' + $.wam.opts.defPages.cart);
          return;
        }
       
        if(typeof data.msg == 'object' && data.msg.length){
          sMsg = data.msg[0].msg;
          if(data.msg[0].success)
             $('#gridMsg').addClass('alert alert-success');
          else
             $('#gridMsg').addClass('alert alert-danger');
          $('#gridMsg').html(sMsg);
          scrollToMsg();
        }
         
       /* GTM - Quickorder AddtoCart action - 022200 */
       if ($.wam.opts.gtmID != '' && typeof data.order[0].orderLine == 'object'){ /* 022702 */
            products = [];
            for (var i=0; i<data.order[0].orderLine.length; i++){
                var dataObj = data.order[0].orderLine[i];
                    products.push ({
                        'item_id': dataObj.styleCode.toUpperCase(),                 /* EC-564 */
                        'item_name': dataObj.styleDesc.toUpperCase(),               /* EC-564 */
                        'item_category': dataObj.category,                          /* EC-564 */
                        'item_variant': dataObj.colorDesc + ' ' + dataObj.sizeDesc, /* EC-564 */
                        'price': dataObj.price,
                        'quantity': dataObj.qty,                                    /* EC-564 */
                    })
            }
            dataLayer.push({
                'event': 'add_to_cart',              /* EC-564 */
                'ecommerce': {
                    'currency': opts.currency,       /* EC-564 */
                    'items': products                /* EC-564 */
                }
            });
        }
        if(typeof data.order == 'object' && data.order.length){
           var itemNum, whse, qty, boqty;
           orderObj = data.order[0];
           
           deisgnGridRefresh = true;

           //Clear order / Bo qtys before adding back
           if(typeof orderObj.orderLine == 'object' && orderObj.orderLine.length){
             for(var i=0;i<orderObj.orderLine.length;i++){
                itemNum = String(orderObj.orderLine[i].itemNumber).toLowerCase(); //need String in case itemNum is numeric only
                whse = orderObj.orderLine[i].warehouse.toLowerCase();
                if(typeof prodObj._item[itemNum] == 'object' && 
                   typeof prodObj._item[itemNum]._itemWhse == 'object' && 
                   prodObj._item[itemNum]._itemWhse[whse] )
                {
                   prodObj._item[itemNum]._itemWhse[whse].orderQty = 0;
                   prodObj._item[itemNum]._itemWhse[whse].boQty = 0;
                }
             }
           }
           //Clear design ordered qtys
           if(typeof prodOrderedJSON == 'object' && prodOrderedJSON.length){
              for(var j=0;j<prodOrderedJSON.length;j++){
               prodOrderedJSON[j].qtyAvail = 0;
               prodOrderedJSON[j].qty = 0;
              }
           }
           var orderedFound = false;
           //Update data-ordered totals
           if(typeof orderObj.orderLine == 'object' && orderObj.orderLine.length){          
           for(var i=0;i<orderObj.orderLine.length;i++){
              itemNum = String(orderObj.orderLine[i].itemNumber).toLowerCase(); //need String in case itemNum is numeric only
              whse = orderObj.orderLine[i].warehouse.toLowerCase();
              if(typeof prodObj._item[itemNum] == 'object' && 
                 typeof prodObj._item[itemNum]._itemWhse == 'object' && 
                 prodObj._item[itemNum]._itemWhse[whse] )
              {
                 orderedFound = false;
                 prodObj._item[itemNum]._itemWhse[whse].orderQty += orderObj.orderLine[i].qty;
                 prodObj._item[itemNum]._itemWhse[whse].boQty += orderObj.orderLine[i].boQty; 
                 if(laUseDecorator && orderObj.orderLine[i].qty > 0){
                   laHasOrderedProd = true;
                   if(typeof designObj == 'object'){
                     $(".qoApplyDesignBtn").show();
                   }
                   if(typeof prodOrderedJSON == 'undefined'){
                     prodOrderedJSON = [];
                   }
                     if(typeof prodOrderedJSON == 'object' && prodOrderedJSON.length){
                        for(var j=0;j<prodOrderedJSON.length;j++){
                           if(prodOrderedJSON[j].itemNumber.toLowerCase() == itemNum && prodOrderedJSON[j].warehouse.toLowerCase() == whse){
                              prodOrderedJSON[j].qty += orderObj.orderLine[i].qty + orderObj.orderLine[i].boQty;
                            orderedFound = true;
                            laHasOrderedProd = true;
                           }
                        }
                     }
                   if(!orderedFound){
                      prodOrderedJSON.push({ itemNumber: itemNum
                                            , warehouse: whse
                                            , colorCode: prodObj._item[itemNum].colorCode                           
                                            , sizeCode: prodObj._item[itemNum].sizeCode
                                            , qty: orderObj.orderLine[i].qty + orderObj.orderLine[i].boQty
                                            , qtyApplied: 0
                                            , qtyAvail: orderObj.orderLine[i].qty + orderObj.orderLine[i].boQty
                                          });
                      laHasOrderedProd = true;
                   }
                   
                   
                 }
                 //Update _itemLink so gridRender will see changes 
                 try{
                    prodObj._itemLink[itemNum]._itemWhse[whse].orderQty = prodObj._item[itemNum]._itemWhse[whse].orderQty;
                    prodObj._itemLink[itemNum]._itemWhse[whse].boQty    = prodObj._item[itemNum]._itemWhse[whse].boQty;
                 }catch(e){  }
              }
              

           }
           }
           //Update design availQty
           if(typeof prodOrderedJSON == 'object' && prodOrderedJSON.length){
              for(var j=0;j<prodOrderedJSON.length;j++){
               prodOrderedJSON[j].qtyAvail = prodOrderedJSON[j].qty - prodOrderedJSON[j].qtyApplied;               
              }
           }           
           updateInputData(orderObj);

           if(typeof $.wam.hdrCart != 'undefined'){
             $.wam.hdrCart.updateOrder(orderObj);
             $.wam.hdrCart.refreshDisplay();
           }
        }
     };
     function quickorderNotify(vThis){        
        var $this = $(vThis),
            color = $this.data('color'),
            whse  = $this.closest('.product-item').data('warehouse');

        if (typeof whse  == 'undefined' || whse  == '') whse  = selectedWhse; 
        if (typeof color == 'undefined' || color == '') color = $("#colorSelect").val(); 

        var query = 'action=setItemBackorderNotice' 
                  + '&style=' + prodObj.styleCode
                  + '&color=' + color
                  + '&warehouse=' + whse
                  + '&content=json'
                  + '&page=' + $.wam.opts.page;
        
        $("#gridMsg").html('').prop('class','');

        $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,function(data) { quickorderNotifyCallback(data,$this) },'application/json','json',true);

     };

     function quickorderNotifyCallback(data,$this) {
        var sMsg;
        if(typeof data == 'object' && data.length){
           sMsg = data[0].msg;       
           if(!data[0].success){
             $('#gridMsg').addClass('alert alert-danger').html(sMsg); 
             scrollToMsg();
           }else{
             $this.toggleClass('selected'); 
             //Update product data 
             var setNotify = $this.hasClass('selected');              
             var whse = $this.closest('.product-item').data('warehouse');
             $this.closest('.product-item').find('.product-elem').not('.product-elem-disabled').find('.qoCell').each(function(){
                var itemNum = $(this).data('item');
                if(typeof prodObj._itemLink[itemNum] == 'object' && 
                   typeof prodObj._itemLink[itemNum]._itemWhse == 'object' && 
                   prodObj._itemLink[itemNum]._itemWhse[whse] )
                {
                   prodObj._itemLink[itemNum]._itemWhse[whse].notify = setNotify;
                }  
             });
           
           }
        }
     };

     var ppObj, ppList;
     function openPrepack(vThis){
       var $this = $(vThis),
           vHTML = "",
           ppColor, 
           ppWhse = $this.closest('.product-item').data('warehouse'),
           colorDesc; 

       if( opts.gridMode == 'whse'){
           ppColor = String($this.closest('.product-item').data('color')).toLowerCase();
           colorDesc = $this.closest('.product-item').find('.gridColorDesc').text(); 
       }else{
           ppColor = $("#colorSelect").val().toLowerCase();
           colorDesc = $("option:selected","#colorSelect").text();         
       }

       $(".prepackTitleColor",'#prepackDialog').html( colorDesc );
       $('#prepackDialog').data('colorCode',ppColor);
       $('#prepackDialog').data('warehouse',ppWhse);

       //Reset prepack data 
       ppObj = {};
       ppList = [];
       for(var i=0;i<prepackObj.length;i++){
          if(prepackObj[i].colorCode == ppColor){
             if(typeof ppObj[ prepackObj[i].prepackCode ] == 'undefined' ){
                ppObj[ prepackObj[i].prepackCode ] = { desc: prepackObj[i].description, sizeList: [] };
                ppList.push({code:prepackObj[i].prepackCode, desc:prepackObj[i].description });
             }
             ppObj[ prepackObj[i].prepackCode ].sizeList.push({ sizeCode: prepackObj[i].sizeCode
                                                               ,sizeDesc: prepackObj[i].sizeDesc
                                                               ,itemNumber: prepackObj[i].itemNumber
                                                               ,qty: prepackObj[i].quantity
                                                             });
          }
       }

       //Build UI for prepack dialog
       vHTML = "<option value='' selected></option>";
       for(var i=0;i<ppList.length;i++){
          vHTML += "<option value='" + ppList[i].code + "'>" + ppList[i].desc + "</option>";
       }
       $("#prepackSelect").html(vHTML);
       if(ppList.length == 1) $("#prepackSelect").val( ppList[0].code );
       $("#prepackSelect").trigger('change'); 
       $('#prepackDialog').modal({backdrop:'static'});
     };
     
     function changePrepack(){
        var ppCode = $(this).val()
            vHTML = "";
       $(".ppMessage",'#prepackDialog').html('').removeClass('alert alert-success alert-danger'); 
       if(typeof ppObj[ppCode] != 'undefined' ){
           vHTML = "<thead>";
           for(var i=0;i<ppObj[ppCode].sizeList.length;i++){
             vHTML += "<th>" + ppObj[ppCode].sizeList[i].sizeDesc + "</th>";
           }
           vHTML += "</thead><tbody><tr>";
           for(var i=0;i<ppObj[ppCode].sizeList.length;i++){
             vHTML += "<td>" + String(ppObj[ppCode].sizeList[i].qty) + "</td>";
           }
           vHTML += "</tr></tbody>";
           $("#prepackTable").html(vHTML); 
        }else{
          $("#prepackTable").html('<tobdy><tr><td>' + $.wam.getText('sel_prepack') + '</td></tr></tbody>'); 
        }
     };
     function prepackChange(){
       this.value = $.trim(this.value);
       if(isNaN(this.value)) this.value = '';
       if(!isNaN(this.value) && this.value != '' && this.value < 0 ){
         this.value = this.value * -1;
       }
       
     };     
     function applyPrepack(){
       var ppColor = $('#prepackDialog').data('colorCode'),
           ppWhse  = $('#prepackDialog').data('warehouse'),
           ppCode  = $('#prepackSelect').val(),
           ppQty   = $('#prepackQty').val(),
           ppItem,
           $ppItemObj,
           ppItemQty;
       
       $(".ppMessage",'#prepackDialog').html('').removeClass('alert alert-success alert-danger');
       
       if( ppCode == '' || ppCode == '' ){
         $(".ppMessage",'#prepackDialog').html( $.wam.getText('no_sel_prepack') ).addClass('alert alert-danger');         
         return;
       }
       if( isNaN(ppQty) || $.trim(ppQty) == '' ){
         $(".ppMessage",'#prepackDialog').html( $.wam.getText('nan_prepack') ).addClass('alert alert-danger');                  
         return;
       }

       if( typeof ppObj[ppCode] == 'object'){
          for(var i=0;i<ppObj[ppCode].sizeList.length;i++){
              ppItem = ppObj[ppCode].sizeList[i].itemNumber.toLowerCase();
              ppItemQty = ppObj[ppCode].sizeList[i].qty * ppQty;
              if( opts.gridMode == 'whse'){
                 $ppItemObj = $grid.find("input[name='" + ppItem + "']");
              }else{
                 $ppItemObj = $grid.find(".product-item[data-warehouse='" + ppWhse + "']").find("input[name='" + ppItem + "']");
              }              
              if( $("#ppClearQty").prop('checked') ){
                 if(ppItemQty > 0){
                    $ppItemObj.val(ppItemQty)
                 }else{
                    $ppItemObj.val('')
                 }
              }else{
                 if(ppItemQty > 0){
                    $ppItemObj.val( parseInt(ppItemQty) + parseInt($ppItemObj.val()) );
                 }
              }
          }
          $('#prepackDialog').modal('hide');
       }
     };

     // TMP - move into layout js as $.wam.moveDialog... 
     moveDialog = function(vElementID){
      vElementID = "#" + vElementID;
      $Elem = $(vElementID);
      if($Elem.length){
      $Elem.css("top", ($(window).height() - $Elem.outerHeight() ) / 2 + $(document).scrollTop() )
           .css("left", ($(window).width() - $Elem.outerWidth() ) / 2 + $(document).scrollLeft() );
      }
     }      

     //--- Begin Decorator Logic --------
     var designObj, groupName, decoratedIcon = '<i class="fa fa-picture-o qoDecImage"></i>';
     function openApplyDesign(){
        var query = 'action=getDesigns&content=json&productID=' + prodObj.styleCode;
        if( deisgnGridRefresh ) query += '&getGrid=true';
        $.wam.block();
        $("body").append("<div id='loadingDesign'><h3 id='loadingDesignMsg'>" + $.wam.getText('deco_loading') + " ...<br><img src='" + $.wam.opts.imgURL + "/loading2.gif' alt='loading...' style='padding-top:20px'></h3></div>");
        moveDialog('loadingDesign');
        $.wam.ajaxPost('/wam_tmpl/web_decorate.p','GET',query,applySavedDesign,'application/json','json',false);
     }
     base.applySavedDesign = function(data,vGroupName){
       var vSelHTML = "",
           vTmpHTML = "";

       if(typeof data == 'object'){
          if(typeof data == 'object' && typeof data.ProDataSet == 'object'){
             data = data.ProDataSet;
          }
          if(typeof data == 'object' && typeof data.html == 'object'){
             $("#applyDesignGridOuter").html(data.html[0].designGrid);
             deisgnGridRefresh = false;
          }
          //ajaxPost uses complete function and data passed to callback is inconsistant. Success works for JSON but breaks on some XML responses... 
          if(typeof data == 'object' && typeof data.responseJSON == 'object'){
             data = data.responseJSON;
          }
          designObj = $.extend(true, [], data.design);
       }
       
       $("#loadingDesign").remove();

       $("#decMsgArea","#applyDesignDialog").hide().css('height','auto');

       if(designObj && designObj.length){
         $.wam.keepBlock = true;
         $.wam.product.closeDecorator(true);
         $.wam.keepBlock = false;
         $(".qoApplyDesignBtn").show();
         if(typeof vGroupName == 'undefined'){
           vGroupName = ""; 
           if(designObj.length == 1){
              vGroupName = designObj[0].groupName;
           }else{
              vGroupName = groupName;
           }
         }
         groupName = vGroupName;
         $.each(designObj,function(idx){
            vSelHTML += "<div class='designPreview";
            if(this.groupName == groupName) vSelHTML += " selected";
            vSelHTML += "' data-design='" + this.groupName + "'>"
                     +  "<div class='designTitle'>" + this.groupName + "</div>";
                     
            if(this.location && this.location.length){
               vTmpHTML = "";
               var extraClass = "";
               var widthPercent = 100 / this.location.length;
               $.each(this.location,function(idx2){

                  if(idx2 == 0){
                    vSelHTML += "<img class='designImg' src='" + this.img + "'>";
                    extraClass = " selected";
                  }else{
                    extraClass = '';
                  }
                  vTmpHTML += "<div class='designLocPreview" + extraClass + "' data-location='" + this.location + "' style='width:" + widthPercent + "%'>"
                           +   "<img src='" + this.img + "'>"
                           +   "<div class='designLocTitle'>" + this.location + "</div>"
                           +  "</div>";
               });

            }
            vSelHTML += "<div class='locationPreview clearfix'>" + vTmpHTML + "</div></div>";

         });
         
         //$(".selectedDesign","#applyDesignDialog").html(groupName);
         if( $("#applyDesignDialog").length < 1 ){
           $('body').append("<div id='applyDesignDialog'></div>");
         }
         $.wam.block();
         $("#selectDesignInner").html(vSelHTML);
         groupName = "";         
         $(".designPreview.selected").trigger('click'); // run selectDesign to update qty and avail values 
         
         setTimeout(function(){
         //Calc widths for slider
         $("#applyDesignDialog").css('left','-9999px').show();
         designSliderInit();
         $("#applyDesignDialog").css('left','auto').show();
         moveDialog('applyDesignDialog');
         
         if( parseInt($('#applyDesignDialog').css('top'),10) < 25 )
            $('#applyDesignDialog').css('top',25);
         
         $("input, a","#applyDesignDialog").prop('disabled',false);
         $(".btnQoDesignGrid").show();
          
         },150); // Add delay to ensure images heights are included
        

         //$(window).on('scroll.designDialog',function(){ moveDialog('applyDesignDialog'); });
       }else{
         if(data && data.length && data[0].msg){
           $.wam.alert(data[0].msg);
           $(".bootbox-alert").css('z-index',99999999); // Force ontop of liveart iframe
         }
       }
     }

     //----------

     function closeApplySavedDesign(){ 
       if( $("input.unapplied","#applyDesignDialog").length && !confirm( $.wam.getText('deco_unapplied') ) ){
          return;
       }
       $.wam.unblock();
       $("#applyDesignDialog").hide();
       $(".la_design_input","#applyDesignGrid").removeClass('unapplied');
     }

     //----------

     function designSliderInit(){

        var selInnerWidth = 0, selInnerHeight = 0, titleHeight = 0;
      
        if( $('.designPreview','#selectDesignInner').length ){
           $('.designTitle','#selectDesignInner').each(function(){
             titleHeight = ($(this).outerHeight(true) > titleHeight)?$(this).outerHeight(true):titleHeight;
           });   
           $(".designTitle").height(titleHeight);
           $('.designPreview','#selectDesignInner').each(function(){
             selInnerWidth += $(this).outerWidth(true);
             selInnerHeight = ($(this).outerHeight(true) > selInnerHeight)?$(this).outerHeight(true):selInnerHeight;
           });
           $("#selectDesignInner").width(selInnerWidth)
           $("#selectDesign").height(selInnerHeight);

           if( $("#selectDesignInner").outerWidth(true) > $("#selectDesign").width() ){
             $("#selDesignLeft").show();
           }
        }else{
           $("#selectDesignInner").html('<h3 style="text-align:center">' + $.wam.getText('no_design') + '</h3>').css('height','auto').width( $("#selectDesign").width() );
           $("#selDesignLeft,#selDesignRight").hide();
           $("#selectDesign").height( $("#selectDesignInner").outerHeight() );
        }

     }

     function selectDesign(){

       var $this = $(this);
       if( groupName == $this.data('design') ) return;

       clearDecMsg();
       if( $("input.unapplied","#applyDesignDialog").length && !confirm( $.wam.getText('deco_unapplied_switch') ) ){
          return;
       }
       $(".designPreview.selected","#applyDesignDialog").removeClass('selected');
       $this.addClass('selected');
       groupName = $this.data('design');
       $(".selectedDesign","#applyDesignDialog").html(groupName);
       updateDesignGrid(groupName);
       $("#applyDesignForm").slideDown('fast');
     }

     //----------

     function updateDesignGrid(vGroupName){
       var color,whse,ordered,$row,$cell,ordObj = {},designOrdObj = {};
       for(var i=0; i<designObj.length; i++) {
          if(designObj[i].groupName == vGroupName){
            designOrdObj = makeOrderedAssoc('warehouse','itemNumber',designObj[i].designOrdered);
            break;
          }
       }
       ordObj = makeOrderedAssoc('warehouse','itemNumber',prodOrderedJSON);

       $("tr","#applyDesignGrid tbody").each(function(){ 

          $row = $(this);
          color = $row.data('color');
          whse  = $row.data('warehouse');

          $(".laGridCell",this).each(function(){ 
             $cell = $(this);
             var itemKey = whse + '_' + $cell.data('item');
             itemKey = itemKey.toLowerCase();
             if(typeof ordObj[itemKey] == 'object'){
                if(typeof designOrdObj[itemKey] == 'object' && designOrdObj[itemKey].qty > 0 ){
                   $cell.find('.la_design_input').val(designOrdObj[itemKey].qty)
                                                 .data('qtyAvail',ordObj[itemKey].qtyAvail + designOrdObj[itemKey].qty)
                                                 .data('origVal',designOrdObj[itemKey].qty);
                }else{
                   $cell.find('.la_design_input').val('').data('qtyAvail',ordObj[itemKey].qtyAvail).data('origVal',0);
                }
                $cell.find('.la_avail').html( ordObj[itemKey].qtyAvail );
             }else{
                $cell.find('.la_avail').html( $cell.find('.la_ordered').html() );
                $cell.find('.la_design_input').val('').data('origVal',0);
             }
          });

       });
       $(".la_design_input","#applyDesignGrid").removeClass('unapplied');
       deisgnGridRefresh = false;
     }

     //----------

     function makeOrderedAssoc(vKey1,vKey2,vArr){
        if(typeof vArr == "undefined" || typeof vArr == "null") return {};
        var newKey,
            newArr = {};
        for(var i=0; i<vArr.length; i++) {
          newKey = vArr[i][vKey1] + '_' + vArr[i][vKey2];
          newKey = newKey.toLowerCase();
          newArr[ newKey ] = $.extend(true,{},vArr[i]);
        }
        return newArr;     
     };

     //----------

     function deleteDesign(){
        if(groupName == '') return;
        var squery = 'action=deleteDesign&designName=' + encodeURIComponent(groupName) + '&productID=' + laProductID;
        if(confirm( $.wam.getText('del_design1') + ' ' + groupName + ' ' + $.wam.getText('del_design2') )){
          clearDecMsg();
          blockDecGrid();
          $.wam.ajaxPost('/wam_tmpl/web_decorate.p','GET',squery,deleteDesign_callback,'application/json','json',false);
        }

     }
     function deleteDesign_callback(data){
       unblockDecGrid();
       if(typeof data == 'object'){
          if(typeof data.ProDataSet == 'object'){
             data = data.ProDataSet;
          }
          if(typeof data.responseJSON == 'object'){
             data = data.responseJSON;
          } 
          if(typeof data.styleOrdered == 'object'){
             prodOrderedJSON = data.styleOrdered;
             decoIconUpdate();
             renderGrid();
          }   
          if(typeof data.msg == 'object'){
             var msgClass;
             if(data.msg[0].errorStatus == 'error'){
                msgClass = 'decMsgError';
             }else{
                $(".designPreview[data-design='" + groupName + "']").remove();
                groupName = '';
                designSliderInit();
                $("#applyDesignForm").slideUp('fast');
                if(!$(".designPreview","#selectDesign").length){
                   $(".btnQoDesignGrid").hide();
                }
                //Redisplay decorated icons in qo grid
                $(".qoDecImage",".orderGrid").remove();
                $(".decoratedText").hide();
                $(".la_design_input","#applyDesignGrid").removeClass('unapplied');
             }
             setDecMsg(data.msg[0].msg,msgClass);
          }
       }

     }

     //----------
     function decoIconUpdate(){
             //Update hasDecoration so we can reRun renderGrid
       if( typeof prodOrderedJSON != "object" ){
         return;
       }
       $.each(prodOrderedJSON,function(){
          try{
            prodObj._item[this.itemNumber]._itemWhse[this.warehouse.toLowerCase()].hasDecoration = (this.qtyApplied > 0);
            console.log("prodObj._item['" + this.itemNumber + "']._itemWhse['" + this.warehouse.toLowerCase() + "'].hasDecoration");
          }catch(e){}          
       });
     }

     //----------

     function designGridSave(){
        var $row,
            $cell,
            cellQty,
            whse,
            squery = 'action=gridSave&designName=' + encodeURIComponent(groupName) + '&productID=' + laProductID, 
            postJSON = {designLine:[]};
        
        $("tr","#applyDesignGrid tbody").each(function(){ 
          $row = $(this);
          color = $row.data('color');
          whse  = $row.data('warehouse');
          $(".laGridCell",this).each(function(){ 
             $cell = $(this);
             cellQty = $cell.find('.la_design_input').val();
             if(cellQty != "" && !isNaN(cellQty)){
                postJSON.designLine.push({ 'whse':whse
                                          ,'itemNumber': $cell.data('item')
                                          ,'qty':cellQty
                                        }); 
             }
          });
        });
        if( postJSON.designLine.length ){
          clearDecMsg();
          blockDecGrid();
          //$.fdm.ajaxPost('web/liveartSaveDesign.p' + squery,'POST',JSON.stringify(postJSON),designGridSave_callback,'json');
          $.wam.ajaxPost('/wam_tmpl/web_decorate.p?' + squery,'POST',JSON.stringify(postJSON),designGridSave_callback,'application/json','json',false);
        }else{
           $.wam.alert( $.wam.getText('no_deco_qty') );
        }
     }

     //----------

     function designGridSave_callback(data){
       unblockDecGrid();
       var cellWhse;
       var $this, $qoStock;
       //Update DesignObj
       if(typeof data == 'object'){
          if(typeof data.ProDataSet == 'object'){
             data = data.ProDataSet;
          }
          if(typeof data.responseJSON == 'object'){
             data = data.responseJSON;
          } 
          if(typeof data.styleOrdered == 'object'){
             prodOrderedJSON = data.styleOrdered;

             //Update hasDecoration so we can reRun renderGrid
             decoIconUpdate();
          }
         
          if(typeof data == 'object' && typeof data.design == 'object'){
            designObj = $.extend(true, [], data.design);
            //Check 0 qty unapplied fields for removal of decorated icon
            $("input.unapplied","#applyDesignGrid").each(function(){
              $this = $(this);
              if(this.value == 0){
                cellWhse = $this.closest('tr').data('warehouse');
                if(cellWhse == selectedWhse){
                   if($this.parent().find('.la_avail').html() == $this.parent().find('.la_ordered').html()){
                     $qoStock = $(".qoStockLevel[data-item='" + this.itemNumber + "']",".orderGrid");
                     $qoStock.find('.qoDecImage').remove();
                   }
                }
              }
            });
            $(".la_design_input","#applyDesignGrid").removeClass('unapplied');
            groupName = ""; // clear selected group so grid will get rebuilt
            $(".designPreview.selected").trigger('click'); // run selectDesign to update qty and avail values  
          }
       }

       //ReRender Grid 
       renderGrid();

       if(typeof data == 'object' && typeof data.msg == 'object'){
         var msgClass;
         if(data.msg[0].errorStatus == 'error'){
           msgClass = 'decMsgError';
         }
         setDecMsg(data.msg[0].msg,msgClass);
       }

     }

     //----------

     function updateGridDecIcons(){
       var $qoStock;
       //Add decorated icon to order grid for applied qtys 
       for(var i=0; i<designObj.length; i++) {
          if(designObj[i].groupName == groupName){
            if(designObj[i].designOrdered && designObj[i].designOrdered.length){
               $.each(designObj[i].designOrdered,function(){ 
                  if( this.warehouse.toLowerCase() == selectedWhse.toLowerCase() ){
                     $qoStock = $(".qoGridItem[data-item='" + this.itemNumber.toLowerCase() + "'] .gridQty",".orderGrid");
                     if( !$qoStock.find('.qoDecImage').length ){
                        $qoStock.prepend(decoratedIcon);
                        $(".decoratedText").show();
                     }
                  }
               });
            }
            break;
          }
       }
     }

     //----------

     function decLineChange(){
       var $this = $(this),
           qtyAvail = $this.data('qtyAvail');
       if(typeof qtyAvail == 'undefined') qtyAvail = $this.data('avail'); //appears to only be missing for ajax added product... 
       $this.val( $.trim($this.val()) );
       if( isNaN($this.val()) ){
          if( typeof $this.data('origVal') != 'undefined' )
           $this.val( $this.data('origVal') );
          else
           $this.val('');
       }
       else if($this.val() == '' && $this.data('origVal') > 0){
          $this.val(0);
       }else if($this.val() > qtyAvail ){
          $this.val(qtyAvail);
       }else if($this.val() < 0 ){
          $this.val(0);
       }
       
       $this.val( Math.floor($this.val()) );  //Truncate Decimals
       
       if($this.val() != '' && !isNaN($this.val()) ){
         $this.parent().find('.la_avail').html(qtyAvail - $this.val());
       }

       if($this.val() != $this.data('origVal')){
         $this.addClass('unapplied');
       }else{
         $this.removeClass('unapplied');
       }

     }
     function blockDecGrid(){
       if(!$(".designOverlay","#applyDesignDialog").length){
          var vW = $("#applyDesignDialog").width(),
              vH = $("#applyDesignDialog").height();
          $("#applyDesignDialog").prepend('<div class="designOverlay" style="width:' + vW +'px;height:' + vH + 'px;opacity:0;position:absolute;background:#000;"></div>');
       }
       $(".designOverlay","#applyDesignDialog").stop().fadeTo('fast',0.60);
     }
     function unblockDecGrid(){
       $(".designOverlay","#applyDesignDialog").stop().fadeOut();
     }
     function setDecMsg(vMsg,vClass){
        if( typeof vClass == 'undefined' ) vClass = 'decMsgSuccess';
        vMsg = '<div class="' + vClass + '">' + vMsg + '</div>';
        $("#decMsgArea","#applyDesignDialog").stop().html(vMsg).slideDown();
     }
     function clearDecMsg(){
        $("#decMsgArea","#applyDesignDialog").stop().slideUp('fast',function(){ $(this).css('height','auto'); });
     }
     function scrollDesigns(dir){
       var decWidth   = $(".designPreview:first","#selectDesignInner").outerWidth(true),
           outerWidth = $("#selectDesign").width(),
           innerWidth = $("#selectDesignInner").width(),
           innerLeft  = parseInt($("#selectDesignInner").css('left')),
           finalLeft;
       if(dir == 'right'){
          if((innerLeft + decWidth) > 0) decWidth = innerLeft * -1;     
          $("#selectDesignInner").stop().animate({left:"+=" + decWidth},'fast');
          finalLeft = innerLeft + decWidth;
       }else{
          if((innerLeft - decWidth) < -1 * innerWidth) decWidth = innerWidth * -1;
          $("#selectDesignInner").stop().animate({left:"-=" + decWidth},'fast');
          finalLeft = innerLeft - decWidth;
       }
       //Check to show/hide left/right arrows
       if(finalLeft < 0){
         $("#selDesignRight").show();
       }else{
         $("#selDesignRight").hide();
       }
       if(finalLeft >= 0){
         $("#selDesignLeft").show();
       }else if(outerWidth - innerWidth >= finalLeft ){
         $("#selDesignLeft").hide();
       }
     }
     //--- End   Decorator Logic --------

     function changeGridMode(newGridMode,refreshGrid,setDefWhse){
        opts.gridMode = newGridMode;

        $.wam.store('gridMode', newGridMode);

        if(opts.gridMode == 'whse'){
           var warehouseObj = { "singleWarehouse": false
                               ,"whseDesc":""
                               ,"cutOffMsg":""                               
                               ,"warehouseList": whseList
                              };
              if(whseList.length == 1){
                warehouseObj.singleWarehouse = true;
                warehouseObj.whseDesc        = whseList[0].whseDesc;
                warehouseObj.cutOffMsg       = whseList[0].cutoffMsg;
              }else{
                $.each(whseList,function(){
                   if(this.isSelected){
                      warehouseObj.cutOffMsg = this.cutoffMsg;
                     /* our default warehouse may not have items available. set to selected warehouse in list */
                      if( setDefWhse ) selectedWhse = this.whse;
                      return false;
                   }
                });
              }         
           $("#colorSelectOuter").html("");
           $("#whseSelectOuter").html( gridWhseTmpl(warehouseObj) );
        }else{
           whseGridLoaded = true;   
           var colorObj = {'singleColor':true, colorList:[] };
           colorObj.singleColor = (prodObj.color.length == 1);
           if(colorObj.singleColor){
             colorObj.colorCode = prodObj.color[0].colorCode;
             colorObj.colorDesc = prodObj.color[0].description;
             colorObj.colorHex  = prodObj.color[0].hexColor;
           }             
           $.each(prodObj.color,function(idx){
             colorObj.colorList.push({'id':this.colorCode, 'text':this.description, 'hexColor':this.hexColor, 'imageSw':this.imageSw});
             //check and set selected - 
             //colorObj.colorList[colorList.length].selected = true;
           });
           $("#whseSelectOuter").html("");
           $("#colorSelectOuter").html( gridColorTmpl(colorObj) );
           //Now create select2 dropdown
           var select2Color = function(data){                  
                  if (!data.id) { return data.text; }
                  var optHTML = "";
                  if(typeof data.imageSw != 'undefined' && data.imageSw != ""){
                    optHTML = "<img class='s2Swatch' src='" + data.imageSw + "'>";
                  }else{
                    optHTML = "<div class='s2Swatch' style='background-color: #" + data.hexColor + "'></div>";
                  }
                  optHTML+=data.text
                  return optHTML;
           };

           if(!colorObj.singleColor){
              $("#colorSelect").select2({
                data: colorObj.colorList,
                width:'100%',
                theme: "bootstrap",
                escapeMarkup: function(markup) {
                  return markup;
                },
                templateResult: select2Color,
                templateSelection: select2Color
              });
           }
        }
        if( refreshGrid ){
         
           if(typeof selectedWhse != "undefined" && selectedWhse != "" && selectedWhse != null){
              $("#whseSelect").val(selectedWhse);   
              $("#whseSelect").trigger("change");  
           }
        
        /*** v ROY010003 v ****/
           renderGrid();
         
         // set the running total of order qty for this row, send in the current row
         
         if (opts.gridMode == 'whse')
          setOrderQtyTotal($(".qoGridColor").find(".product-description")); 
         else
          setOrderQtyTotal($(".qoGridWhse").find(".product-description")); 
        /*** ^ ROY010003 ^ ***/
        }
     }
     
    /***** v ROY010003 v *****/
     // takes in a JS date and reformats it
     function formatDate(dateObj)
     {
      if (typeof dateObj == "string")
           
       var d = new Date(dateObj + "T00:00");
      else
       var d = dateObj;
      
      try 
      {
       var year  = d.getFullYear(),
           month = d.getMonth(),
           day   = d.getDate();
      } catch(e) {};
      
      if (typeof month == "undefined" || typeof day == "undefined" || typeof year == "undefined")
       return "";
      else
       return (month + 1) + "/" + day + "/" + year;
     }

     function viewOnOrder(itemObj)
     {
      // itemObj is an element with class .product-elem which is the container for all the item info
      var rowObj    = itemObj.closest(".product-item");
      var headerObj = rowObj.find(".product-head");
      var detailObj = rowObj.find(".product-description");
      var linksObj  = detailObj.find(".product-links");
      var infoObj   = linksObj.find(".onOrderInfo");

      // if the user "closed" the alert, then recreate it
      if (infoObj.length == 0)
      {
       linksObj.prepend('<div class="onOrderInfo alert alert-info fade in"><a href="#" class="close" data-dismiss="alert">&times;</a></div>');
       infoObj = linksObj.find(".onOrderInfo");
      }
       
      // get the incoming dates from the header obj
      var onOrderDates = [];

      onOrderDates[0] = "Size:";
      
      headerObj.find(".currentlyAvailable").each(function()
      {
       onOrderDates.push($(this).html());
      });
      
      headerObj.find(".comingSoon").each(function()
      {
       onOrderDates.push($(this).html());
      });
      
      // get the incoming qtys from the passed in item obj
      var onOrderQtys = [];
      
      onOrderQtys[0] = itemObj.find(".product-size").html();
       
      $(".product-count",itemObj).each(function()
      {
       onOrderQtys.push($(this).html()); 
      });
      
      $(".onOrderQty",itemObj).each(function()
      {
       onOrderQtys.push($(this).html()); 
      });
      
      // delete any on order info already displaying
      infoObj.find(".info").remove();
      

      // display the merged incomging dates + qtys
      for (var i=0; i<onOrderDates.length; i++)
      {
       infoObj.append('<div class="info"><div class="date">' + $.trim(onOrderDates[i]) + '</div><span class="qty">' + $.trim(onOrderQtys[i]) + '</span></div>');
      }
                                 
     } //viewOnOrder()
      
     function comingToggle(toggleObj)
     {
      var showClass = "fa-angle-up";
      var hideClass = "fa-angle-down";
      var toggleIcon = toggleObj.find("i");
      
      // hidden?
      var hidden = toggleIcon.hasClass(hideClass);
      
      if (hidden)
      {
       toggleIcon.removeClass(hideClass);
       toggleIcon.addClass(showClass);
       
       // show the on order dates
       toggleObj.parent().find(".comingSoon").show();
       
       //show the on order qtys
       toggleObj.closest(".product-item").find(".onOrderQty").show();
      }
      else 
      {
       toggleIcon.removeClass(showClass);
       toggleIcon.addClass(hideClass);
       
       // hide the on order dates
       toggleObj.parent().find(".comingSoon").hide();
       
       //hide the on order qtys
       toggleObj.closest(".product-item").find(".onOrderQty").hide();

      }
     }
    /***** ^ ROY010003 ^ *****/
    
    //-------------------------
    //-------------------------
     /*****vvv CIT010000 vvv*****/
     function setMultiHexGrid(){
      var myColorValList;  
      var myTextColorList; 
      var myColorStop;
      var h;
      var ht;

      if(!$(".qoHeaderRow").length){
          $(".qoDesc").each(function(){
              if ($(this).data("hexcolor").indexOf(",") != -1) {
                  myColorValList  = $(this).data("hexcolor").split(",");
                  myTextColorList = $(this).data("texthex").split(",");
                  myColorStop = 100 / myColorValList.length;

                  for (var i = 0; i < myColorValList.length; i++) {
                      myTextColorList[i] = (myTextColorList[i] == "Light" ? "FFFFFF" : "000000");
                      
                      if (i == 0) {
                          h  = "linear-gradient(90deg, #" + myColorValList[0]  + " " + myColorStop.toString() + "%"; 
                          ht = "linear-gradient(90deg, #" + myTextColorList[0] + " " + (myColorStop).toString() + "%"; 
                      }
                      else{
                          h  += ", #" + myColorValList[i] + " " + (i * myColorStop).toString() + "%";
                          ht += ", #" + myTextColorList[i] + " " + (i * myColorStop).toString() + "%";
 
                          if (i < myColorValList.length - 1) {
                              h  += ", #" + myColorValList[i] + " " + ((i+1) * myColorStop).toString() + "%";
                              ht += ", #" + myTextColorList[i] + " " + ((i+1) * myColorStop).toString() + "%";
                          }
                      }
                  }
                  h  += ")";
                  ht += ")";
                  $(this).css("background",h);
                  $(".qoDescText",this).css({"background": ht,"-webkit-background-clip":"text","-webkit-text-fill-color": "transparent"});
                  $(".eachSaleLabel, .eachLabel, .expStockLabel, .stockLabel",this).css({"background": ht,"-webkit-background-clip": "text","-webkit-text-fill-color": "transparent"});
              }
          })
      }
  }
  /*****^^^ CIT010000 ^^^*****/
   }; //End quickorder

   //Extend $.wam.product with quickorder
   $.extend(true,$.wam.product,{
     'quickorder': quickorder
   });   

})( jQuery, window, document );

//Forward function outside of closure for use with liveArt
var applySavedDesign = function(data,vGroupName){
  return $.wam.product.quickorder.applySavedDesign(data,vGroupName); 
};
if(typeof define != "undefined"){
  var __origDefine = define; // RequireJS messes this up ... 
  define = null;
}
/*! Select2 4.0.6-rc.1 | https://github.com/select2/select2/blob/master/LICENSE.md */!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):"object"==typeof module&&module.exports?module.exports=function(b,c){return void 0===c&&(c="undefined"!=typeof window?require("jquery"):require("jquery")(b)),a(c),c}:a(jQuery)}(function(a){var b=function(){if(a&&a.fn&&a.fn.select2&&a.fn.select2.amd)var b=a.fn.select2.amd;var b;return function(){if(!b||!b.requirejs){b?c=b:b={};var a,c,d;!function(b){function e(a,b){return v.call(a,b)}function f(a,b){var c,d,e,f,g,h,i,j,k,l,m,n,o=b&&b.split("/"),p=t.map,q=p&&p["*"]||{};if(a){for(a=a.split("/"),g=a.length-1,t.nodeIdCompat&&x.test(a[g])&&(a[g]=a[g].replace(x,"")),"."===a[0].charAt(0)&&o&&(n=o.slice(0,o.length-1),a=n.concat(a)),k=0;k<a.length;k++)if("."===(m=a[k]))a.splice(k,1),k-=1;else if(".."===m){if(0===k||1===k&&".."===a[2]||".."===a[k-1])continue;k>0&&(a.splice(k-1,2),k-=2)}a=a.join("/")}if((o||q)&&p){for(c=a.split("/"),k=c.length;k>0;k-=1){if(d=c.slice(0,k).join("/"),o)for(l=o.length;l>0;l-=1)if((e=p[o.slice(0,l).join("/")])&&(e=e[d])){f=e,h=k;break}if(f)break;!i&&q&&q[d]&&(i=q[d],j=k)}!f&&i&&(f=i,h=j),f&&(c.splice(0,h,f),a=c.join("/"))}return a}function g(a,c){return function(){var d=w.call(arguments,0);return"string"!=typeof d[0]&&1===d.length&&d.push(null),o.apply(b,d.concat([a,c]))}}function h(a){return function(b){return f(b,a)}}function i(a){return function(b){r[a]=b}}function j(a){if(e(s,a)){var c=s[a];delete s[a],u[a]=!0,n.apply(b,c)}if(!e(r,a)&&!e(u,a))throw new Error("No "+a);return r[a]}function k(a){var b,c=a?a.indexOf("!"):-1;return c>-1&&(b=a.substring(0,c),a=a.substring(c+1,a.length)),[b,a]}function l(a){return a?k(a):[]}function m(a){return function(){return t&&t.config&&t.config[a]||{}}}var n,o,p,q,r={},s={},t={},u={},v=Object.prototype.hasOwnProperty,w=[].slice,x=/\.js$/;p=function(a,b){var c,d=k(a),e=d[0],g=b[1];return a=d[1],e&&(e=f(e,g),c=j(e)),e?a=c&&c.normalize?c.normalize(a,h(g)):f(a,g):(a=f(a,g),d=k(a),e=d[0],a=d[1],e&&(c=j(e))),{f:e?e+"!"+a:a,n:a,pr:e,p:c}},q={require:function(a){return g(a)},exports:function(a){var b=r[a];return void 0!==b?b:r[a]={}},module:function(a){return{id:a,uri:"",exports:r[a],config:m(a)}}},n=function(a,c,d,f){var h,k,m,n,o,t,v,w=[],x=typeof d;if(f=f||a,t=l(f),"undefined"===x||"function"===x){for(c=!c.length&&d.length?["require","exports","module"]:c,o=0;o<c.length;o+=1)if(n=p(c[o],t),"require"===(k=n.f))w[o]=q.require(a);else if("exports"===k)w[o]=q.exports(a),v=!0;else if("module"===k)h=w[o]=q.module(a);else if(e(r,k)||e(s,k)||e(u,k))w[o]=j(k);else{if(!n.p)throw new Error(a+" missing "+k);n.p.load(n.n,g(f,!0),i(k),{}),w[o]=r[k]}m=d?d.apply(r[a],w):void 0,a&&(h&&h.exports!==b&&h.exports!==r[a]?r[a]=h.exports:m===b&&v||(r[a]=m))}else a&&(r[a]=d)},a=c=o=function(a,c,d,e,f){if("string"==typeof a)return q[a]?q[a](c):j(p(a,l(c)).f);if(!a.splice){if(t=a,t.deps&&o(t.deps,t.callback),!c)return;c.splice?(a=c,c=d,d=null):a=b}return c=c||function(){},"function"==typeof d&&(d=e,e=f),e?n(b,a,c,d):setTimeout(function(){n(b,a,c,d)},4),o},o.config=function(a){return o(a)},a._defined=r,d=function(a,b,c){if("string"!=typeof a)throw new Error("See almond README: incorrect module build, no module name");b.splice||(c=b,b=[]),e(r,a)||e(s,a)||(s[a]=[a,b,c])},d.amd={jQuery:!0}}(),b.requirejs=a,b.require=c,b.define=d}}(),b.define("almond",function(){}),b.define("jquery",[],function(){var b=a||$;return null==b&&console&&console.error&&console.error("Select2: An instance of jQuery or a jQuery-compatible library was not found. Make sure that you are including jQuery before Select2 on your web page."),b}),b.define("select2/utils",["jquery"],function(a){function b(a){var b=a.prototype,c=[];for(var d in b){"function"==typeof b[d]&&("constructor"!==d&&c.push(d))}return c}var c={};c.Extend=function(a,b){function c(){this.constructor=a}var d={}.hasOwnProperty;for(var e in b)d.call(b,e)&&(a[e]=b[e]);return c.prototype=b.prototype,a.prototype=new c,a.__super__=b.prototype,a},c.Decorate=function(a,c){function d(){var b=Array.prototype.unshift,d=c.prototype.constructor.length,e=a.prototype.constructor;d>0&&(b.call(arguments,a.prototype.constructor),e=c.prototype.constructor),e.apply(this,arguments)}function e(){this.constructor=d}var f=b(c),g=b(a);c.displayName=a.displayName,d.prototype=new e;for(var h=0;h<g.length;h++){var i=g[h];d.prototype[i]=a.prototype[i]}for(var j=(function(a){var b=function(){};a in d.prototype&&(b=d.prototype[a]);var e=c.prototype[a];return function(){return Array.prototype.unshift.call(arguments,b),e.apply(this,arguments)}}),k=0;k<f.length;k++){var l=f[k];d.prototype[l]=j(l)}return d};var d=function(){this.listeners={}};d.prototype.on=function(a,b){this.listeners=this.listeners||{},a in this.listeners?this.listeners[a].push(b):this.listeners[a]=[b]},d.prototype.trigger=function(a){var b=Array.prototype.slice,c=b.call(arguments,1);this.listeners=this.listeners||{},null==c&&(c=[]),0===c.length&&c.push({}),c[0]._type=a,a in this.listeners&&this.invoke(this.listeners[a],b.call(arguments,1)),"*"in this.listeners&&this.invoke(this.listeners["*"],arguments)},d.prototype.invoke=function(a,b){for(var c=0,d=a.length;c<d;c++)a[c].apply(this,b)},c.Observable=d,c.generateChars=function(a){for(var b="",c=0;c<a;c++){b+=Math.floor(36*Math.random()).toString(36)}return b},c.bind=function(a,b){return function(){a.apply(b,arguments)}},c._convertData=function(a){for(var b in a){var c=b.split("-"),d=a;if(1!==c.length){for(var e=0;e<c.length;e++){var f=c[e];f=f.substring(0,1).toLowerCase()+f.substring(1),f in d||(d[f]={}),e==c.length-1&&(d[f]=a[b]),d=d[f]}delete a[b]}}return a},c.hasScroll=function(b,c){var d=a(c),e=c.style.overflowX,f=c.style.overflowY;return(e!==f||"hidden"!==f&&"visible"!==f)&&("scroll"===e||"scroll"===f||(d.innerHeight()<c.scrollHeight||d.innerWidth()<c.scrollWidth))},c.escapeMarkup=function(a){var b={"\\":"&#92;","&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","/":"&#47;"};return"string"!=typeof a?a:String(a).replace(/[&<>"'\/\\]/g,function(a){return b[a]})},c.appendMany=function(b,c){if("1.7"===a.fn.jquery.substr(0,3)){var d=a();a.map(c,function(a){d=d.add(a)}),c=d}b.append(c)},c.__cache={};var e=0;return c.GetUniqueElementId=function(a){var b=a.getAttribute("data-select2-id");return null==b&&(a.id?(b=a.id,a.setAttribute("data-select2-id",b)):(a.setAttribute("data-select2-id",++e),b=e.toString())),b},c.StoreData=function(a,b,d){var e=c.GetUniqueElementId(a);c.__cache[e]||(c.__cache[e]={}),c.__cache[e][b]=d},c.GetData=function(b,d){var e=c.GetUniqueElementId(b);return d?c.__cache[e]&&null!=c.__cache[e][d]?c.__cache[e][d]:a(b).data(d):c.__cache[e]},c.RemoveData=function(a){var b=c.GetUniqueElementId(a);null!=c.__cache[b]&&delete c.__cache[b]},c}),b.define("select2/results",["jquery","./utils"],function(a,b){function c(a,b,d){this.$element=a,this.data=d,this.options=b,c.__super__.constructor.call(this)}return b.Extend(c,b.Observable),c.prototype.render=function(){var b=a('<ul class="select2-results__options" role="tree"></ul>');return this.options.get("multiple")&&b.attr("aria-multiselectable","true"),this.$results=b,b},c.prototype.clear=function(){this.$results.empty()},c.prototype.displayMessage=function(b){var c=this.options.get("escapeMarkup");this.clear(),this.hideLoading();var d=a('<li role="treeitem" aria-live="assertive" class="select2-results__option"></li>'),e=this.options.get("translations").get(b.message);d.append(c(e(b.args))),d[0].className+=" select2-results__message",this.$results.append(d)},c.prototype.hideMessages=function(){this.$results.find(".select2-results__message").remove()},c.prototype.append=function(a){this.hideLoading();var b=[];if(null==a.results||0===a.results.length)return void(0===this.$results.children().length&&this.trigger("results:message",{message:"noResults"}));a.results=this.sort(a.results);for(var c=0;c<a.results.length;c++){var d=a.results[c],e=this.option(d);b.push(e)}this.$results.append(b)},c.prototype.position=function(a,b){b.find(".select2-results").append(a)},c.prototype.sort=function(a){return this.options.get("sorter")(a)},c.prototype.highlightFirstItem=function(){var a=this.$results.find(".select2-results__option[aria-selected]"),b=a.filter("[aria-selected=true]");b.length>0?b.first().trigger("mouseenter"):a.first().trigger("mouseenter"),this.ensureHighlightVisible()},c.prototype.setClasses=function(){var c=this;this.data.current(function(d){var e=a.map(d,function(a){return a.id.toString()});c.$results.find(".select2-results__option[aria-selected]").each(function(){var c=a(this),d=b.GetData(this,"data"),f=""+d.id;null!=d.element&&d.element.selected||null==d.element&&a.inArray(f,e)>-1?c.attr("aria-selected","true"):c.attr("aria-selected","false")})})},c.prototype.showLoading=function(a){this.hideLoading();var b=this.options.get("translations").get("searching"),c={disabled:!0,loading:!0,text:b(a)},d=this.option(c);d.className+=" loading-results",this.$results.prepend(d)},c.prototype.hideLoading=function(){this.$results.find(".loading-results").remove()},c.prototype.option=function(c){var d=document.createElement("li");d.className="select2-results__option";var e={role:"treeitem","aria-selected":"false"};c.disabled&&(delete e["aria-selected"],e["aria-disabled"]="true"),null==c.id&&delete e["aria-selected"],null!=c._resultId&&(d.id=c._resultId),c.title&&(d.title=c.title),c.children&&(e.role="group",e["aria-label"]=c.text,delete e["aria-selected"]);for(var f in e){var g=e[f];d.setAttribute(f,g)}if(c.children){var h=a(d),i=document.createElement("strong");i.className="select2-results__group";a(i);this.template(c,i);for(var j=[],k=0;k<c.children.length;k++){var l=c.children[k],m=this.option(l);j.push(m)}var n=a("<ul></ul>",{class:"select2-results__options select2-results__options--nested"});n.append(j),h.append(i),h.append(n)}else this.template(c,d);return b.StoreData(d,"data",c),d},c.prototype.bind=function(c,d){var e=this,f=c.id+"-results";this.$results.attr("id",f),c.on("results:all",function(a){e.clear(),e.append(a.data),c.isOpen()&&(e.setClasses(),e.highlightFirstItem())}),c.on("results:append",function(a){e.append(a.data),c.isOpen()&&e.setClasses()}),c.on("query",function(a){e.hideMessages(),e.showLoading(a)}),c.on("select",function(){c.isOpen()&&(e.setClasses(),e.highlightFirstItem())}),c.on("unselect",function(){c.isOpen()&&(e.setClasses(),e.highlightFirstItem())}),c.on("open",function(){e.$results.attr("aria-expanded","true"),e.$results.attr("aria-hidden","false"),e.setClasses(),e.ensureHighlightVisible()}),c.on("close",function(){e.$results.attr("aria-expanded","false"),e.$results.attr("aria-hidden","true"),e.$results.removeAttr("aria-activedescendant")}),c.on("results:toggle",function(){var a=e.getHighlightedResults();0!==a.length&&a.trigger("mouseup")}),c.on("results:select",function(){var a=e.getHighlightedResults();if(0!==a.length){var c=b.GetData(a[0],"data");"true"==a.attr("aria-selected")?e.trigger("close",{}):e.trigger("select",{data:c})}}),c.on("results:previous",function(){var a=e.getHighlightedResults(),b=e.$results.find("[aria-selected]"),c=b.index(a);if(!(c<=0)){var d=c-1;0===a.length&&(d=0);var f=b.eq(d);f.trigger("mouseenter");var g=e.$results.offset().top,h=f.offset().top,i=e.$results.scrollTop()+(h-g);0===d?e.$results.scrollTop(0):h-g<0&&e.$results.scrollTop(i)}}),c.on("results:next",function(){var a=e.getHighlightedResults(),b=e.$results.find("[aria-selected]"),c=b.index(a),d=c+1;if(!(d>=b.length)){var f=b.eq(d);f.trigger("mouseenter");var g=e.$results.offset().top+e.$results.outerHeight(!1),h=f.offset().top+f.outerHeight(!1),i=e.$results.scrollTop()+h-g;0===d?e.$results.scrollTop(0):h>g&&e.$results.scrollTop(i)}}),c.on("results:focus",function(a){a.element.addClass("select2-results__option--highlighted")}),c.on("results:message",function(a){e.displayMessage(a)}),a.fn.mousewheel&&this.$results.on("mousewheel",function(a){var b=e.$results.scrollTop(),c=e.$results.get(0).scrollHeight-b+a.deltaY,d=a.deltaY>0&&b-a.deltaY<=0,f=a.deltaY<0&&c<=e.$results.height();d?(e.$results.scrollTop(0),a.preventDefault(),a.stopPropagation()):f&&(e.$results.scrollTop(e.$results.get(0).scrollHeight-e.$results.height()),a.preventDefault(),a.stopPropagation())}),this.$results.on("mouseup",".select2-results__option[aria-selected]",function(c){var d=a(this),f=b.GetData(this,"data");if("true"===d.attr("aria-selected"))return void(e.options.get("multiple")?e.trigger("unselect",{originalEvent:c,data:f}):e.trigger("close",{}));e.trigger("select",{originalEvent:c,data:f})}),this.$results.on("mouseenter",".select2-results__option[aria-selected]",function(c){var d=b.GetData(this,"data");e.getHighlightedResults().removeClass("select2-results__option--highlighted"),e.trigger("results:focus",{data:d,element:a(this)})})},c.prototype.getHighlightedResults=function(){return this.$results.find(".select2-results__option--highlighted")},c.prototype.destroy=function(){this.$results.remove()},c.prototype.ensureHighlightVisible=function(){var a=this.getHighlightedResults();if(0!==a.length){var b=this.$results.find("[aria-selected]"),c=b.index(a),d=this.$results.offset().top,e=a.offset().top,f=this.$results.scrollTop()+(e-d),g=e-d;f-=2*a.outerHeight(!1),c<=2?this.$results.scrollTop(0):(g>this.$results.outerHeight()||g<0)&&this.$results.scrollTop(f)}},c.prototype.template=function(b,c){var d=this.options.get("templateResult"),e=this.options.get("escapeMarkup"),f=d(b,c);null==f?c.style.display="none":"string"==typeof f?c.innerHTML=e(f):a(c).append(f)},c}),b.define("select2/keys",[],function(){return{BACKSPACE:8,TAB:9,ENTER:13,SHIFT:16,CTRL:17,ALT:18,ESC:27,SPACE:32,PAGE_UP:33,PAGE_DOWN:34,END:35,HOME:36,LEFT:37,UP:38,RIGHT:39,DOWN:40,DELETE:46}}),b.define("select2/selection/base",["jquery","../utils","../keys"],function(a,b,c){function d(a,b){this.$element=a,this.options=b,d.__super__.constructor.call(this)}return b.Extend(d,b.Observable),d.prototype.render=function(){var c=a('<span class="select2-selection" role="combobox"  aria-haspopup="true" aria-expanded="false"></span>');return this._tabindex=0,null!=b.GetData(this.$element[0],"old-tabindex")?this._tabindex=b.GetData(this.$element[0],"old-tabindex"):null!=this.$element.attr("tabindex")&&(this._tabindex=this.$element.attr("tabindex")),c.attr("title",this.$element.attr("title")),c.attr("tabindex",this._tabindex),this.$selection=c,c},d.prototype.bind=function(a,b){var d=this,e=(a.id,a.id+"-results");this.container=a,this.$selection.on("focus",function(a){d.trigger("focus",a)}),this.$selection.on("blur",function(a){d._handleBlur(a)}),this.$selection.on("keydown",function(a){d.trigger("keypress",a),a.which===c.SPACE&&a.preventDefault()}),a.on("results:focus",function(a){d.$selection.attr("aria-activedescendant",a.data._resultId)}),a.on("selection:update",function(a){d.update(a.data)}),a.on("open",function(){d.$selection.attr("aria-expanded","true"),d.$selection.attr("aria-owns",e),d._attachCloseHandler(a)}),a.on("close",function(){d.$selection.attr("aria-expanded","false"),d.$selection.removeAttr("aria-activedescendant"),d.$selection.removeAttr("aria-owns"),d.$selection.focus(),window.setTimeout(function(){d.$selection.focus()},0),d._detachCloseHandler(a)}),a.on("enable",function(){d.$selection.attr("tabindex",d._tabindex)}),a.on("disable",function(){d.$selection.attr("tabindex","-1")})},d.prototype._handleBlur=function(b){var c=this;window.setTimeout(function(){document.activeElement==c.$selection[0]||a.contains(c.$selection[0],document.activeElement)||c.trigger("blur",b)},1)},d.prototype._attachCloseHandler=function(c){a(document.body).on("mousedown.select2."+c.id,function(c){var d=a(c.target),e=d.closest(".select2");a(".select2.select2-container--open").each(function(){a(this),this!=e[0]&&b.GetData(this,"element").select2("close")})})},d.prototype._detachCloseHandler=function(b){a(document.body).off("mousedown.select2."+b.id)},d.prototype.position=function(a,b){b.find(".selection").append(a)},d.prototype.destroy=function(){this._detachCloseHandler(this.container)},d.prototype.update=function(a){throw new Error("The `update` method must be defined in child classes.")},d}),b.define("select2/selection/single",["jquery","./base","../utils","../keys"],function(a,b,c,d){function e(){e.__super__.constructor.apply(this,arguments)}return c.Extend(e,b),e.prototype.render=function(){var a=e.__super__.render.call(this);return a.addClass("select2-selection--single"),a.html('<span class="select2-selection__rendered"></span><span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span>'),a},e.prototype.bind=function(a,b){var c=this;e.__super__.bind.apply(this,arguments);var d=a.id+"-container";this.$selection.find(".select2-selection__rendered").attr("id",d).attr("role","textbox").attr("aria-readonly","true"),this.$selection.attr("aria-labelledby",d),this.$selection.on("mousedown",function(a){1===a.which&&c.trigger("toggle",{originalEvent:a})}),this.$selection.on("focus",function(a){}),this.$selection.on("blur",function(a){}),a.on("focus",function(b){a.isOpen()||c.$selection.focus()})},e.prototype.clear=function(){var a=this.$selection.find(".select2-selection__rendered");a.empty(),a.removeAttr("title")},e.prototype.display=function(a,b){var c=this.options.get("templateSelection");return this.options.get("escapeMarkup")(c(a,b))},e.prototype.selectionContainer=function(){return a("<span></span>")},e.prototype.update=function(a){if(0===a.length)return void this.clear();var b=a[0],c=this.$selection.find(".select2-selection__rendered"),d=this.display(b,c);c.empty().append(d),c.attr("title",b.title||b.text)},e}),b.define("select2/selection/multiple",["jquery","./base","../utils"],function(a,b,c){function d(a,b){d.__super__.constructor.apply(this,arguments)}return c.Extend(d,b),d.prototype.render=function(){var a=d.__super__.render.call(this);return a.addClass("select2-selection--multiple"),a.html('<ul class="select2-selection__rendered"></ul>'),a},d.prototype.bind=function(b,e){var f=this;d.__super__.bind.apply(this,arguments),this.$selection.on("click",function(a){f.trigger("toggle",{originalEvent:a})}),this.$selection.on("click",".select2-selection__choice__remove",function(b){if(!f.options.get("disabled")){var d=a(this),e=d.parent(),g=c.GetData(e[0],"data");f.trigger("unselect",{originalEvent:b,data:g})}})},d.prototype.clear=function(){var a=this.$selection.find(".select2-selection__rendered");a.empty(),a.removeAttr("title")},d.prototype.display=function(a,b){var c=this.options.get("templateSelection");return this.options.get("escapeMarkup")(c(a,b))},d.prototype.selectionContainer=function(){return a('<li class="select2-selection__choice"><span class="select2-selection__choice__remove" role="presentation">&times;</span></li>')},d.prototype.update=function(a){if(this.clear(),0!==a.length){for(var b=[],d=0;d<a.length;d++){var e=a[d],f=this.selectionContainer(),g=this.display(e,f);f.append(g),f.attr("title",e.title||e.text),c.StoreData(f[0],"data",e),b.push(f)}var h=this.$selection.find(".select2-selection__rendered");c.appendMany(h,b)}},d}),b.define("select2/selection/placeholder",["../utils"],function(a){function b(a,b,c){this.placeholder=this.normalizePlaceholder(c.get("placeholder")),a.call(this,b,c)}return b.prototype.normalizePlaceholder=function(a,b){return"string"==typeof b&&(b={id:"",text:b}),b},b.prototype.createPlaceholder=function(a,b){var c=this.selectionContainer();return c.html(this.display(b)),c.addClass("select2-selection__placeholder").removeClass("select2-selection__choice"),c},b.prototype.update=function(a,b){var c=1==b.length&&b[0].id!=this.placeholder.id;if(b.length>1||c)return a.call(this,b);this.clear();var d=this.createPlaceholder(this.placeholder);this.$selection.find(".select2-selection__rendered").append(d)},b}),b.define("select2/selection/allowClear",["jquery","../keys","../utils"],function(a,b,c){function d(){}return d.prototype.bind=function(a,b,c){var d=this;a.call(this,b,c),null==this.placeholder&&this.options.get("debug")&&window.console&&console.error&&console.error("Select2: The `allowClear` option should be used in combination with the `placeholder` option."),this.$selection.on("mousedown",".select2-selection__clear",function(a){d._handleClear(a)}),b.on("keypress",function(a){d._handleKeyboardClear(a,b)})},d.prototype._handleClear=function(a,b){if(!this.options.get("disabled")){var d=this.$selection.find(".select2-selection__clear");if(0!==d.length){b.stopPropagation();var e=c.GetData(d[0],"data"),f=this.$element.val();this.$element.val(this.placeholder.id);var g={data:e};if(this.trigger("clear",g),g.prevented)return void this.$element.val(f);for(var h=0;h<e.length;h++)if(g={data:e[h]},this.trigger("unselect",g),g.prevented)return void this.$element.val(f);this.$element.trigger("change"),this.trigger("toggle",{})}}},d.prototype._handleKeyboardClear=function(a,c,d){d.isOpen()||c.which!=b.DELETE&&c.which!=b.BACKSPACE||this._handleClear(c)},d.prototype.update=function(b,d){if(b.call(this,d),!(this.$selection.find(".select2-selection__placeholder").length>0||0===d.length)){var e=a('<span class="select2-selection__clear">&times;</span>');c.StoreData(e[0],"data",d),this.$selection.find(".select2-selection__rendered").prepend(e)}},d}),b.define("select2/selection/search",["jquery","../utils","../keys"],function(a,b,c){function d(a,b,c){a.call(this,b,c)}return d.prototype.render=function(b){var c=a('<li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="-1" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" role="textbox" aria-autocomplete="list" /></li>');this.$searchContainer=c,this.$search=c.find("input");var d=b.call(this);return this._transferTabIndex(),d},d.prototype.bind=function(a,d,e){var f=this;a.call(this,d,e),d.on("open",function(){f.$search.trigger("focus")}),d.on("close",function(){f.$search.val(""),f.$search.removeAttr("aria-activedescendant"),f.$search.trigger("focus")}),d.on("enable",function(){f.$search.prop("disabled",!1),f._transferTabIndex()}),d.on("disable",function(){f.$search.prop("disabled",!0)}),d.on("focus",function(a){f.$search.trigger("focus")}),d.on("results:focus",function(a){f.$search.attr("aria-activedescendant",a.id)}),this.$selection.on("focusin",".select2-search--inline",function(a){f.trigger("focus",a)}),this.$selection.on("focusout",".select2-search--inline",function(a){f._handleBlur(a)}),this.$selection.on("keydown",".select2-search--inline",function(a){if(a.stopPropagation(),f.trigger("keypress",a),f._keyUpPrevented=a.isDefaultPrevented(),a.which===c.BACKSPACE&&""===f.$search.val()){var d=f.$searchContainer.prev(".select2-selection__choice");if(d.length>0){var e=b.GetData(d[0],"data");f.searchRemoveChoice(e),a.preventDefault()}}});var g=document.documentMode,h=g&&g<=11;this.$selection.on("input.searchcheck",".select2-search--inline",function(a){if(h)return void f.$selection.off("input.search input.searchcheck");f.$selection.off("keyup.search")}),this.$selection.on("keyup.search input.search",".select2-search--inline",function(a){if(h&&"input"===a.type)return void f.$selection.off("input.search input.searchcheck");var b=a.which;b!=c.SHIFT&&b!=c.CTRL&&b!=c.ALT&&b!=c.TAB&&f.handleSearch(a)})},d.prototype._transferTabIndex=function(a){this.$search.attr("tabindex",this.$selection.attr("tabindex")),this.$selection.attr("tabindex","-1")},d.prototype.createPlaceholder=function(a,b){this.$search.attr("placeholder",b.text)},d.prototype.update=function(a,b){var c=this.$search[0]==document.activeElement;if(this.$search.attr("placeholder",""),a.call(this,b),this.$selection.find(".select2-selection__rendered").append(this.$searchContainer),this.resizeSearch(),c){this.$element.find("[data-select2-tag]").length?this.$element.focus():this.$search.focus()}},d.prototype.handleSearch=function(){if(this.resizeSearch(),!this._keyUpPrevented){var a=this.$search.val();this.trigger("query",{term:a})}this._keyUpPrevented=!1},d.prototype.searchRemoveChoice=function(a,b){this.trigger("unselect",{data:b}),this.$search.val(b.text),this.handleSearch()},d.prototype.resizeSearch=function(){this.$search.css("width","25px");var a="";if(""!==this.$search.attr("placeholder"))a=this.$selection.find(".select2-selection__rendered").innerWidth();else{a=.75*(this.$search.val().length+1)+"em"}this.$search.css("width",a)},d}),b.define("select2/selection/eventRelay",["jquery"],function(a){function b(){}return b.prototype.bind=function(b,c,d){var e=this,f=["open","opening","close","closing","select","selecting","unselect","unselecting","clear","clearing"],g=["opening","closing","selecting","unselecting","clearing"];b.call(this,c,d),c.on("*",function(b,c){if(-1!==a.inArray(b,f)){c=c||{};var d=a.Event("select2:"+b,{params:c});e.$element.trigger(d),-1!==a.inArray(b,g)&&(c.prevented=d.isDefaultPrevented())}})},b}),b.define("select2/translation",["jquery","require"],function(a,b){function c(a){this.dict=a||{}}return c.prototype.all=function(){return this.dict},c.prototype.get=function(a){return this.dict[a]},c.prototype.extend=function(b){this.dict=a.extend({},b.all(),this.dict)},c._cache={},c.loadPath=function(a){if(!(a in c._cache)){var d=b(a);c._cache[a]=d}return new c(c._cache[a])},c}),b.define("select2/diacritics",[],function(){return{"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"A","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"AA","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"AE","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"AE","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"AE","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"AO","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"AU","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"AV","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"AV","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"AY","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"B","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"B","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"B","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"B","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"B","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"B","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"B","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"B","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"C","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"D","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"DZ","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"DZ","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"Dz","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"Dz","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"E","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"F","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"F","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"F","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"F","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"F","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"G","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"H","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"I","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"J","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"J","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"J","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"J","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"K","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"L","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"LJ","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"Lj","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"M","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"M","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"M","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"M","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"M","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"M","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"M","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"N","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"NJ","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"Nj","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"O","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"OI","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"OO","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"OU","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"P","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"Q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"Q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"Q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"Q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"Q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"R","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"S","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"T","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"TZ","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"U","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"V","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"V","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"V","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"V","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"V","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"V","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"V","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"VY","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"W","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"X","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"X","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"X","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"X","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"Y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"Z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"a","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"aa","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"ae","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"ae","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"ae","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"ao","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"au","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"av","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"av","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"ay","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"b","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"b","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"b","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"b","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"b","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"b","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"b","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"b","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"c","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"d","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"dz","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"dz","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"e","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"f","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"f","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"f","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"f","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"f","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂµÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"g","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"h","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"hv","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"i","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"j","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"j","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"j","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"j","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"j","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"k","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"l","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"lj","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"m","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"m","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"m","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"m","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"m","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"m","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"m","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âž":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"n","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"nj","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â²":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"o","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"oi","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"ou","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"oo","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂµÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"p","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"q","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â™":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"r","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"s","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŠÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"t","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"tz","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¤":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŠÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"u","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"v","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â“":"v","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"v","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"v","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŠÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"v","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸":"v","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŠÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"v","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"vy","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"w","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â§":"x","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"x","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"x","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"x","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¨":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â³":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â´":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â»ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿":"y","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂœÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âº":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¼":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¾":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âœ":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¡ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂºÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¶":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂˆÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‰ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂªÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â£":"z","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â˜","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‹ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â†":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â”","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âª":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â„ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¸","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â½":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â«":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¥","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â©","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â±","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â­":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âµ","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â®":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â·","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¯":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â ":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â…ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¿","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¹":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂŽÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â°","ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â€ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Âš":"ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚ÂÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â†ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â’"}}),b.define("select2/data/base",["../utils"],function(a){function b(a,c){b.__super__.constructor.call(this)}return a.Extend(b,a.Observable),b.prototype.current=function(a){throw new Error("The `current` method must be defined in child classes.")},b.prototype.query=function(a,b){throw new Error("The `query` method must be defined in child classes.")},b.prototype.bind=function(a,b){},b.prototype.destroy=function(){},b.prototype.generateResultId=function(b,c){var d=b.id+"-result-";return d+=a.generateChars(4),null!=c.id?d+="-"+c.id.toString():d+="-"+a.generateChars(4),d},b}),b.define("select2/data/select",["./base","../utils","jquery"],function(a,b,c){function d(a,b){this.$element=a,this.options=b,d.__super__.constructor.call(this)}return b.Extend(d,a),d.prototype.current=function(a){var b=[],d=this;this.$element.find(":selected").each(function(){var a=c(this),e=d.item(a);b.push(e)}),a(b)},d.prototype.select=function(a){var b=this;if(a.selected=!0,c(a.element).is("option"))return a.element.selected=!0,void this.$element.trigger("change");if(this.$element.prop("multiple"))this.current(function(d){var e=[];a=[a],a.push.apply(a,d);for(var f=0;f<a.length;f++){var g=a[f].id;-1===c.inArray(g,e)&&e.push(g)}b.$element.val(e),b.$element.trigger("change")});else{var d=a.id;this.$element.val(d),this.$element.trigger("change")}},d.prototype.unselect=function(a){var b=this;if(this.$element.prop("multiple")){if(a.selected=!1,c(a.element).is("option"))return a.element.selected=!1,void this.$element.trigger("change");this.current(function(d){for(var e=[],f=0;f<d.length;f++){var g=d[f].id;g!==a.id&&-1===c.inArray(g,e)&&e.push(g)}b.$element.val(e),b.$element.trigger("change")})}},d.prototype.bind=function(a,b){var c=this;this.container=a,a.on("select",function(a){c.select(a.data)}),a.on("unselect",function(a){c.unselect(a.data)})},d.prototype.destroy=function(){this.$element.find("*").each(function(){b.RemoveData(this)})},d.prototype.query=function(a,b){var d=[],e=this;this.$element.children().each(function(){var b=c(this);if(b.is("option")||b.is("optgroup")){var f=e.item(b),g=e.matches(a,f);null!==g&&d.push(g)}}),b({results:d})},d.prototype.addOptions=function(a){b.appendMany(this.$element,a)},d.prototype.option=function(a){var d;a.children?(d=document.createElement("optgroup"),d.label=a.text):(d=document.createElement("option"),void 0!==d.textContent?d.textContent=a.text:d.innerText=a.text),void 0!==a.id&&(d.value=a.id),a.disabled&&(d.disabled=!0),a.selected&&(d.selected=!0),a.title&&(d.title=a.title);var e=c(d),f=this._normalizeItem(a);return f.element=d,b.StoreData(d,"data",f),e},d.prototype.item=function(a){var d={};if(null!=(d=b.GetData(a[0],"data")))return d;if(a.is("option"))d={id:a.val(),text:a.text(),disabled:a.prop("disabled"),selected:a.prop("selected"),title:a.prop("title")};else if(a.is("optgroup")){d={text:a.prop("label"),children:[],title:a.prop("title")};for(var e=a.children("option"),f=[],g=0;g<e.length;g++){var h=c(e[g]),i=this.item(h);f.push(i)}d.children=f}return d=this._normalizeItem(d),d.element=a[0],b.StoreData(a[0],"data",d),d},d.prototype._normalizeItem=function(a){a!==Object(a)&&(a={id:a,text:a}),a=c.extend({},{text:""},a);var b={selected:!1,disabled:!1};return null!=a.id&&(a.id=a.id.toString()),null!=a.text&&(a.text=a.text.toString()),null==a._resultId&&a.id&&null!=this.container&&(a._resultId=this.generateResultId(this.container,a)),c.extend({},b,a)},d.prototype.matches=function(a,b){return this.options.get("matcher")(a,b)},d}),b.define("select2/data/array",["./select","../utils","jquery"],function(a,b,c){function d(a,b){var c=b.get("data")||[];d.__super__.constructor.call(this,a,b),this.addOptions(this.convertToOptions(c))}return b.Extend(d,a),d.prototype.select=function(a){var b=this.$element.find("option").filter(function(b,c){return c.value==a.id.toString()});0===b.length&&(b=this.option(a),this.addOptions(b)),d.__super__.select.call(this,a)},d.prototype.convertToOptions=function(a){function d(a){return function(){return c(this).val()==a.id}}for(var e=this,f=this.$element.find("option"),g=f.map(function(){return e.item(c(this)).id}).get(),h=[],i=0;i<a.length;i++){var j=this._normalizeItem(a[i]);if(c.inArray(j.id,g)>=0){var k=f.filter(d(j)),l=this.item(k),m=c.extend(!0,{},j,l),n=this.option(m);k.replaceWith(n)}else{var o=this.option(j);if(j.children){var p=this.convertToOptions(j.children);b.appendMany(o,p)}h.push(o)}}return h},d}),b.define("select2/data/ajax",["./array","../utils","jquery"],function(a,b,c){function d(a,b){this.ajaxOptions=this._applyDefaults(b.get("ajax")),null!=this.ajaxOptions.processResults&&(this.processResults=this.ajaxOptions.processResults),d.__super__.constructor.call(this,a,b)}return b.Extend(d,a),d.prototype._applyDefaults=function(a){var b={data:function(a){return c.extend({},a,{q:a.term})},transport:function(a,b,d){var e=c.ajax(a);return e.then(b),e.fail(d),e}};return c.extend({},b,a,!0)},d.prototype.processResults=function(a){return a},d.prototype.query=function(a,b){function d(){var d=f.transport(f,function(d){var f=e.processResults(d,a);e.options.get("debug")&&window.console&&console.error&&(f&&f.results&&c.isArray(f.results)||console.error("Select2: The AJAX results did not return an array in the `results` key of the response.")),b(f)},function(){"status"in d&&(0===d.status||"0"===d.status)||e.trigger("results:message",{message:"errorLoading"})});e._request=d}var e=this;null!=this._request&&(c.isFunction(this._request.abort)&&this._request.abort(),this._request=null);var f=c.extend({type:"GET"},this.ajaxOptions);"function"==typeof f.url&&(f.url=f.url.call(this.$element,a)),"function"==typeof f.data&&(f.data=f.data.call(this.$element,a)),this.ajaxOptions.delay&&null!=a.term?(this._queryTimeout&&window.clearTimeout(this._queryTimeout),this._queryTimeout=window.setTimeout(d,this.ajaxOptions.delay)):d()},d}),b.define("select2/data/tags",["jquery"],function(a){function b(b,c,d){var e=d.get("tags"),f=d.get("createTag");void 0!==f&&(this.createTag=f);var g=d.get("insertTag");if(void 0!==g&&(this.insertTag=g),b.call(this,c,d),a.isArray(e))for(var h=0;h<e.length;h++){var i=e[h],j=this._normalizeItem(i),k=this.option(j);this.$element.append(k)}}return b.prototype.query=function(a,b,c){function d(a,f){for(var g=a.results,h=0;h<g.length;h++){var i=g[h],j=null!=i.children&&!d({results:i.children},!0);if((i.text||"").toUpperCase()===(b.term||"").toUpperCase()||j)return!f&&(a.data=g,void c(a))}if(f)return!0;var k=e.createTag(b);if(null!=k){var l=e.option(k);l.attr("data-select2-tag",!0),e.addOptions([l]),e.insertTag(g,k)}a.results=g,c(a)}var e=this;if(this._removeOldTags(),null==b.term||null!=b.page)return void a.call(this,b,c);a.call(this,b,d)},b.prototype.createTag=function(b,c){var d=a.trim(c.term);return""===d?null:{id:d,text:d}},b.prototype.insertTag=function(a,b,c){b.unshift(c)},b.prototype._removeOldTags=function(b){this._lastTag;this.$element.find("option[data-select2-tag]").each(function(){this.selected||a(this).remove()})},b}),b.define("select2/data/tokenizer",["jquery"],function(a){function b(a,b,c){var d=c.get("tokenizer");void 0!==d&&(this.tokenizer=d),a.call(this,b,c)}return b.prototype.bind=function(a,b,c){a.call(this,b,c),this.$search=b.dropdown.$search||b.selection.$search||c.find(".select2-search__field")},b.prototype.query=function(b,c,d){function e(b){var c=g._normalizeItem(b);if(!g.$element.find("option").filter(function(){return a(this).val()===c.id}).length){var d=g.option(c);d.attr("data-select2-tag",!0),g._removeOldTags(),g.addOptions([d])}f(c)}function f(a){g.trigger("select",{data:a})}var g=this;c.term=c.term||"";var h=this.tokenizer(c,this.options,e);h.term!==c.term&&(this.$search.length&&(this.$search.val(h.term),this.$search.focus()),c.term=h.term),b.call(this,c,d)},b.prototype.tokenizer=function(b,c,d,e){for(var f=d.get("tokenSeparators")||[],g=c.term,h=0,i=this.createTag||function(a){return{id:a.term,text:a.term}};h<g.length;){var j=g[h];if(-1!==a.inArray(j,f)){var k=g.substr(0,h),l=a.extend({},c,{term:k}),m=i(l);null!=m?(e(m),g=g.substr(h+1)||"",h=0):h++}else h++}return{term:g}},b}),b.define("select2/data/minimumInputLength",[],function(){function a(a,b,c){this.minimumInputLength=c.get("minimumInputLength"),a.call(this,b,c)}return a.prototype.query=function(a,b,c){if(b.term=b.term||"",b.term.length<this.minimumInputLength)return void this.trigger("results:message",{message:"inputTooShort",args:{minimum:this.minimumInputLength,input:b.term,params:b}});a.call(this,b,c)},a}),b.define("select2/data/maximumInputLength",[],function(){function a(a,b,c){this.maximumInputLength=c.get("maximumInputLength"),a.call(this,b,c)}return a.prototype.query=function(a,b,c){if(b.term=b.term||"",this.maximumInputLength>0&&b.term.length>this.maximumInputLength)return void this.trigger("results:message",{message:"inputTooLong",args:{maximum:this.maximumInputLength,input:b.term,params:b}});a.call(this,b,c)},a}),b.define("select2/data/maximumSelectionLength",[],function(){function a(a,b,c){this.maximumSelectionLength=c.get("maximumSelectionLength"),a.call(this,b,c)}return a.prototype.query=function(a,b,c){var d=this;this.current(function(e){var f=null!=e?e.length:0;if(d.maximumSelectionLength>0&&f>=d.maximumSelectionLength)return void d.trigger("results:message",{message:"maximumSelected",args:{maximum:d.maximumSelectionLength}});a.call(d,b,c)})},a}),b.define("select2/dropdown",["jquery","./utils"],function(a,b){function c(a,b){this.$element=a,this.options=b,c.__super__.constructor.call(this)}return b.Extend(c,b.Observable),c.prototype.render=function(){var b=a('<span class="select2-dropdown"><span class="select2-results"></span></span>');return b.attr("dir",this.options.get("dir")),this.$dropdown=b,b},c.prototype.bind=function(){},c.prototype.position=function(a,b){},c.prototype.destroy=function(){this.$dropdown.remove()},c}),b.define("select2/dropdown/search",["jquery","../utils"],function(a,b){function c(){}return c.prototype.render=function(b){var c=b.call(this),d=a('<span class="select2-search select2-search--dropdown"><input class="select2-search__field" type="search" tabindex="-1" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" role="textbox" /></span>');return this.$searchContainer=d,this.$search=d.find("input"),c.prepend(d),c},c.prototype.bind=function(b,c,d){var e=this;b.call(this,c,d),this.$search.on("keydown",function(a){e.trigger("keypress",a),e._keyUpPrevented=a.isDefaultPrevented()}),this.$search.on("input",function(b){a(this).off("keyup")}),this.$search.on("keyup input",function(a){e.handleSearch(a)}),c.on("open",function(){e.$search.attr("tabindex",0),e.$search.focus(),window.setTimeout(function(){e.$search.focus()},0)}),c.on("close",function(){e.$search.attr("tabindex",-1),e.$search.val(""),e.$search.blur()}),c.on("focus",function(){c.isOpen()||e.$search.focus()}),c.on("results:all",function(a){if(null==a.query.term||""===a.query.term){e.showSearch(a)?e.$searchContainer.removeClass("select2-search--hide"):e.$searchContainer.addClass("select2-search--hide")}})},c.prototype.handleSearch=function(a){if(!this._keyUpPrevented){var b=this.$search.val();this.trigger("query",{term:b})}this._keyUpPrevented=!1},c.prototype.showSearch=function(a,b){return!0},c}),b.define("select2/dropdown/hidePlaceholder",[],function(){function a(a,b,c,d){this.placeholder=this.normalizePlaceholder(c.get("placeholder")),a.call(this,b,c,d)}return a.prototype.append=function(a,b){b.results=this.removePlaceholder(b.results),a.call(this,b)},a.prototype.normalizePlaceholder=function(a,b){return"string"==typeof b&&(b={id:"",text:b}),b},a.prototype.removePlaceholder=function(a,b){for(var c=b.slice(0),d=b.length-1;d>=0;d--){var e=b[d];this.placeholder.id===e.id&&c.splice(d,1)}return c},a}),b.define("select2/dropdown/infiniteScroll",["jquery"],function(a){function b(a,b,c,d){this.lastParams={},a.call(this,b,c,d),this.$loadingMore=this.createLoadingMore(),this.loading=!1}return b.prototype.append=function(a,b){this.$loadingMore.remove(),this.loading=!1,a.call(this,b),this.showLoadingMore(b)&&this.$results.append(this.$loadingMore)},b.prototype.bind=function(b,c,d){var e=this;b.call(this,c,d),c.on("query",function(a){e.lastParams=a,e.loading=!0}),c.on("query:append",function(a){e.lastParams=a,e.loading=!0}),this.$results.on("scroll",function(){var b=a.contains(document.documentElement,e.$loadingMore[0]);if(!e.loading&&b){e.$results.offset().top+e.$results.outerHeight(!1)+50>=e.$loadingMore.offset().top+e.$loadingMore.outerHeight(!1)&&e.loadMore()}})},b.prototype.loadMore=function(){this.loading=!0;var b=a.extend({},{page:1},this.lastParams);b.page++,this.trigger("query:append",b)},b.prototype.showLoadingMore=function(a,b){return b.pagination&&b.pagination.more},b.prototype.createLoadingMore=function(){var b=a('<li class="select2-results__option select2-results__option--load-more"role="treeitem" aria-disabled="true"></li>'),c=this.options.get("translations").get("loadingMore");return b.html(c(this.lastParams)),b},b}),b.define("select2/dropdown/attachBody",["jquery","../utils"],function(a,b){function c(b,c,d){this.$dropdownParent=d.get("dropdownParent")||a(document.body),b.call(this,c,d)}return c.prototype.bind=function(a,b,c){var d=this,e=!1;a.call(this,b,c),b.on("open",function(){d._showDropdown(),d._attachPositioningHandler(b),e||(e=!0,b.on("results:all",function(){d._positionDropdown(),d._resizeDropdown()}),b.on("results:append",function(){d._positionDropdown(),d._resizeDropdown()}))}),b.on("close",function(){d._hideDropdown(),d._detachPositioningHandler(b)}),this.$dropdownContainer.on("mousedown",function(a){a.stopPropagation()})},c.prototype.destroy=function(a){a.call(this),this.$dropdownContainer.remove()},c.prototype.position=function(a,b,c){b.attr("class",c.attr("class")),b.removeClass("select2"),b.addClass("select2-container--open"),b.css({position:"absolute",top:-999999}),this.$container=c},c.prototype.render=function(b){var c=a("<span></span>"),d=b.call(this);return c.append(d),this.$dropdownContainer=c,c},c.prototype._hideDropdown=function(a){this.$dropdownContainer.detach()},c.prototype._attachPositioningHandler=function(c,d){var e=this,f="scroll.select2."+d.id,g="resize.select2."+d.id,h="orientationchange.select2."+d.id,i=this.$container.parents().filter(b.hasScroll);i.each(function(){b.StoreData(this,"select2-scroll-position",{x:a(this).scrollLeft(),y:a(this).scrollTop()})}),i.on(f,function(c){var d=b.GetData(this,"select2-scroll-position");a(this).scrollTop(d.y)}),a(window).on(f+" "+g+" "+h,function(a){e._positionDropdown(),e._resizeDropdown()})},c.prototype._detachPositioningHandler=function(c,d){var e="scroll.select2."+d.id,f="resize.select2."+d.id,g="orientationchange.select2."+d.id;this.$container.parents().filter(b.hasScroll).off(e),a(window).off(e+" "+f+" "+g)},c.prototype._positionDropdown=function(){var b=a(window),c=this.$dropdown.hasClass("select2-dropdown--above"),d=this.$dropdown.hasClass("select2-dropdown--below"),e=null,f=this.$container.offset();f.bottom=f.top+this.$container.outerHeight(!1);var g={height:this.$container.outerHeight(!1)};g.top=f.top,g.bottom=f.top+g.height;var h={height:this.$dropdown.outerHeight(!1)},i={top:b.scrollTop(),bottom:b.scrollTop()+b.height()},j=i.top<f.top-h.height,k=i.bottom>f.bottom+h.height,l={left:f.left,top:g.bottom},m=this.$dropdownParent;"static"===m.css("position")&&(m=m.offsetParent());var n=m.offset();l.top-=n.top,l.left-=n.left,c||d||(e="below"),k||!j||c?!j&&k&&c&&(e="below"):e="above",("above"==e||c&&"below"!==e)&&(l.top=g.top-n.top-h.height),null!=e&&(this.$dropdown.removeClass("select2-dropdown--below select2-dropdown--above").addClass("select2-dropdown--"+e),this.$container.removeClass("select2-container--below select2-container--above").addClass("select2-container--"+e)),this.$dropdownContainer.css(l)},c.prototype._resizeDropdown=function(){var a={width:this.$container.outerWidth(!1)+"px"};this.options.get("dropdownAutoWidth")&&(a.minWidth=a.width,a.position="relative",a.width="auto"),this.$dropdown.css(a)},c.prototype._showDropdown=function(a){this.$dropdownContainer.appendTo(this.$dropdownParent),this._positionDropdown(),this._resizeDropdown()},c}),b.define("select2/dropdown/minimumResultsForSearch",[],function(){function a(b){for(var c=0,d=0;d<b.length;d++){var e=b[d];e.children?c+=a(e.children):c++}return c}function b(a,b,c,d){this.minimumResultsForSearch=c.get("minimumResultsForSearch"),this.minimumResultsForSearch<0&&(this.minimumResultsForSearch=1/0),a.call(this,b,c,d)}return b.prototype.showSearch=function(b,c){return!(a(c.data.results)<this.minimumResultsForSearch)&&b.call(this,c)},b}),b.define("select2/dropdown/selectOnClose",["../utils"],function(a){function b(){}return b.prototype.bind=function(a,b,c){var d=this;a.call(this,b,c),b.on("close",function(a){d._handleSelectOnClose(a)})},b.prototype._handleSelectOnClose=function(b,c){if(c&&null!=c.originalSelect2Event){var d=c.originalSelect2Event;if("select"===d._type||"unselect"===d._type)return}var e=this.getHighlightedResults();if(!(e.length<1)){var f=a.GetData(e[0],"data");null!=f.element&&f.element.selected||null==f.element&&f.selected||this.trigger("select",{data:f})}},b}),b.define("select2/dropdown/closeOnSelect",[],function(){function a(){}return a.prototype.bind=function(a,b,c){var d=this;a.call(this,b,c),b.on("select",function(a){d._selectTriggered(a)}),b.on("unselect",function(a){d._selectTriggered(a)})},a.prototype._selectTriggered=function(a,b){var c=b.originalEvent;c&&c.ctrlKey||this.trigger("close",{originalEvent:c,originalSelect2Event:b})},a}),b.define("select2/i18n/en",[],function(){return{errorLoading:function(){return"The results could not be loaded."},inputTooLong:function(a){var b=a.input.length-a.maximum,c="Please delete "+b+" character";return 1!=b&&(c+="s"),c},inputTooShort:function(a){return"Please enter "+(a.minimum-a.input.length)+" or more characters"},loadingMore:function(){return"Loading more resultsÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦"},maximumSelected:function(a){var b="You can only select "+a.maximum+" item";return 1!=a.maximum&&(b+="s"),b},noResults:function(){return"No results found"},searching:function(){return"SearchingÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚ÂƒÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â¢ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¬ÃƒÂƒÃ‚ÂƒÃƒÂ‚Ã‚Â‚ÃƒÂƒÃ‚Â‚ÃƒÂ‚Ã‚Â¦"}}}),b.define("select2/defaults",["jquery","require","./results","./selection/single","./selection/multiple","./selection/placeholder","./selection/allowClear","./selection/search","./selection/eventRelay","./utils","./translation","./diacritics","./data/select","./data/array","./data/ajax","./data/tags","./data/tokenizer","./data/minimumInputLength","./data/maximumInputLength","./data/maximumSelectionLength","./dropdown","./dropdown/search","./dropdown/hidePlaceholder","./dropdown/infiniteScroll","./dropdown/attachBody","./dropdown/minimumResultsForSearch","./dropdown/selectOnClose","./dropdown/closeOnSelect","./i18n/en"],function(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C){function D(){this.reset()}return D.prototype.apply=function(l){if(l=a.extend(!0,{},this.defaults,l),null==l.dataAdapter){if(null!=l.ajax?l.dataAdapter=o:null!=l.data?l.dataAdapter=n:l.dataAdapter=m,l.minimumInputLength>0&&(l.dataAdapter=j.Decorate(l.dataAdapter,r)),l.maximumInputLength>0&&(l.dataAdapter=j.Decorate(l.dataAdapter,s)),l.maximumSelectionLength>0&&(l.dataAdapter=j.Decorate(l.dataAdapter,t)),l.tags&&(l.dataAdapter=j.Decorate(l.dataAdapter,p)),null==l.tokenSeparators&&null==l.tokenizer||(l.dataAdapter=j.Decorate(l.dataAdapter,q)),null!=l.query){var C=b(l.amdBase+"compat/query");l.dataAdapter=j.Decorate(l.dataAdapter,C)}if(null!=l.initSelection){var D=b(l.amdBase+"compat/initSelection");l.dataAdapter=j.Decorate(l.dataAdapter,D)}}if(null==l.resultsAdapter&&(l.resultsAdapter=c,null!=l.ajax&&(l.resultsAdapter=j.Decorate(l.resultsAdapter,x)),null!=l.placeholder&&(l.resultsAdapter=j.Decorate(l.resultsAdapter,w)),l.selectOnClose&&(l.resultsAdapter=j.Decorate(l.resultsAdapter,A))),null==l.dropdownAdapter){if(l.multiple)l.dropdownAdapter=u;else{var E=j.Decorate(u,v);l.dropdownAdapter=E}if(0!==l.minimumResultsForSearch&&(l.dropdownAdapter=j.Decorate(l.dropdownAdapter,z)),l.closeOnSelect&&(l.dropdownAdapter=j.Decorate(l.dropdownAdapter,B)),null!=l.dropdownCssClass||null!=l.dropdownCss||null!=l.adaptDropdownCssClass){var F=b(l.amdBase+"compat/dropdownCss");l.dropdownAdapter=j.Decorate(l.dropdownAdapter,F)}l.dropdownAdapter=j.Decorate(l.dropdownAdapter,y)}if(null==l.selectionAdapter){if(l.multiple?l.selectionAdapter=e:l.selectionAdapter=d,null!=l.placeholder&&(l.selectionAdapter=j.Decorate(l.selectionAdapter,f)),l.allowClear&&(l.selectionAdapter=j.Decorate(l.selectionAdapter,g)),l.multiple&&(l.selectionAdapter=j.Decorate(l.selectionAdapter,h)),null!=l.containerCssClass||null!=l.containerCss||null!=l.adaptContainerCssClass){var G=b(l.amdBase+"compat/containerCss");l.selectionAdapter=j.Decorate(l.selectionAdapter,G)}l.selectionAdapter=j.Decorate(l.selectionAdapter,i)}if("string"==typeof l.language)if(l.language.indexOf("-")>0){var H=l.language.split("-"),I=H[0];l.language=[l.language,I]}else l.language=[l.language];if(a.isArray(l.language)){var J=new k;l.language.push("en");for(var K=l.language,L=0;L<K.length;L++){var M=K[L],N={};try{N=k.loadPath(M)}catch(a){try{M=this.defaults.amdLanguageBase+M,N=k.loadPath(M)}catch(a){l.debug&&window.console&&console.warn&&console.warn('Select2: The language file for "'+M+'" could not be automatically loaded. A fallback will be used instead.');continue}}J.extend(N)}l.translations=J}else{var O=k.loadPath(this.defaults.amdLanguageBase+"en"),P=new k(l.language);P.extend(O),l.translations=P}return l},D.prototype.reset=function(){function b(a){function b(a){return l[a]||a}return a.replace(/[^\u0000-\u007E]/g,b)}function c(d,e){if(""===a.trim(d.term))return e;if(e.children&&e.children.length>0){for(var f=a.extend(!0,{},e),g=e.children.length-1;g>=0;g--){null==c(d,e.children[g])&&f.children.splice(g,1)}return f.children.length>0?f:c(d,f)}var h=b(e.text).toUpperCase(),i=b(d.term).toUpperCase();return h.indexOf(i)>-1?e:null}this.defaults={amdBase:"./",amdLanguageBase:"./i18n/",closeOnSelect:!0,debug:!1,dropdownAutoWidth:!1,escapeMarkup:j.escapeMarkup,language:C,matcher:c,minimumInputLength:0,maximumInputLength:0,maximumSelectionLength:0,minimumResultsForSearch:0,selectOnClose:!1,sorter:function(a){return a},templateResult:function(a){return a.text},templateSelection:function(a){return a.text},theme:"default",width:"resolve"}},D.prototype.set=function(b,c){var d=a.camelCase(b),e={};e[d]=c;var f=j._convertData(e);a.extend(!0,this.defaults,f)},new D}),b.define("select2/options",["require","jquery","./defaults","./utils"],function(a,b,c,d){function e(b,e){if(this.options=b,null!=e&&this.fromElement(e),this.options=c.apply(this.options),e&&e.is("input")){var f=a(this.get("amdBase")+"compat/inputData");this.options.dataAdapter=d.Decorate(this.options.dataAdapter,f)}}return e.prototype.fromElement=function(a){var c=["select2"];null==this.options.multiple&&(this.options.multiple=a.prop("multiple")),null==this.options.disabled&&(this.options.disabled=a.prop("disabled")),null==this.options.language&&(a.prop("lang")?this.options.language=a.prop("lang").toLowerCase():a.closest("[lang]").prop("lang")&&(this.options.language=a.closest("[lang]").prop("lang"))),null==this.options.dir&&(a.prop("dir")?this.options.dir=a.prop("dir"):a.closest("[dir]").prop("dir")?this.options.dir=a.closest("[dir]").prop("dir"):this.options.dir="ltr"),a.prop("disabled",this.options.disabled),a.prop("multiple",this.options.multiple),d.GetData(a[0],"select2Tags")&&(this.options.debug&&window.console&&console.warn&&console.warn('Select2: The `data-select2-tags` attribute has been changed to use the `data-data` and `data-tags="true"` attributes and will be removed in future versions of Select2.'),d.StoreData(a[0],"data",d.GetData(a[0],"select2Tags")),d.StoreData(a[0],"tags",!0)),d.GetData(a[0],"ajaxUrl")&&(this.options.debug&&window.console&&console.warn&&console.warn("Select2: The `data-ajax-url` attribute has been changed to `data-ajax--url` and support for the old attribute will be removed in future versions of Select2."),a.attr("ajax--url",d.GetData(a[0],"ajaxUrl")),d.StoreData(a[0],"ajax-Url",d.GetData(a[0],"ajaxUrl")));var e={};e=b.fn.jquery&&"1."==b.fn.jquery.substr(0,2)&&a[0].dataset?b.extend(!0,{},a[0].dataset,d.GetData(a[0])):d.GetData(a[0]);var f=b.extend(!0,{},e);f=d._convertData(f);for(var g in f)b.inArray(g,c)>-1||(b.isPlainObject(this.options[g])?b.extend(this.options[g],f[g]):this.options[g]=f[g]);return this},e.prototype.get=function(a){return this.options[a]},e.prototype.set=function(a,b){this.options[a]=b},e}),b.define("select2/core",["jquery","./options","./utils","./keys"],function(a,b,c,d){var e=function(a,d){null!=c.GetData(a[0],"select2")&&c.GetData(a[0],"select2").destroy(),this.$element=a,this.id=this._generateId(a),d=d||{},this.options=new b(d,a),e.__super__.constructor.call(this);var f=a.attr("tabindex")||0;c.StoreData(a[0],"old-tabindex",f),a.attr("tabindex","-1");var g=this.options.get("dataAdapter");this.dataAdapter=new g(a,this.options);var h=this.render();this._placeContainer(h);var i=this.options.get("selectionAdapter");this.selection=new i(a,this.options),this.$selection=this.selection.render(),this.selection.position(this.$selection,h);var j=this.options.get("dropdownAdapter");this.dropdown=new j(a,this.options),this.$dropdown=this.dropdown.render(),this.dropdown.position(this.$dropdown,h);var k=this.options.get("resultsAdapter");this.results=new k(a,this.options,this.dataAdapter),this.$results=this.results.render(),this.results.position(this.$results,this.$dropdown);var l=this;this._bindAdapters(),this._registerDomEvents(),this._registerDataEvents(),this._registerSelectionEvents(),this._registerDropdownEvents(),this._registerResultsEvents(),this._registerEvents(),this.dataAdapter.current(function(a){l.trigger("selection:update",{data:a})}),a.addClass("select2-hidden-accessible"),a.attr("aria-hidden","true"),this._syncAttributes(),c.StoreData(a[0],"select2",this),a.data("select2",this)};return c.Extend(e,c.Observable),e.prototype._generateId=function(a){var b="";return b=null!=a.attr("id")?a.attr("id"):null!=a.attr("name")?a.attr("name")+"-"+c.generateChars(2):c.generateChars(4),b=b.replace(/(:|\.|\[|\]|,)/g,""),b="select2-"+b},e.prototype._placeContainer=function(a){a.insertAfter(this.$element);var b=this._resolveWidth(this.$element,this.options.get("width"));null!=b&&a.css("width",b)},e.prototype._resolveWidth=function(a,b){var c=/^width:(([-+]?([0-9]*\.)?[0-9]+)(px|em|ex|%|in|cm|mm|pt|pc))/i;if("resolve"==b){var d=this._resolveWidth(a,"style");return null!=d?d:this._resolveWidth(a,"element")}if("element"==b){var e=a.outerWidth(!1);return e<=0?"auto":e+"px"}if("style"==b){var f=a.attr("style");if("string"!=typeof f)return null;for(var g=f.split(";"),h=0,i=g.length;h<i;h+=1){var j=g[h].replace(/\s/g,""),k=j.match(c);if(null!==k&&k.length>=1)return k[1]}return null}return b},e.prototype._bindAdapters=function(){this.dataAdapter.bind(this,this.$container),this.selection.bind(this,this.$container),this.dropdown.bind(this,this.$container),this.results.bind(this,this.$container)},e.prototype._registerDomEvents=function(){var b=this;this.$element.on("change.select2",function(){b.dataAdapter.current(function(a){b.trigger("selection:update",{data:a})})}),this.$element.on("focus.select2",function(a){b.trigger("focus",a)}),this._syncA=c.bind(this._syncAttributes,this),this._syncS=c.bind(this._syncSubtree,this),this.$element[0].attachEvent&&this.$element[0].attachEvent("onpropertychange",this._syncA);var d=window.MutationObserver||window.WebKitMutationObserver||window.MozMutationObserver;null!=d?(this._observer=new d(function(c){a.each(c,b._syncA),a.each(c,b._syncS)}),this._observer.observe(this.$element[0],{attributes:!0,childList:!0,subtree:!1})):this.$element[0].addEventListener&&(this.$element[0].addEventListener("DOMAttrModified",b._syncA,!1),this.$element[0].addEventListener("DOMNodeInserted",b._syncS,!1),this.$element[0].addEventListener("DOMNodeRemoved",b._syncS,!1))},e.prototype._registerDataEvents=function(){var a=this;this.dataAdapter.on("*",function(b,c){a.trigger(b,c)})},e.prototype._registerSelectionEvents=function(){var b=this,c=["toggle","focus"];this.selection.on("toggle",function(){b.toggleDropdown()}),this.selection.on("focus",function(a){b.focus(a)}),this.selection.on("*",function(d,e){-1===a.inArray(d,c)&&b.trigger(d,e)})},e.prototype._registerDropdownEvents=function(){var a=this;this.dropdown.on("*",function(b,c){a.trigger(b,c)})},e.prototype._registerResultsEvents=function(){var a=this;this.results.on("*",function(b,c){a.trigger(b,c)})},e.prototype._registerEvents=function(){var a=this;this.on("open",function(){a.$container.addClass("select2-container--open")}),this.on("close",function(){a.$container.removeClass("select2-container--open")}),this.on("enable",function(){a.$container.removeClass("select2-container--disabled")}),this.on("disable",function(){a.$container.addClass("select2-container--disabled")}),this.on("blur",function(){a.$container.removeClass("select2-container--focus")}),this.on("query",function(b){a.isOpen()||a.trigger("open",{}),this.dataAdapter.query(b,function(c){a.trigger("results:all",{data:c,query:b})})}),this.on("query:append",function(b){this.dataAdapter.query(b,function(c){a.trigger("results:append",{data:c,query:b})})}),this.on("keypress",function(b){var c=b.which;a.isOpen()?c===d.ESC||c===d.TAB||c===d.UP&&b.altKey?(a.close(),b.preventDefault()):c===d.ENTER?(a.trigger("results:select",{}),b.preventDefault()):c===d.SPACE&&b.ctrlKey?(a.trigger("results:toggle",{}),b.preventDefault()):c===d.UP?(a.trigger("results:previous",{}),b.preventDefault()):c===d.DOWN&&(a.trigger("results:next",{}),b.preventDefault()):(c===d.ENTER||c===d.SPACE||c===d.DOWN&&b.altKey)&&(a.open(),b.preventDefault())})},e.prototype._syncAttributes=function(){this.options.set("disabled",this.$element.prop("disabled")),this.options.get("disabled")?(this.isOpen()&&this.close(),this.trigger("disable",{})):this.trigger("enable",{})},e.prototype._syncSubtree=function(a,b){var c=!1,d=this;if(!a||!a.target||"OPTION"===a.target.nodeName||"OPTGROUP"===a.target.nodeName){if(b)if(b.addedNodes&&b.addedNodes.length>0)for(var e=0;e<b.addedNodes.length;e++){var f=b.addedNodes[e];f.selected&&(c=!0)}else b.removedNodes&&b.removedNodes.length>0&&(c=!0);else c=!0;c&&this.dataAdapter.current(function(a){d.trigger("selection:update",{data:a})})}},e.prototype.trigger=function(a,b){var c=e.__super__.trigger,d={open:"opening",close:"closing",select:"selecting",unselect:"unselecting",clear:"clearing"};if(void 0===b&&(b={}),a in d){var f=d[a],g={prevented:!1,name:a,args:b};if(c.call(this,f,g),g.prevented)return void(b.prevented=!0)}c.call(this,a,b)},e.prototype.toggleDropdown=function(){this.options.get("disabled")||(this.isOpen()?this.close():this.open())},e.prototype.open=function(){this.isOpen()||this.trigger("query",{})},e.prototype.close=function(){this.isOpen()&&this.trigger("close",{})},e.prototype.isOpen=function(){return this.$container.hasClass("select2-container--open")},e.prototype.hasFocus=function(){return this.$container.hasClass("select2-container--focus")},e.prototype.focus=function(a){this.hasFocus()||(this.$container.addClass("select2-container--focus"),this.trigger("focus",{}))},e.prototype.enable=function(a){this.options.get("debug")&&window.console&&console.warn&&console.warn('Select2: The `select2("enable")` method has been deprecated and will be removed in later Select2 versions. Use $element.prop("disabled") instead.'),null!=a&&0!==a.length||(a=[!0]);var b=!a[0];this.$element.prop("disabled",b)},e.prototype.data=function(){this.options.get("debug")&&arguments.length>0&&window.console&&console.warn&&console.warn('Select2: Data can no longer be set using `select2("data")`. You should consider setting the value instead using `$element.val()`.');var a=[];return this.dataAdapter.current(function(b){a=b}),a},e.prototype.val=function(b){if(this.options.get("debug")&&window.console&&console.warn&&console.warn('Select2: The `select2("val")` method has been deprecated and will be removed in later Select2 versions. Use $element.val() instead.'),null==b||0===b.length)return this.$element.val();var c=b[0];a.isArray(c)&&(c=a.map(c,function(a){return a.toString()})),this.$element.val(c).trigger("change")},e.prototype.destroy=function(){this.$container.remove(),this.$element[0].detachEvent&&this.$element[0].detachEvent("onpropertychange",this._syncA),null!=this._observer?(this._observer.disconnect(),this._observer=null):this.$element[0].removeEventListener&&(this.$element[0].removeEventListener("DOMAttrModified",this._syncA,!1),this.$element[0].removeEventListener("DOMNodeInserted",this._syncS,!1),this.$element[0].removeEventListener("DOMNodeRemoved",this._syncS,!1)),this._syncA=null,this._syncS=null,this.$element.off(".select2"),this.$element.attr("tabindex",c.GetData(this.$element[0],"old-tabindex")),this.$element.removeClass("select2-hidden-accessible"),this.$element.attr("aria-hidden","false"),c.RemoveData(this.$element[0]),this.$element.removeData("select2"),this.dataAdapter.destroy(),this.selection.destroy(),this.dropdown.destroy(),this.results.destroy(),this.dataAdapter=null,this.selection=null,this.dropdown=null,this.results=null},e.prototype.render=function(){var b=a('<span class="select2 select2-container"><span class="selection"></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>');return b.attr("dir",this.options.get("dir")),this.$container=b,this.$container.addClass("select2-container--"+this.options.get("theme")),c.StoreData(b[0],"element",this.$element),b},e}),b.define("jquery-mousewheel",["jquery"],function(a){return a}),b.define("jquery.select2",["jquery","jquery-mousewheel","./select2/core","./select2/defaults","./select2/utils"],function(a,b,c,d,e){if(null==a.fn.select2){var f=["open","close","destroy"];a.fn.select2=function(b){if("object"==typeof(b=b||{}))return this.each(function(){var d=a.extend(!0,{},b);new c(a(this),d)}),this;if("string"==typeof b){var d,g=Array.prototype.slice.call(arguments,1);return this.each(function(){var a=e.GetData(this,"select2");null==a&&window.console&&console.error&&console.error("The select2('"+b+"') method was called on an element that is not using Select2."),d=a[b].apply(a,g)}),a.inArray(b,f)>-1?this:d}throw new Error("Invalid arguments for Select2: "+b)}}return null==a.fn.select2.defaults&&(a.fn.select2.defaults=d),c}),{define:b.define,require:b.require}}(),c=b.require("jquery.select2");return a.fn.select2.amd=b,c});
if(typeof define != "undefined"){
  define = __origDefine;
}



;(function ($, window, document){
   
   var review = new function(){
      var  reviewCore = this
         , opts = {}
         , itemWhse = {}
         , selectedWhse = ""
         , selectedColor = ""
         ;
          
      reviewCore.init = function(options){
         $.extend(true,opts,options);
         
         var $tmp = $("#reviewDialog");
         $("#reviewDialog").remove();
         $('body').append($tmp);
         $tmp = null;     
         $("#reviewDialog").modal({show:false});
        
         // Bind Events
         $("input[name='rating']").on('click',selectRating);
         $("#submitReview").on('click',submitReview);
         $(".helpfulYes,.helpfulNo").on('click',function(){ submitHelpful(this); });         
         $("#btnWriteReviewLogin").on('click',reviewLoginRedir);
      };

      //Private Functions
      function selectRating(msg){ 
         $("input[name='reviewRating']").val( $("input[name='rating']:checked").val() );
      };
      function reviewLoginRedir(){
        $.wam.confirm( $.wam.getText('review_login'),function(yes){ 
          if(yes){
             $.wam.golink('/wam_tmpl/login.p','page=' + $.wam.opts.defPages.login + '&loginLocation=' + encodeURIComponent('/wam_tmpl/catalog_product.p?page=' + $.wam.opts.page + '&product=' + $.wam.product.prodObj.styleCode) );
          }
        }); 
      };
      function submitReview(){ 
        var query = 'action=submitReview&content=json&product=' + $.wam.product.prodObj.styleCode;
        $('#reviewMsg').html('').removeClass('alert alert-danger alert-success');
        //Validate - check for invalid char / title entered etc. 
        if( document.productReview.reviewTitle.value == '' ){
           $('#reviewMsg').html( $.wam.getText('no_rev_title') ).addClass('alert alert-danger');
           return;
        }
        if( document.productReview.reviewBody.value == '' ){
           $('#reviewMsg').html( $.wam.getText('no_rev_review')  ).addClass('alert alert-danger');
           return;
        }        
        if( $("input[name='rating']:checked",".ratingSelect").length == 0 ){
           $('#reviewMsg').html( $.wam.getText('no_rev_star') ).addClass('alert alert-danger');
           return;
        }        
        query += '&' + $('form[name="productReview"]').serialize();
        $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,submitReview_callback,'application/json','json',true);
      };
      function submitReview_callback(data){
         if(typeof data.msg == "object"){
            $('#reviewMsg').html( data.msg[0].msg );
            if( data.msg[0].success ){
              $('#reviewMsg').addClass('alert alert-success');
              $('form[name="productReview"]').slideUp();
              $("#submitReview").hide();              
            }else{
              $('#reviewMsg').addClass('alert alert-danger');              
            }
         }
      };

      function submitHelpful(vThis){ 
        var $this = $(vThis),
            rowID = $this.closest('.reviewDetail').data('rowid'),
            isHelpful = $this.hasClass('helpfulYes'),
            query = 'action=submitHelpful&content=json&reviewRowID=' + rowID + '&isHelpful=' + isHelpful;

        $.wam.ajaxPost('/wam_tmpl/catalog_product.p?' + query,'POST',null,function(data){ submitHelpful_callback(data, $this); },'application/json','json',true);
      };
      function submitHelpful_callback(data,$this){
         if(typeof data.msg == "object"){
            //Could set localstorage value of rowid to prevent submitting multiple times... then check and hide yes / no in docReady... 
            $this.closest('.helpfulOuter').html( data.msg[0].msg );
         }
      };

      function goReviewMsg(msg){
          var $revMsg = $('#reviewMsg');
          $revMsg.html(msg);
          //Scroll to the top of the browse products
          $("html,body").animate({scrollTop: $revMsg.offset().top },250);
      };

      //Extend $.wam.product with review... this must be done within the subtmpl function so it will have access to parents internal vars... 
      $.wam.product.extend('review',reviewCore);   

   }; //End review
   
})( jQuery, window, document );




jQuery(document).ready(function(){

$.wam.product.init(prodJSON,prodOptsJSON);
if(typeof vLgProdImgError != 'undefined'){
   $.wam.imgError(vLgProdImgError,'large');
}

//Replace lazyloaded images on tab click  
$('.prodTopTabs a').on('shown.bs.tab',function(){ 
   $("img[data-lazyload]",".compDetail").unveil(30);  
    $(this).find(".glyphicon").first().html("&#xe259;");
});
 $('.nav-tabs a').on('hide.bs.tab', function(e){
     $(this).find(".glyphicon").first().html("&#xe260;");
  });





$.wam.product.review.init();



});