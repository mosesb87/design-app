#!/bin/bash
# usage: fetch.sh URL FILENAME
URL="$1"; FILE="$2"
DIR=/home/claude/reviews/royal-apparel/captures
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128 Safari/537.36"
TS=$(date -u +%Y-%m-%dT%H:%M:%SZ)
OUT=$(curl -sL -A "$UA" --max-time 45 -o "$DIR/$FILE" -w "%{http_code} %{url_effective} %{num_redirects} %{size_download}" "$URL")
CODE=$(echo "$OUT" | awk '{print $1}')
EFF=$(echo "$OUT" | awk '{print $2}')
NRED=$(echo "$OUT" | awk '{print $3}')
SIZE=$(echo "$OUT" | awk '{print $4}')
echo "$URL -> $FILE | HTTP $CODE | final: $EFF | redirects: $NRED | bytes: $SIZE | fetched-at: $TS" >> "$DIR/index.txt"
echo "HTTP $CODE final=$EFF redirects=$NRED bytes=$SIZE"
