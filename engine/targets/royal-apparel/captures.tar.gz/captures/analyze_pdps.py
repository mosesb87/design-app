import re,json,html,glob,os,collections
def balanced(s):
    depth=0; instr=False; esc=False
    for idx,ch in enumerate(s):
        if instr:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch=='"': instr=False
        else:
            if ch=='"': instr=True
            elif ch=='{': depth+=1
            elif ch=='}':
                depth-=1
                if depth==0: return s[:idx+1]
    return None
rows=[]
files=sorted(glob.glob('/home/claude/reviews/royal-apparel/captures/product-*.html'))
for f in files:
    x=open(f,encoding='utf-8',errors='replace').read()
    g=lambda p: re.findall(p,x,re.S|re.I)
    r={'file':os.path.basename(f)}
    r['title']=html.unescape(g(r'<title>(.*?)</title>')[0].strip()) if g(r'<title>(.*?)</title>') else ''
    md=g(r'<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)'); r['meta']=html.unescape(md[0]) if md else ''
    r['canonical']=bool(g(r'<link[^>]+rel=["\']canonical["\']'))
    r['ogimage']=bool(g(r'og:image'))
    h1=g(r'<h1[^>]*>(.*?)</h1>'); r['h1']=html.unescape(re.sub(r'<[^>]+>','',h1[0]).strip()) if h1 else ''
    r['breadcrumb']=bool(g(r'BreadcrumbList|class=["\'][^"\']*breadcrumb'))
    lds=g(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>')
    r['ld_count']=len(lds); r['ld_product_blocks']=sum(1 for l in lds if '"Product"' in l)
    prod=[l for l in lds if '"offers"' in l]
    r['offer_avail']=''; r['offer_url']=''; r['ld_brand']=False; r['ld_gtin']=False; r['ld_mpn']=False; r['rating']=''
    if prod:
        try:
            d=json.loads(prod[0]); o=d.get('offers',[{}])[0]; r['offer_avail']=o.get('availability',''); r['offer_url']=o.get('url',''); r['offer_price']=o.get('price','')
            r['ld_brand']='brand' in d; r['ld_gtin']=any(k.startswith('gtin') for k in d); r['ld_mpn']='mpn' in d
        except Exception as e: r['offer_avail']='PARSE_ERR'
    for l in lds:
        m=re.search(r'"ratingValue":\s*"([^"]+)".*?"ratingCount":\s*"([^"]+)"',l,re.S)
        if m: r['rating']=m.group(1)+'/'+m.group(2)
    r['imgs']=len(g(r'<img\b')); r['imgs_noalt']=len([i for i in g(r'<img\b[^>]*>') if 'alt=' not in i.lower()])
    r['view_item']=bool(g(r'"event":\s*"view_item"'))
    i=x.find('var prodJSON = ')
    if i>0:
        d=json.loads(balanced(x[i+15:])); p=d['product'][0]
        r['style']=p['styleCode']; r['colors']=len(p['color']); r['sizes']=len(p['size']); r['altviews']=len(p['altView']); r['video']=bool(p['video']); r['price']=p['regPrice']; r['pricehi']=p['regHighPrice']; r['onSale']=p['onSale']; r['status']=p['itemStatus']; r['street']=p['streetDate']
        desc=html.unescape(re.sub(r'<[^>]+>',' ',p['fullDesc'])); r['desc_words']=len(desc.split()); r['webDesc_words']=len(re.sub(r'<[^>]+>',' ',p['webDesc']).split())
        r['hex_ffffff']=sum(1 for c in p['color'] if c['hexColor'].upper()=='FFFFFF'); r['imgs_main']=bool(p['imageLg'])
        r['show_stock_sizes']=sum(1 for s in p['size'] if s['show_stock'])
        m=re.search(r'var prodOptsJSON = (\{.*?\});',x,re.S); r['showStock_opt']=('showStock : true' in x)
    rows.append(r)
json.dump(rows,open('/home/claude/reviews/royal-apparel/captures/pdp-sample-analysis.json','w'),indent=1)
print(len(rows),'PDPs')
for r in rows:
    print(f"{r.get('style','?'):10} | title={r['title'][:45]!r:48} | meta={'Y' if r['meta'] else 'N'} canon={'Y' if r['canonical'] else 'N'} ogimg={'Y' if r['ogimage'] else 'N'} bc={'Y' if r['breadcrumb'] else 'N'} | ldProd={r['ld_product_blocks']} avail={r['offer_avail']!r} brand={r['ld_brand']} gtin={r['ld_gtin']} rating={r['rating']} | colors={r.get('colors')} sizes={r.get('sizes')} alts={r.get('altviews')} vid={r.get('video')} price={r.get('price')}-{r.get('pricehi')} status={r.get('status')} street={r.get('street')} descw={r.get('desc_words')} noalt={r['imgs_noalt']}/{r['imgs']}")
print('\n--- meta descriptions:')
for r in rows: print(r['meta'][:150])
