import re,html,sys,json
def inspect(f, verbose=True):
    s=open(f,encoding='utf-8',errors='ignore').read()
    def g(p,flags=re.I|re.S):
        m=re.search(p,s,flags); return html.unescape(m.group(1).strip()) if m else None
    r={}
    r['file']=f
    r['title']=g(r'<title[^>]*>(.*?)</title>')
    r['desc']=g(r'<meta\s+name="description"\s+content="([^"]*)"')
    r['canonical']=g(r'<link\s+rel="canonical"\s+href="([^"]*)"')
    r['ogimage']=g(r'<meta\s+property="og:image"\s+content="([^"]*)"')
    lds=re.findall(r'<script type="application/ld\+json"[^>]*>(.*?)</script>',s,re.S)
    types=[]
    r['ld_types']=[]
    for t in lds:
        try:
            j=json.loads(t)
            items=j if isinstance(j,list) else [j]
            for it in items:
                ty=it.get('@type'); r['ld_types'].append(ty)
                if ty=='Product':
                    r['ld_product']={k:(str(it.get(k))[:80]) for k in ['name','sku','brand','offers','aggregateRating','image','description'] if k in it}
                    off=it.get('offers')
                    if isinstance(off,list): off=off[0]
                    if isinstance(off,dict): r['ld_offer']={k:off.get(k) for k in ['price','priceCurrency','availability','url'] if k in off}
                    if 'aggregateRating' in it: r['ld_rating']=it['aggregateRating']
        except Exception as e:
            r['ld_types'].append('PARSE_ERR:'+t[:60].replace('\n',' '))
    r['breadcrumb_nav']=bool(re.search(r'aria-label="breadcrumbs?"',s,re.I))
    r['breadcrumb_ld']='BreadcrumbList' in s
    r['skip_link']=bool(re.search(r'skip to content',s,re.I))
    r['recharge']=len(re.findall(r'recharge',s,re.I))
    r['subscribe_text']=re.findall(r'(Subscribe\s*&amp;\s*Save|Subscribe and Save|Subscription|Deliver every|One-time purchase|One Time Purchase)',s,re.I)[:5]
    r['selling_plan']=len(re.findall(r'selling_plan',s))
    r['supplement_facts_text']=len(re.findall(r'Supplement Facts',s,re.I))
    r['supplement_facts_img']=re.findall(r'<img[^>]*(?:facts|SF_|supp|label)[^>]*>',s,re.I)[:3]
    r['faq_count']=len(re.findall(r'FAQ|Frequently Asked',s,re.I))
    r['faq_ld']='FAQPage' in s
    r['how_to_use']=re.findall(r'(How to Use|Suggested Use|Directions|How to Take|Recommended Use)',s,re.I)[:3]
    r['stamped']=len(re.findall(r'stamped',s,re.I))
    r['review_count_text']=re.findall(r'(\d[\d,]*)\s*(?:Reviews|reviews)',s)[:5]
    r['rating_text']=re.findall(r'data-rating="([\d.]+)"',s)[:2]
    r['add_to_cart']=re.findall(r'(Add to cart|Add to Cart|ADD TO CART|Buy it now|Sold out)',s)[:4]
    r['sold_out']=len(re.findall(r'sold out',s,re.I))
    r['rebuy']=len(re.findall(r'rebuy',s,re.I))
    imgs=re.findall(r'<img[^>]*>',s)
    pimgs=[i for i in imgs if '/cdn/shop/files/' in i or '/cdn/shop/products/' in i]
    noalt=[i for i in pimgs if re.search(r'alt=""',i) or not re.search(r'alt=',i)]
    r['imgs_total']=len(imgs); r['product_imgs']=len(pimgs); r['product_imgs_noalt']=len(noalt)
    r['h1']=re.findall(r'<h1[^>]*>(.*?)</h1>',s,re.S)[:2]
    r['h1']=[html.unescape(re.sub(r'<[^>]+>','',x)).strip()[:80] for x in r['h1']]
    r['h2s']=[html.unescape(re.sub(r'<[^>]+>','',x)).strip()[:60] for x in re.findall(r'<h2[^>]*>(.*?)</h2>',s,re.S)][:25]
    r['h3s']=[html.unescape(re.sub(r'<[^>]+>','',x)).strip()[:60] for x in re.findall(r'<h3[^>]*>(.*?)</h3>',s,re.S)][:25]
    r['prices']=re.findall(r'\$\d+\.\d\d',s)[:12]
    r['tabs']=re.findall(r'(?:accordion|tab)[^>]*>\s*<[^>]*>\s*([A-Z][A-Za-z &]{3,40})<',s)[:10]
    r['route']=len(re.findall(r'route',s,re.I))
    r['redo']=len(re.findall(r'redo',s,re.I))
    r['size_pixels']=len(s)
    if verbose:
        for k,v in r.items(): print(f"{k}: {v}")
    return r
if __name__=='__main__':
    for f in sys.argv[1:]:
        inspect(f); print('='*80)
