#!/bin/bash
# Usage: fetch.sh <url> <outfile-name> [method]
# Saves body to captures/<outfile-name>, appends a line to captures/index.txt
URL="$1"
OUT="$2"
METHOD="${3:-GET}"
DIR="/home/claude/reviews/blueroot/captures"
UA="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128 Safari/537.36"
TS=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
if [ "$METHOD" = "HEAD" ]; then
  CODE=$(curl -sS -I -L -A "$UA" -o "$DIR/$OUT" -w "%{http_code} %{url_effective}" "$URL" 2>&1)
else
  CODE=$(curl -sS -L -A "$UA" -o "$DIR/$OUT" -w "%{http_code} %{url_effective} %{size_download}" "$URL" 2>&1)
fi
echo "$URL -> $OUT -> $CODE -> $TS ($METHOD)" >> "$DIR/index.txt"
echo "$CODE"
