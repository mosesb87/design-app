import re,html,sys
def pagetext(f,maxlen=3500,start='id="main-content"'):
    s=open(f,encoding='utf-8',errors='ignore').read()
    i=s.find(start); main=s[i:] if i>0 else s
    j=main.find('<footer'); 
    if j>0: main=main[:j]
    t=re.sub(r'<script.*?</script>','',main,flags=re.S)
    t=re.sub(r'<style.*?</style>','',t,flags=re.S)
    t=re.sub(r'<noscript.*?</noscript>','',t,flags=re.S)
    t=re.sub(r'<(h[1-6]|p|li|div|section|summary|details|button|label|option|span|tr|td|th|br)[^>]*>','\n',t)
    t=re.sub(r'<[^>]+>',' ',t); t=html.unescape(t)
    lines=[re.sub(r'\s+',' ',l).strip() for l in t.split('\n')]
    out=[]
    for l in lines:
        if not l: continue
        if out and out[-1]==l: continue
        out.append(l)
    return '\n'.join(out)[:maxlen]
if __name__=='__main__':
    for f in sys.argv[1:]:
        print("=====",f); print(pagetext(f))
