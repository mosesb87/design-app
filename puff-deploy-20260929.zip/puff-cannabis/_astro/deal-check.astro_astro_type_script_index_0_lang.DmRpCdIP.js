import{_ as e,a as t,b as n,c as r,f as i,i as a,l as o,m as s,o as c,s as l,t as u,u as d,y as f}from"./checks.BkqC5i3L.js";import{a as p,i as m,n as h,o as g,r as _,t as v}from"./store.C4zEq6Hh.js";var y=(e,t=document)=>t.querySelector(e),b=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`),x=e=>`$${e.toFixed(2)}`,S=e=>{let t=p(e.id);return t===void 0?e.exclusionRaw:t??null},C=t=>u(t,m(t.id),e,{terms:S(t)}),w={READY:`status--ok`,REVIEW:`status--warn`,BLOCK:`status--stop`,UNKNOWN:`status--unknown`},T={store:`monroe`,q:``,cat:`all`,resolvableOnly:!1,sort:`title`};function E(){let e=new URLSearchParams(location.search),t=e.get(`store`);return{store:t&&f[t]?t:T.store,q:e.get(`q`)??``,cat:e.get(`cat`)??`all`,resolvableOnly:e.get(`resolvable`)===`1`,sort:e.get(`sort`)??`title`}}function D(e){let t=new URLSearchParams;e.store!==T.store&&t.set(`store`,e.store),e.q&&t.set(`q`,e.q),e.cat!==`all`&&t.set(`cat`,e.cat),e.resolvableOnly&&t.set(`resolvable`,`1`),e.sort!==T.sort&&t.set(`sort`,e.sort);let n=h(_());n&&t.set(`fix`,n);let r=t.toString();history.replaceState(null,``,r?`?${r}`:location.pathname)}function O(e,n,r){if(r.cat!==`all`&&n!==r.cat)return!1;let i=r.q.trim().toLowerCase();if(!i)return!0;let a=m(e.id),o=[e.rawTitle,e.exclusionRaw??``,e.storePrefix??``,a?.productHint??``,...(a?.brandIds??[]).map(e=>d[e]?.name??e)].join(` `).toLowerCase();if(o.includes(i))return!0;let s=t(i);return s.length>0&&t(o).includes(s)}function k(e,t,n){let r=c(e,t),i=l(e,t),a=[];n!==null&&a.push(`<span class="mono"><strong>${x(n)}</strong> each under this deal <span style="color:var(--ink-3)">(derived from the published bundle)</span></span>`),r===null?a.push(`<span class="mono" style="color:var(--ink-3)">no single-item price in the sample for this store</span>`):a.push(`<span class="mono">single item ${x(r)} <span class="status ${i?`status--ok`:`status--unknown`}">${i?`observed at this store`:`modelled`}</span></span>`);let o=[];return e.status!==`active`&&o.push(`<span class="status status--stop">${b(e.status)}</span>`),e.imagePresent===!1&&o.push(`<span class="status status--warn">no image</span>`),e.verified!==`verified`&&o.push(`<span class="status status--unknown">brand string unmapped</span>`),`<li style="border:1px solid var(--line);border-radius:var(--r);padding:.7rem .8rem;background:#fbfaf7">
    <div style="display:flex;gap:.6rem;justify-content:space-between;flex-wrap:wrap;align-items:baseline">
      <span style="font-weight:600">${b(e.name)}</span>
      <span class="mono" style="color:var(--ink-3)">${b(e.brandRaw??`no brand`)} · ${e.netWeightG??`?`}g · ${b(e.form??`form unknown`)}</span>
    </div>
    <div style="display:flex;gap:1.2rem;flex-wrap:wrap;margin-top:.4rem;font-size:.84rem">${a.join(``)}</div>
    ${o.length?`<div style="display:flex;gap:.35rem;margin-top:.45rem;flex-wrap:wrap">${o.join(``)}</div>`:``}
  </li>`}function A(e){return e.map(e=>`<div class="rules__row">
        <dt>${b(e.label)}</dt>
        <dd>${b(e.detail)}</dd>
        <span class="rules__pts" style="color:${e.weight>0?`var(--ok)`:e.weight<0?`var(--stop)`:`var(--ink-3)`}">${e.weight>0?`+`:``}${e.weight}</span>
      </div>`).join(``)}function j(e,t,n){let r=m(e.id),i=C(e),s=a(r),u=f[t]?.status===`open`,d=i.resolved.eligible.map(e=>({p:e,savings:o(r,e,t),single:c(e,t)})),h=i.resolved.unknown,g=i.resolved.inactiveMatched,_=d.map(e=>e.savings).filter(e=>e!==null).sort((e,t)=>t-e)[0]??null,v=d.some(e=>l(e.p,t)),y=e=>{let t=e.map(e=>f[e]?.city??e);return t.length===1?t[0]:`${t.slice(0,-1).join(`, `)} and ${t[t.length-1]}`},T=[];T.push(`<span class="mono">Shoppable at <b>${b(f[t].city)}</b>: ${u?r.storeScope.length===0?`<span class="status status--warn">unpublished — treated as all stores, unconfirmed</span>`:`<span>honoured at ${b(y(r.storeScope))}${r.storeScopeOrigin===`derived`?` <span class="status status--signal">corrected locally</span>`:``}</span>`:`<span class="status status--stop">this location is not open yet</span>`}</span>`);let E=r.startsOn||r.endsOn?`${r.startsOn?`from ${b(r.startsOn)}`:`no start`} · ${r.endsOn?`to ${b(r.endsOn)}`:`no end`}${r.startsOn||r.endsOn?` <span class="status status--signal">corrected locally</span>`:``}`:`<span class="status status--warn">no date published anywhere</span>`;T.push(`<span class="mono">Runs: ${E}</span>`),T.push(S(e)?`<span class="mono">Terms: “${b(S(e))}”${p(e.id)===void 0?``:` <span class="status status--signal">corrected locally</span>`}</span>`:`<span class="mono">Terms: <span class="status status--warn">none published</span></span>`);let D=u?d.length>0?`<ul style="list-style:none;margin:.6rem 0 0;padding:0;display:grid;gap:.45rem">
           ${d.slice(0,5).map(e=>k(e.p,t,s)).join(``)}
         </ul>
         ${d.length>5?`<p class="mono" style="margin-top:.5rem;color:var(--ink-3)">+ ${d.length-5} more qualifying record(s) in the sample</p>`:``}`:`<p class="note note--warn" style="margin-top:.6rem"><span class="note__label">No confident match</span>
           Nothing in the sample resolves this offer without a human decision. The offer may still be real — the site simply does not say enough to look it up.</p>`:`<p class="note note--stop" style="margin-top:.6rem"><span class="note__label">Not shoppable</span>
         Menominee is marked “coming soon” by the company, so no offer should be presented as shoppable there.</p>`;return`<article class="card" id="deal-${e.id}" style="scroll-margin-top:120px">
    <div class="card__head">
      <div>
        <h3 style="font-size:1.05rem">${b(e.rawTitle)}</h3>
        <p class="mono" style="color:var(--ink-3);margin-top:.3rem">
          ${e.slug?`<a class="link" href="${b(e.sourceUrl)}" target="_blank" rel="noopener">source page ↗</a>`:`seen on the home page only`}
          · surface: ${e.surface===`both`?`home + specials index`:e.surface===`home`?`home page only`:`specials index only`}
          ${e.storePrefix?` · published prefix “${b(e.storePrefix)}”`:``}
        </p>
      </div>
      <div style="display:flex;gap:.4rem;flex-wrap:wrap;align-items:center">
        <span class="status status--solid ${w[i.verdict]}">${i.verdict}</span>
        ${s===null?`<span class="status status--unknown">no unit price derivable</span>`:`<span class="status status--neutral">${x(s)} / unit</span>`}
      </div>
    </div>
    <div class="card__body">
      <div class="keyline">${T.join(``)}</div>

      ${D}

      ${g.length?`<p class="note note--stop" style="margin-top:.6rem"><span class="note__label">Points at records that are not sellable</span>
               ${g.map(e=>b(e.name)).join(`; `)} — still matched by this live offer.</p>`:``}

      ${h.length&&u?`<p class="note" style="margin-top:.6rem"><span class="note__label">${h.length} uncertain match(es) held back</span>
               These qualify on brand or category but disagree on size, form or potency, or carry an unmapped brand string. They are listed in the reconciliation workspace rather than shown as eligible here.</p>`:``}

      ${u&&s!==null?_===null?`<p class="note" style="margin-top:.6rem"><span class="note__label">Saving</span>
                 Not shown. This store has no single-item price in the sample for the qualifying records, and a saving is not estimated.</p>`:`<p class="note ${v?`note--ok`:``}" style="margin-top:.6rem"><span class="note__label">Saving per unit${v?` · rests on a published price`:` · modelled price`}</span>
                 ${x(_)} per unit at ${b(f[t].city)}${v?`, computed from the $25.00 published on the Monroe product page`:` (modelled single-item price)`}.</p>`:``}

      <details class="disclosure" style="margin-top:.8rem" ${n?`open`:``}>
        <summary>Why this verdict — ${i.counts.pass} pass · ${i.counts.fail} fail · ${i.counts.unknown} unknown of ${i.counts.total}</summary>
        <div>
          <div class="tablewrap" style="margin-bottom:.8rem">
            <table style="min-width:520px">
              <thead><tr><th>Check</th><th>Question</th><th>Result</th><th>Detail</th></tr></thead>
              <tbody>
                ${i.checks.map(e=>`<tr>
                      <td class="mono">${e.id}</td>
                      <td style="font-size:.86rem">${b(e.label)}</td>
                      <td><span class="status ${e.status===`pass`?`status--ok`:e.status===`fail`?`status--stop`:`status--unknown`}">${e.status}</span></td>
                      <td style="font-size:.86rem">${b(e.detail)}</td>
                    </tr>`).join(``)}
              </tbody>
            </table>
          </div>
          <p class="mono" style="color:var(--ink-3);margin-bottom:.4rem">Scoring receipt for the first qualifying record</p>
          <dl class="rules">
            ${i.resolved.eligible.length?A(M(e.id,i.resolved.eligible[0].id)):`<div class="rules__row"><dt>No receipt</dt><dd>Nothing qualified, so there is no scoring to show.</dd><span></span></div>`}
          </dl>
        </div>
      </details>
    </div>
  </article>`}function M(t,n){let i=s.find(e=>e.id===t),a=m(t),o=e.find(e=>e.id===n);return r(i,a,o).reasons}function N(){let e=y(`[data-dc]`);if(!e)return;g();let t=E(),r=y(`[data-dc-results]`,e),o=y(`[data-dc-count]`,e),c=y(`[data-dc-store]`,e),l=y(`[data-dc-q]`,e),u=y(`[data-dc-sort]`,e),d=y(`[data-dc-resolvable]`,e);c.innerHTML=n.map(e=>`<option value="${e.id}" ${e.status===`coming-soon`?`disabled`:``}>${b(e.city)}${e.status===`coming-soon`?` (coming soon — not shoppable)`:``}</option>`).join(``);function p(){c.value=t.store,l.value=t.q,u.value=t.sort,d.checked=t.resolvableOnly;let n=Array.from(new Set(s.map(e=>m(e.id).categoryId).filter(e=>e!==null))),h=y(`[data-dc-cats]`,e);h.innerHTML=[{id:`all`,name:`All offers`},...n.map(e=>({id:e,name:i[e].name}))].map(e=>`<button class="chip" type="button" data-cat="${e.id}" aria-pressed="${t.cat===e.id}">${b(e.name)}</button>`).join(``),h.querySelectorAll(`[data-cat]`).forEach(e=>e.addEventListener(`click`,()=>{t.cat=e.dataset.cat,D(t),p()}));let g=s.filter(e=>O(e,m(e.id).categoryId,t));t.resolvableOnly&&(g=g.filter(e=>C(e).resolved.eligible.length>0)),t.sort===`title`&&(g=[...g].sort((e,t)=>e.rawTitle.localeCompare(t.rawTitle))),t.sort===`verdict`&&(g=[...g].sort((e,t)=>[`BLOCK`,`REVIEW`,`UNKNOWN`,`READY`].indexOf(C(e).verdict)-[`BLOCK`,`REVIEW`,`UNKNOWN`,`READY`].indexOf(C(t).verdict))),t.sort===`price`&&(g=[...g].sort((e,t)=>(a(m(e.id))??1e9)-(a(m(t.id))??1e9))),o.textContent=String(g.length);let _=f[t.store].status===`open`,v=y(`[data-dc-storenote]`,e);v.innerHTML=_?`Showing what resolves at <b>${b(f[t.store].name)}</b>. Prices appear only where this store has a price in the sample.`:`<span class="status status--stop">Coming soon</span> — this location is marked “coming soon”, so nothing is shown as shoppable.`,r.innerHTML=g.length?g.map(e=>j(e,t.store,!1)).join(``):`<p class="note"><span class="note__label">No offers match</span>
           Nothing in the published set matches that. Try a broader word, or clear the filters. This empty state is the honest one: the checker only searches offers that were actually observed.</p>`;let x=y(`[data-dc-state]`,e);x.textContent=`${g.length} of ${s.length} offers · store ${f[t.store].city} · ${t.cat===`all`?`all categories`:i[t.cat].name}${t.q?` · “${t.q}”`:``}`}c.addEventListener(`change`,()=>{t.store=c.value,D(t),p()}),u.addEventListener(`change`,()=>{t.sort=u.value,D(t),p()}),d.addEventListener(`change`,()=>{t.resolvableOnly=d.checked,D(t),p()});let h;l.addEventListener(`input`,()=>{window.clearTimeout(h),h=window.setTimeout(()=>{t.q=l.value,D(t),p()},180)}),e.querySelectorAll(`[data-dc-try]`).forEach(e=>e.addEventListener(`click`,()=>{t.q=e.dataset.dcTry,D(t),p()})),y(`[data-dc-reset]`,e)?.addEventListener(`click`,()=>{t={...T},D(t),p()}),window.addEventListener(v,p),window.addEventListener(`storage`,p),p()}N();