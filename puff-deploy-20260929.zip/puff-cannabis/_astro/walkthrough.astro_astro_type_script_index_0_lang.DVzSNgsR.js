import{n as e,r as t}from"./sources.Dotfl-Ce.js";import{C as n,_ as r,b as i,g as a,i as o,o as s,p as c,t as l,x as u}from"./checks.qF_L4lOF.js";import{a as d,n as f,o as p,r as m,t as h}from"./metrics.SB0Y0EwK.js";var g=(e,t=document)=>t.querySelector(e),_=(e,t=document)=>Array.from(t.querySelectorAll(e)),v=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`),y=e=>`$${e.toFixed(2)}`,b=0;function x(g){let _=h();if(g===`profile`)return`<div class="grid grid--3">
      ${[{l:`Webmaster / E-Commerce Specialist`,n:`Warren, Michigan`},{l:`Storefronts run`,n:`Shopify, WordPress, WooCommerce`},{l:`Catalog scale`,n:`a 14,000-item migration`},{l:`Promotion QA`,n:`sixteen checks before a menu`},{l:`Cannabis reviews`,n:`menus, stores and pages reconciled`},{l:`Languages`,n:`English and Arabic`}].map(e=>`<div class="card"><div class="card__body"><strong style="font-size:.95rem">${v(e.l)}</strong><p class="mono" style="color:var(--ink-3);margin-top:.3rem">${v(e.n)}</p></div></div>`).join(``)}
    </div>`;if(g===`observed`)return`<div class="tablewrap"><table><thead><tr><th>Layer</th><th>What is already there</th></tr></thead>
      <tbody>${[[`Storefront`,`Native and first-party, on the company's own domain`],[`Product URLs`,`≈29,000, each scoped to one store`],[`Published per product`,`brand · size · price · availability, in structured data`],[`Categories`,`${c.length} with ${c[0].subcategories.length} sub-categories on Flower alone`],[`Effect labels`,`${r.length}, already working`],[`Locations`,`${n.filter(e=>e.status===`open`).length} open, 1 coming soon`],[`Deal cards on the home page`,String(_.dealCards)]].map(([e,t])=>`<tr><td style="font-weight:600;width:34%">${v(e)}</td><td>${v(t)}</td></tr>`).join(``)}</tbody></table></div>`;if(g===`gap`)return`<div class="grid grid--2">
      <div class="card"><div class="card__body">
        <p class="mono" style="color:var(--ink-3)">THE PROMOTION LAYER</p>
        <ul style="margin:.6rem 0 0;padding-left:1.1rem;display:grid;gap:.35rem;font-size:.92rem">
          <li>${_.dealCards} cards across two surfaces</li>
          <li>${_.onBothSurfaces} of ${_.uniqueDeals} offers appear on both</li>
          <li>${_.withStoreScope} carry a location scope</li>
          <li>${_.withDates} carry a date</li>
          <li>0 list the products they cover</li>
        </ul>
      </div></div>
      <div class="card"><div class="card__body">
        <p class="mono" style="color:var(--ink-3)">THE PRODUCT LAYER</p>
        <ul style="margin:.6rem 0 0;padding-left:1.1rem;display:grid;gap:.35rem;font-size:.92rem">
          <li>≈29,000 store-scoped product URLs</li>
          <li>price, size, brand and stock published per store</li>
          <li>a working category, brand, effect and strain taxonomy</li>
          <li>inventory re-stamped the day before retrieval</li>
        </ul>
      </div></div>
    </div>
    <p class="note note--signal" style="margin-top:1rem"><span class="note__label">Between them</span>
      The company's own deal page says: <em>“*Website cart may not reflect the bundled price but it will be adjusted at time of payment.”</em>
      The gap is not data. It is a join, and a set of fields.</p>`;if(g===`resolver`){let e=a.find(e=>e.rawTitle.startsWith(`2/$40 Mitten`)),t=u[e.id],n=o(t),r=i.filter(e=>e.brandId===`mitten-extracts`&&e.netWeightG===2).find(e=>e.menuPriceOrigin===`public-observation`),c=s(r,`monroe`);return`<div class="card">
      <div class="card__head"><strong>${v(e.rawTitle)}</strong><span class="status status--neutral">at Monroe</span></div>
      <div class="card__body">
        <div class="grid grid--3">
          <div><p class="mono" style="color:var(--ink-3)">DEAL UNIT PRICE (DERIVED)</p><p style="font-size:1.5rem;font-weight:800">${y(n)}</p></div>
          <div><p class="mono" style="color:var(--ink-3)">PUBLISHED SINGLE PRICE</p><p style="font-size:1.5rem;font-weight:800">${y(c)}</p><p class="mono" style="color:var(--ok)">observed on the Monroe product page</p></div>
          <div><p class="mono" style="color:var(--ink-3)">SAVING PER UNIT</p><p style="font-size:1.5rem;font-weight:800;color:var(--signal-ink)">${y(c-n)}</p></div>
        </div>
        <p class="mono" style="margin-top:1rem;color:var(--ink-3)">
          Neither the deal card, the deal page nor the product page states this comparison. The two figures it needs are both published, on two different pages, about the same store.
        </p>
      </div>
    </div>`}if(g===`checks`){let e=a.map(e=>l(e,u[e.id],i).verdict),t=t=>e.filter(e=>e===t).length;return`<div class="grid grid--4">
      ${[{l:`BLOCK`,v:t(`BLOCK`),n:`blocking check failed`,t:`status--stop`},{l:`REVIEW`,v:t(`REVIEW`),n:`something contradicts`,t:`status--warn`},{l:`UNKNOWN`,v:t(`UNKNOWN`),n:`nothing provable either`,t:`status--unknown`},{l:`READY`,v:t(`READY`),n:`every check passes`,t:`status--ok`}].map(e=>`<div class="kpi"><span class="kpi__label">${e.l}</span><p class="kpi__value" style="color:var(--${e.t.replace(`status--`,``)})">${e.v}</p><p class="kpi__note">${e.n}</p></div>`).join(``)}
    </div>
    <p class="mono" style="margin-top:.8rem;color:var(--ink-3)">
      ${_.uniqueDeals} offers × 14 checks = ${_.uniqueDeals*14} checks. No offer can reach READY today, because two fields are missing from all ${_.uniqueDeals}.
    </p>`}if(g===`measure`){let e=d(p),t=f(p),n=e[0].value,r=e=>`<div>
              <div class="keyline" style="justify-content:space-between"><span>${v(e.label)}</span><span class="mono">${e.value} <span style="color:var(--ink-3)">of ${e.denominator}</span></span></div>
              <div class="meter"><div class="meter__fill bar-grow" style="width:${Math.round(e.value/n*100)}%"></div></div>
            </div>`;return`<div class="card"><div class="card__body">
      <p class="mono" style="color:var(--ink-3)">MODELLED · ${p.length} sessions · population funnel</p>
      <div style="display:grid;gap:.5rem;margin-top:.8rem">${e.map(r).join(``)}</div>
      <p class="mono" style="color:var(--ink-3);margin-top:1rem">MODELLED · deal branch, among sessions that saw a deal</p>
      <div style="display:grid;gap:.5rem;margin-top:.6rem">${t.map(r).join(``)}</div>
      <p class="mono" style="margin-top:.8rem;color:var(--ink-3)">
        Modelled, not measured. Two series because they have two different bases — running them as one funnel is how a stage ends up larger than the stage before it. Device split: ${m(p).map(e=>`${e.device} ${e.count}`).join(` · `)}.
      </p>
    </div></div>`}return g===`labels`?`<div class="card"><div class="card__body">
      <ul style="list-style:none;margin:0;padding:0;display:grid;gap:.7rem">
        ${[`public-observation`,`public-statement`,`bounded-check`,`modeled`,`requires-internal`].map(n=>`<li><span class="status ${n===`public-observation`?`status--ok`:n===`public-statement`?`status--signal`:n===`bounded-check`?`status--warn`:n===`modeled`?`status--unknown`:`status--stop`}">${e[n]}</span><p style="margin-top:.35rem;font-size:.92rem">${v(t[n])}</p></li>`).join(``)}
      </ul>
    </div></div>`:``}function S(){if(!g(`[data-wt]`))return;let e=_(`[data-wt-scene]`);if(e.length===0)return;let t=[`profile`,`observed`,`gap`,`resolver`,`checks`,`measure`,`labels`];e.forEach((e,n)=>{let r=e.querySelector(`.wt-figure`);r&&(r.innerHTML=x(t[n]??``))});let n=g(`[data-wt-bar]`),r=g(`[data-wt-pct]`),i=g(`[data-wt-pos]`),a=_(`[data-wt-go]`);function o(t,o=!0){b=Math.max(0,Math.min(e.length-1,t)),e.forEach((e,t)=>{e.hidden=t!==b});let s=Math.round((b+1)/e.length*100);n&&(n.style.width=`${s}%`),r&&(r.textContent=`${s}%`),i&&(i.textContent=`Scene ${b+1} of ${e.length}`),a.forEach((e,t)=>e.setAttribute(`aria-current`,String(t===b))),_(`[data-wt-prev]`).forEach(e=>e.disabled=b===0),_(`[data-wt-next]`).forEach(t=>t.disabled=b===e.length-1),o&&location.hash!==`#scene-${b+1}`&&history.replaceState(null,``,`#scene-${b+1}`),document.getElementById(`wt-h-${String(b+1).padStart(2,`0`)}`)?.scrollIntoView({block:`start`,behavior:`auto`})}_(`[data-wt-go]`).forEach(e=>e.addEventListener(`click`,()=>o(Number(e.dataset.wtGo)))),_(`[data-wt-prev]`).forEach(e=>e.addEventListener(`click`,()=>o(b-1))),_(`[data-wt-next]`).forEach(e=>e.addEventListener(`click`,()=>o(b+1))),_(`[data-wt-restart]`).forEach(e=>e.addEventListener(`click`,()=>o(0))),document.addEventListener(`keydown`,e=>{e.target instanceof HTMLInputElement||e.target instanceof HTMLSelectElement||(e.key===`ArrowRight`&&o(b+1),e.key===`ArrowLeft`&&o(b-1))});let s=()=>{let e=Number((location.hash.match(/^#scene-(\d+)$/)??[])[1]);return Number.isFinite(e)&&e>0?e-1:0};window.addEventListener(`hashchange`,()=>{let e=s();e!==b&&o(e,!1)}),o(s(),!1)}S();