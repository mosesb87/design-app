import{C as e,S as t,a as n,b as r,d as i,g as a,i as o,l as s,m as c,o as l,s as u,t as d,u as f}from"./checks.qF_L4lOF.js";import{a as p,i as m,n as h,o as g,r as _,t as v}from"./store.Dju5ol6d.js";var y=(e,t=document)=>t.querySelector(e),b=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`),x=e=>`$${e.toFixed(2)}`,S=e=>{let t=p(e.id);return t===void 0?e.exclusionRaw:t??null},C=e=>d(e,m(e.id),r,{terms:S(e)}),w={READY:`status--ok`,REVIEW:`status--warn`,BLOCK:`status--stop`,UNKNOWN:`status--unknown`},T={store:`monroe`,q:``,cat:`all`,resolvableOnly:!1,sort:`title`};function E(){let e=new URLSearchParams(location.search),n=e.get(`store`);return{store:n&&t[n]?n:T.store,q:e.get(`q`)??``,cat:e.get(`cat`)??`all`,resolvableOnly:e.get(`resolvable`)===`1`,sort:e.get(`sort`)??`title`}}function D(e){let t=new URLSearchParams;e.store!==T.store&&t.set(`store`,e.store),e.q&&t.set(`q`,e.q),e.cat!==`all`&&t.set(`cat`,e.cat),e.resolvableOnly&&t.set(`resolvable`,`1`),e.sort!==T.sort&&t.set(`sort`,e.sort);let n=h(_());n&&t.set(`fix`,n);let r=t.toString();history.replaceState(null,``,r?`?${r}`:location.pathname)}function O(e,t,r){if(r.cat!==`all`&&t!==r.cat)return!1;let a=r.q.trim().toLowerCase();if(!a)return!0;let o=m(e.id),s=[e.rawTitle,e.exclusionRaw??``,e.storePrefix??``,o?.productHint??``,...(o?.brandIds??[]).map(e=>i[e]?.name??e)].join(` `).toLowerCase();if(s.includes(a))return!0;let c=n(a);return c.length>0&&n(s).includes(c)}function k(e,t,n){let r=l(e,t),i=u(e,t),a=[];n!==null&&a.push(`<span class="mono"><strong>${x(n)}</strong> each under this deal <span style="color:var(--ink-3)">(derived from the published bundle)</span></span>`),r===null?a.push(`<span class="mono" style="color:var(--ink-3)">no single-item price in the sample for this store</span>`):a.push(`<span class="mono">single item ${x(r)} <span class="status ${i?`status--ok`:`status--unknown`}">${i?`observed at this store`:`modelled`}</span></span>`);let o=[];return e.status!==`active`&&o.push(`<span class="status status--stop">${b(e.status)}</span>`),e.imagePresent===!1&&o.push(`<span class="status status--warn">no image</span>`),e.verified!==`verified`&&o.push(`<span class="status status--unknown">brand string unmapped</span>`),`<li style="border:1px solid var(--line);border-radius:var(--r);padding:.7rem .8rem;background:#fbfaf7">
    <div style="display:flex;gap:.6rem;justify-content:space-between;flex-wrap:wrap;align-items:baseline">
      <span style="font-weight:600">${b(e.name)}</span>
      <span class="mono" style="color:var(--ink-3)">${b(e.brandRaw??`no brand`)} · ${e.netWeightG??`?`}g · ${b(e.form??`form unknown`)}</span>
    </div>
    <div style="display:flex;gap:1.2rem;flex-wrap:wrap;margin-top:.4rem;font-size:.84rem">${a.join(``)}</div>
    ${o.length?`<div style="display:flex;gap:.35rem;margin-top:.45rem;flex-wrap:wrap">${o.join(``)}</div>`:``}
  </li>`}function A(e){return e.map(e=>`<div class="rules__row">
        <dt>${b(e.label)}</dt>
        <dd>${b(e.detail)}</dd>
        <span class="rules__pts" style="color:${e.weight>0?`var(--ok)`:e.weight<0?`var(--stop)`:`var(--ink-3)`}">${e.weight>0?`+`:``}${e.weight}</span>
      </div>`).join(``)}function j(e,n,r){let i=m(e.id),a=C(e),s=o(i),c=t[n]?.status===`open`,d=a.resolved.eligible.map(e=>({p:e,savings:f(i,e,n),single:l(e,n)})),h=a.resolved.unknown,g=a.resolved.inactiveMatched,_=d.map(e=>e.savings).filter(e=>e!==null).sort((e,t)=>t-e)[0]??null,v=d.some(e=>u(e.p,n)),y=e=>{let n=e.map(e=>t[e]?.city??e);return n.length===1?n[0]:`${n.slice(0,-1).join(`, `)} and ${n[n.length-1]}`},T=[];T.push(`<span class="mono">Shoppable at <b>${b(t[n].city)}</b>: ${c?i.storeScope.length===0?`<span class="status status--warn">unpublished — treated as all stores, unconfirmed</span>`:`<span>honoured at ${b(y(i.storeScope))}${i.storeScopeOrigin===`derived`?` <span class="status status--signal">corrected locally</span>`:``}</span>`:`<span class="status status--stop">this location is not open yet</span>`}</span>`);let E=i.startsOn||i.endsOn?`${i.startsOn?`from ${b(i.startsOn)}`:`no start`} · ${i.endsOn?`to ${b(i.endsOn)}`:`no end`}${i.startsOn||i.endsOn?` <span class="status status--signal">corrected locally</span>`:``}`:`<span class="status status--warn">no date published anywhere</span>`;T.push(`<span class="mono">Runs: ${E}</span>`),T.push(S(e)?`<span class="mono">Terms: “${b(S(e))}”${p(e.id)===void 0?``:` <span class="status status--signal">corrected locally</span>`}</span>`:`<span class="mono">Terms: <span class="status status--warn">none published</span></span>`);let D=c?d.length>0?`<ul style="list-style:none;margin:.6rem 0 0;padding:0;display:grid;gap:.45rem">
           ${d.slice(0,5).map(e=>k(e.p,n,s)).join(``)}
         </ul>
         ${d.length>5?`<p class="mono" style="margin-top:.5rem;color:var(--ink-3)">+ ${d.length-5} more qualifying record(s) in the sample</p>`:``}`:`<p class="note note--warn" style="margin-top:.6rem"><span class="note__label">No confident match</span>
           Nothing in the sample resolves this offer without a human decision. The offer may still be real — the site simply does not say enough to look it up.</p>`:`<p class="note note--stop" style="margin-top:.6rem"><span class="note__label">Not shoppable</span>
         Menominee is marked “coming soon” by the company, so no offer should be presented as shoppable there.</p>`;return`<article class="card" id="deal-${e.id}" style="scroll-margin-top:120px">
    <div class="card__head">
      <div>
        <h3 style="font-size:1.05rem">${b(e.rawTitle)}</h3>
        <p class="mono" style="color:var(--ink-3);margin-top:.3rem">
          ${e.slug?`<a class="link" href="${b(e.sourceUrl)}" target="_blank" rel="noopener">source page ↗</a>`:`seen on the home page only`}
          · surface: ${e.surface===`both`?`home + specials index`:e.surface===`home`?`home page only`:`specials index only`}
          ${e.storePrefix?` · published prefix “${b(e.storePrefix)}”`:``}
        </p>
      </div>
      <div style="display:flex;gap:.4rem;flex-wrap:wrap;align-items:center">
        <span class="status status--solid ${w[a.verdict]}">${a.verdict}</span>
        ${s===null?`<span class="status status--unknown">no unit price derivable</span>`:`<span class="status status--neutral">${x(s)} / unit</span>`}
      </div>
    </div>
    <div class="card__body">
      <div class="keyline">${T.join(``)}</div>

      ${D}

      ${g.length?`<p class="note note--stop" style="margin-top:.6rem"><span class="note__label">Points at records that are not sellable</span>
               ${g.map(e=>b(e.name)).join(`; `)} — still matched by this live offer.</p>`:``}

      ${h.length&&c?`<p class="note" style="margin-top:.6rem"><span class="note__label">${h.length} uncertain match(es) held back</span>
               These qualify on brand or category but disagree on size, form or potency, or carry an unmapped brand string. They are listed in the reconciliation workspace rather than shown as eligible here.</p>`:``}

      ${c&&s!==null?_===null?`<p class="note" style="margin-top:.6rem"><span class="note__label">Saving</span>
                 Not shown. This store has no single-item price in the sample for the qualifying records, and a saving is not estimated.</p>`:`<p class="note ${v?`note--ok`:``}" style="margin-top:.6rem"><span class="note__label">Saving per unit${v?` · rests on a published price`:` · modelled price`}</span>
                 ${x(_)} per unit at ${b(t[n].city)}${v?`, computed from the $25.00 published on the Monroe product page`:` (modelled single-item price)`}.</p>`:``}

      <details class="disclosure" style="margin-top:.8rem" ${r?`open`:``}>
        <summary>Why this verdict — ${a.counts.pass} pass · ${a.counts.fail} fail · ${a.counts.unknown} unknown of ${a.counts.total}</summary>
        <div>
          <div class="tablewrap" style="margin-bottom:.8rem">
            <table style="min-width:520px">
              <thead><tr><th>Check</th><th>Question</th><th>Result</th><th>Detail</th></tr></thead>
              <tbody>
                ${a.checks.map(e=>`<tr>
                      <td class="mono">${e.id}</td>
                      <td style="font-size:.86rem">${b(e.label)}</td>
                      <td><span class="status ${e.status===`pass`?`status--ok`:e.status===`fail`?`status--stop`:`status--unknown`}">${e.status}</span></td>
                      <td style="font-size:.86rem">${b(e.detail)}</td>
                    </tr>`).join(``)}
              </tbody>
            </table>
          </div>
          <p class="mono" style="color:var(--ink-3);margin-bottom:.4rem">Scoring receipt for the first qualifying record</p>
          <dl class="rules">
            ${a.resolved.eligible.length?A(M(e.id,a.resolved.eligible[0].id)):`<div class="rules__row"><dt>No receipt</dt><dd>Nothing qualified, so there is no scoring to show.</dd><span></span></div>`}
          </dl>
        </div>
      </details>
    </div>
  </article>`}function M(e,t){let n=a.find(t=>t.id===e),i=m(e),o=r.find(e=>e.id===t);return s(n,i,o).reasons}function N(){let n=y(`[data-dc]`);if(!n)return;g();let r=E(),i=y(`[data-dc-results]`,n),s=y(`[data-dc-count]`,n),l=y(`[data-dc-store]`,n),u=y(`[data-dc-q]`,n),d=y(`[data-dc-sort]`,n),f=y(`[data-dc-resolvable]`,n);l.innerHTML=e.map(e=>`<option value="${e.id}" ${e.status===`coming-soon`?`disabled`:``}>${b(e.city)}${e.status===`coming-soon`?` (coming soon — not shoppable)`:``}</option>`).join(``);function p(){l.value=r.store,u.value=r.q,d.value=r.sort,f.checked=r.resolvableOnly;let e=Array.from(new Set(a.map(e=>m(e.id).categoryId).filter(e=>e!==null))),h=y(`[data-dc-cats]`,n);h.innerHTML=[{id:`all`,name:`All offers`},...e.map(e=>({id:e,name:c[e].name}))].map(e=>`<button class="chip" type="button" data-cat="${e.id}" aria-pressed="${r.cat===e.id}">${b(e.name)}</button>`).join(``),h.querySelectorAll(`[data-cat]`).forEach(e=>e.addEventListener(`click`,()=>{r.cat=e.dataset.cat,D(r),p()}));let g=a.filter(e=>O(e,m(e.id).categoryId,r));r.resolvableOnly&&(g=g.filter(e=>C(e).resolved.eligible.length>0)),r.sort===`title`&&(g=[...g].sort((e,t)=>e.rawTitle.localeCompare(t.rawTitle))),r.sort===`verdict`&&(g=[...g].sort((e,t)=>[`BLOCK`,`REVIEW`,`UNKNOWN`,`READY`].indexOf(C(e).verdict)-[`BLOCK`,`REVIEW`,`UNKNOWN`,`READY`].indexOf(C(t).verdict))),r.sort===`price`&&(g=[...g].sort((e,t)=>(o(m(e.id))??1e9)-(o(m(t.id))??1e9))),s.textContent=String(g.length);let _=t[r.store].status===`open`,v=y(`[data-dc-storenote]`,n);v.innerHTML=_?`Showing what resolves at <b>${b(t[r.store].name)}</b>. Prices appear only where this store has a price in the sample.`:`<span class="status status--stop">Coming soon</span> — this location is marked “coming soon”, so nothing is shown as shoppable.`,i.innerHTML=g.length?g.map(e=>j(e,r.store,!1)).join(``):`<p class="note"><span class="note__label">No offers match</span>
           Nothing in the published set matches that. Try a broader word, or clear the filters. This empty state is the honest one: the checker only searches offers that were actually observed.</p>`;let x=y(`[data-dc-state]`,n);x.textContent=`${g.length} of ${a.length} offers · store ${t[r.store].city} · ${r.cat===`all`?`all categories`:c[r.cat].name}${r.q?` · “${r.q}”`:``}`}l.addEventListener(`change`,()=>{r.store=l.value,D(r),p()}),d.addEventListener(`change`,()=>{r.sort=d.value,D(r),p()}),f.addEventListener(`change`,()=>{r.resolvableOnly=f.checked,D(r),p()});let h;u.addEventListener(`input`,()=>{window.clearTimeout(h),h=window.setTimeout(()=>{r.q=u.value,D(r),p()},180)}),n.querySelectorAll(`[data-dc-try]`).forEach(e=>e.addEventListener(`click`,()=>{r.q=e.dataset.dcTry,D(r),p()})),y(`[data-dc-reset]`,n)?.addEventListener(`click`,()=>{r={...T},D(r),p()}),window.addEventListener(v,p),window.addEventListener(`storage`,p),p()}N();