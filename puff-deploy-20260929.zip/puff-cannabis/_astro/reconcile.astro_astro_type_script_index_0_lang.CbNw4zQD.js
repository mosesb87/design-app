import{C as e,S as t,b as n,g as r,i,m as a,n as o,o as s,r as c,t as l,v as u}from"./checks.qF_L4lOF.js";import{a as d,c as f,d as p,i as m,l as h,o as g,s as _,t as v,u as y}from"./store.Dju5ol6d.js";var b=`/puff-cannabis/`,x=b.endsWith(`/`)?b.slice(0,-1):b;function S(e=``){let t=e.replace(/^\/+/,``);return t===``?`${x}/`:`${x}/${t}`}var C=(e,t=document)=>t.querySelector(e),w=(e,t=document)=>Array.from(t.querySelectorAll(e)),T=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`).replace(/>/g,`&gt;`).replace(/"/g,`&quot;`),E=e=>`$${e.toFixed(2)}`,D={READY:`status--ok`,REVIEW:`status--warn`,BLOCK:`status--stop`,UNKNOWN:`status--unknown`},O=[`BLOCK`,`REVIEW`,`UNKNOWN`,`READY`],k=e.filter(e=>e.status===`open`),A=e=>{let t=d(e.id);return t===void 0?e.exclusionRaw:t??null},j=e=>l(e,m(e.id),n,{terms:A(e)}),M=[u,`Exclusions apply. Limited time offer.`,`Exclusions apply.`],N=null,P=`all`,F=`all`;function I(){let e=C(`[data-rc]`);if(!e)return;let t=r.map(e=>({d:e,a:j(e)})).filter(e=>P===`all`||e.a.verdict===P).filter(e=>F===`all`||m(e.d.id).categoryId===F).sort((e,t)=>O.indexOf(e.a.verdict)-O.indexOf(t.a.verdict)||e.d.rawTitle.localeCompare(t.d.rawTitle)),n=r.map(e=>j(e)),o=e=>n.filter(t=>t.verdict===e).length,s=C(`[data-rc-kpis]`,e);s&&(s.innerHTML=[{l:`Offers assessed`,v:String(n.length),n:`${n.reduce((e,t)=>e+t.counts.total,0)} checks run`},{l:`Blocking failures`,v:String(o(`BLOCK`)),n:`Do not launch as written`,tone:`stop`},{l:`Contradictions`,v:String(o(`REVIEW`)),n:`Something disagrees with something else`,tone:`warn`},{l:`Unconfirmed`,v:String(o(`UNKNOWN`)),n:`Nothing wrong, nothing provable`,tone:`unknown`},{l:`Ready as published`,v:String(o(`READY`)),n:`Every check passes`,tone:`ok`},{l:`Local corrections`,v:String(_()),n:`Saved in this browser only`,tone:`signal`}].map(e=>`<div class="kpi">
          <span class="kpi__label">${T(e.l)}</span>
          <p class="kpi__value">${T(e.v)}</p>
          <p class="kpi__note">${T(e.n)}</p>
        </div>`).join(``));let c=C(`[data-rc-rows]`,e);c&&(c.innerHTML=t.length?t.map(({d:e,a:t})=>{let n=m(e.id),r=i(n),o=d(e.id)!==void 0||n.storeScopeOrigin===`derived`;return`<tr data-rc-row="${e.id}" ${N===e.id?`style="background:#fdf3ef"`:``}>
              <td><span class="status status--solid ${D[t.verdict]}">${t.verdict}</span></td>
              <td style="min-width:230px">
                <button class="link" type="button" data-rc-open="${e.id}" style="background:none;border:0;padding:0;cursor:pointer;text-align:left;font:inherit">
                  ${T(e.rawTitle)}
                </button>
                <div class="mono" style="color:var(--ink-3);margin-top:.2rem">
                  ${e.surface===`both`?`home + index`:e.surface===`home`?`home only`:`index only`}
                  ${o?` · <span style="color:var(--signal-ink)">corrected locally</span>`:``}
                </div>
              </td>
              <td class="mono">${n.categoryId?T(a[n.categoryId].name):`—`}</td>
              <td class="num">${r===null?`—`:E(r)}</td>
              <td class="num">${t.resolved.eligible.length}</td>
              <td class="num">${t.resolved.unknown.length}</td>
              <td class="num" style="color:${t.counts.fail?`var(--stop)`:`var(--ink-3)`}">${t.counts.fail}</td>
              <td class="num">${t.counts.unknown}</td>
            </tr>`}).join(``):`<tr><td colspan="8" style="padding:1.2rem">Nothing matches those filters. <button class="link" type="button" data-rc-resetfilters style="background:none;border:0;font:inherit;cursor:pointer">Clear them</button>.</td></tr>`);let l=C(`[data-rc-detail]`,e);l&&(l.innerHTML=N?R(r.find(e=>e.id===N)):L()),z(e)}function L(){return`<div class="card"><div class="card__body">
    <p class="section-label">Nothing selected</p>
    <p>Choose an offer from the table to see its proposed record, the fourteen checks, and the products it resolves to. Nothing is preselected, because the point is that you choose what to inspect.</p>
  </div></div>`}function R(e){let n=j(e),r=m(e.id),a=i(r),l=c(r),u=d(e.id)!==void 0||r.storeScopeOrigin===`derived`,f=n.checks.map(e=>`<tr>
        <td class="mono">${e.id}</td>
        <td><span class="status ${e.status===`pass`?`status--ok`:e.status===`fail`?`status--stop`:`status--unknown`}">${e.status}</span></td>
        <td class="mono" style="color:var(--ink-3)">${e.severity}</td>
        <td style="font-size:.86rem"><strong>${T(e.question)}</strong><br />${T(e.detail)}${e.needs===`—`?``:`<br /><span class="mono" style="color:var(--ink-3)">Needs: ${T(e.needs)}</span>`}</td>
      </tr>`).join(``),h=(e,t,n)=>e.length?`<p class="mono" style="margin:.8rem 0 .35rem;color:var(--ink-3)">${t} · ${e.length}</p>
         <ul style="list-style:none;margin:0;padding:0;display:grid;gap:.3rem">
           ${e.map(e=>{let t=s(e,`monroe`);return`<li style="border:1px solid var(--line);border-radius:2px;padding:.45rem .6rem;font-size:.86rem;display:flex;gap:.6rem;justify-content:space-between;flex-wrap:wrap">
                 <span>${T(e.name)}</span>
                 <span class="mono" style="color:var(--ink-3)">${T(e.brandRaw??`—`)} · ${e.netWeightG??`?`}g · ${e.status===`active`?``:`<span class="status status--stop">${e.status}</span> `}${e.imagePresent===!1?`<span class="status status--warn">no image</span> `:``}${t===null?``:`· ${E(t)} at Monroe`}</span>
               </li>`}).join(``)}
         </ul>
         <p class="mono" style="color:var(--ink-3);margin-top:.3rem">${n}</p>`:``;return`<div class="card">
    <div class="card__head">
      <div>
        <h3 style="font-size:1.08rem">${T(e.rawTitle)}</h3>
        <p class="mono" style="color:var(--ink-3);margin-top:.25rem">
          ${e.sourceUrl?`<a class="link" href="${T(e.sourceUrl)}" target="_blank" rel="noopener">source ↗</a>`:`home page`} · retrieved ${e.accessedOn}
        </p>
      </div>
      <div style="display:flex;gap:.4rem;flex-wrap:wrap">
        <span class="status status--solid ${D[n.verdict]}">${n.verdict}</span>
        ${u?`<span class="status status--signal">Corrected locally</span>`:``}
      </div>
    </div>
    <div class="card__body">
      <p class="note ${n.verdict===`READY`?`note--ok`:n.verdict===`BLOCK`?`note--stop`:`note--warn`}">
        <span class="note__label">What this verdict means</span>${T(o[n.verdict])}
      </p>

      <p class="section-label" style="margin-top:1.2rem">The proposed record</p>
      <dl class="rules">
        <div class="rules__row"><dt>Offer type</dt><dd>${T(r.kind)}${r.buyQty?` · ${r.buyQty} for ${E(r.bundlePriceUsd??0)}`:``}${r.percentOff?` · ${r.percentOff}% off`:``}</dd><span></span></div>
        <div class="rules__row"><dt>Brands</dt><dd>${r.brandIds.length?T(r.brandIds.join(`, `)):`none named — eligibility is category-wide`}</dd><span></span></div>
        <div class="rules__row"><dt>Size</dt><dd>${r.netWeightG===null?`not stated`:`${r.netWeightG}g`}${l===null?``:` · bundle totals ${l}g`}</dd><span></span></div>
        <div class="rules__row"><dt>Derived unit price</dt><dd>${a===null?`not derivable from what is published`:`${E(a)} — derived from the published bundle price, not a menu price`}</dd><span></span></div>
        ${r.parseNotes.length?r.parseNotes.map(e=>`<div class="rules__row"><dt>Parse note</dt><dd>${T(e)}</dd><span></span></div>`).join(``):``}
      </dl>

      <p class="section-label" style="margin-top:1.4rem">Correct it locally</p>
      <form data-rc-form style="display:grid;gap:.9rem">
        <fieldset style="border:1px solid var(--line);border-radius:2px;padding:.8rem;margin:0">
          <legend class="mono" style="padding:0 .4rem;color:var(--ink-3)">Location scope</legend>
          <div style="display:flex;flex-wrap:wrap;gap:.4rem">
            ${k.map(e=>`<label class="chip" style="${r.storeScope.includes(e.id)?`background:var(--ink);color:#fff;border-color:var(--ink)`:``}">
                <input type="checkbox" name="storeScope" value="${e.id}" ${r.storeScope.includes(e.id)?`checked`:``} style="width:auto;accent-color:currentColor" />
                ${T(e.city)}
              </label>`).join(``)}
          </div>
          <p class="mono" style="color:var(--ink-3);margin-top:.55rem">
            Currently ${r.storeScope.length===0?`<strong>unpublished</strong> — the card says nothing, so the tool can only assume company-wide`:`scoped to ${T(r.storeScope.map(e=>t[e].city).join(`, `))}`}. Menominee is excluded because the company marks it coming soon.
          </p>
        </fieldset>

        <div style="display:grid;gap:.9rem;grid-template-columns:repeat(auto-fit,minmax(190px,1fr))">
          <div class="field"><label for="rc-start">Starts</label><input id="rc-start" type="date" name="startsOn" value="${r.startsOn??``}" /></div>
          <div class="field"><label for="rc-end">Ends</label><input id="rc-end" type="date" name="endsOn" value="${r.endsOn??``}" /></div>
          <div class="field"><label for="rc-terms">Terms sentence</label>
            <select id="rc-terms" name="terms">
              <option value="__keep" ${d(e.id)===void 0?`selected`:``}>Keep as published (${A(e)?`present`:`none`})</option>
              ${M.map(t=>`<option value="${T(t)}" ${d(e.id)===t?`selected`:``}>${T(t)}</option>`).join(``)}
              <option value="__none" ${d(e.id)===null?`selected`:``}>None — leave it empty</option>
            </select>
          </div>
        </div>

        <div style="display:flex;gap:.5rem;flex-wrap:wrap">
          <button class="btn btn--signal" type="submit">Save correction</button>
          <button class="btn btn--ghost" type="button" data-rc-reset="${e.id}">Reset this offer</button>
          <a class="btn btn--ghost" href="${p(`${S(`deal-check/`)}?q=${encodeURIComponent(e.rawTitle.split(` `).slice(0,2).join(` `))}`)}">See it in the deal checker →</a>
        </div>
        <p class="mono" style="color:var(--ink-3)">
          Saves in this browser only. Nothing is sent anywhere and Puff's site is untouched. The
          correction is read by the deal checker on the next page you open.
        </p>
      </form>

      <p class="section-label" style="margin-top:1.6rem">The fourteen checks</p>
      <div class="tablewrap">
        <table style="min-width:620px">
          <thead><tr><th>ID</th><th>Result</th><th>Severity</th><th>Check</th></tr></thead>
          <tbody>${f}</tbody>
        </table>
      </div>

      <p class="section-label" style="margin-top:1.6rem">What this resolves to</p>
      ${h(n.resolved.eligible,`Certain matches`,`Ranked by the published weights. Prices shown are the store's own where the sample has one.`)}
      ${h(n.resolved.unknown,`Uncertain matches — held back`,`These qualify on brand or category but disagree on size, form or potency, or carry an unmapped brand string. They are not shown to a shopper as eligible; they are queued for a person.`)}
      ${h(n.resolved.inactiveMatched,`Matched but not sellable`,`A live offer pointing at a record that is no longer active. This is the failure that survives longest, because nothing checks it.`)}
      ${n.resolved.eligible.length===0&&n.resolved.unknown.length===0?`<p class="note note--warn">Nothing in the sample resolves this offer. That is a finding about how little the title carries, not proof the offer is wrong.</p>`:``}
    </div>
  </div>`}function z(e){w(`[data-rc-open]`,e).forEach(e=>e.addEventListener(`click`,()=>{N=e.dataset.rcOpen,I(),C(`[data-rc-detail]`)?.scrollIntoView({block:`start`,behavior:`smooth`})})),w(`[data-rc-reset]`,e).forEach(e=>e.addEventListener(`click`,()=>{y(e.dataset.rcReset),I()})),w(`[data-rc-resetfilters]`,e).forEach(e=>e.addEventListener(`click`,()=>{P=`all`,F=`all`,I()}));let t=C(`[data-rc-form]`,e);t?.addEventListener(`submit`,e=>{if(e.preventDefault(),!N)return;let n=new FormData(t),r={storeScope:n.getAll(`storeScope`).map(String),startsOn:n.get(`startsOn`)||null,endsOn:n.get(`endsOn`)||null,verified:`verified`},i=n.get(`terms`);i===`__none`?r.termsOverride=null:i!==`__keep`&&(r.termsOverride=i),f(N,r),I(),B()})}function B(){let e=C(`[data-rc-flash]`);e&&(e.innerHTML=`<p class="note note--ok pulse"><span class="note__label">Saved in this browser</span>
    The correction is now in force across the deal checker, and this table.
    It has not been sent anywhere and Puff's website is unchanged. Clearing this browser's storage
    removes it.</p>`,window.setTimeout(()=>{e.innerHTML=``},6e3))}function V(){let e=C(`[data-rc]`);if(!e)return;w(`[data-rc-verdict]`,e).forEach(t=>t.addEventListener(`click`,()=>{P=t.dataset.rcVerdict,w(`[data-rc-verdict]`,e).forEach(e=>e.setAttribute(`aria-pressed`,String(e===t))),I()}));let t=C(`[data-rc-area]`,e);t?.addEventListener(`change`,()=>{F=t.value,I()}),C(`[data-rc-clear]`,e)?.addEventListener(`click`,()=>{h(),N=null,I(),B()}),g(),window.addEventListener(v,I),I()}V();